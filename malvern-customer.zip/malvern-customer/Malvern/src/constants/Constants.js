const Constants = {
  otpScreenText: 'Enter the 4-digit code sent to you at',
};
export default Constants;
