import React, {Component} from 'react';
import {
  Platform,
  Text,
  TextInput,
  StatusBar,
  PermissionsAndroid,
} from 'react-native';
import Navigation from './Navigation';
import LoadingView from './components/CLoader';
import {PersistGate} from 'redux-persist/integration/react';
import {Provider} from 'react-redux';
import SplashScreen from 'react-native-splash-screen';
import configureStore from './redux/configureStore';
import {setConfiguration} from '../src/utils/configuration';
import {API_ROOT} from './env';
import Geolocation from 'react-native-geolocation-service';
import Geocoder from 'react-native-geocoding';
import strings from './constants/languagesString';
Geocoder.init('AIzaSyCS6VfhaV6MNwtOHaXfBJY0ntUs34YUhaA');
import {decode, encode} from 'base-64';

console.ignoredYellowBox = ['Warning: Each', 'Warning: Failed'];
console.disableYellowBox = true;
const {store, persistor} = configureStore();

export default class App extends Component {
  constructor() {
    super();
    if (Text.defaultProps == null) {
      Text.defaultProps = {};
      Text.defaultProps.allowFontScaling = false;
    }
    if (TextInput.defaultProps == null) {
      TextInput.defaultProps = {};
    }
    TextInput.defaultProps.allowFontScaling = false;
    this.notificationListener = null;
  }

  componentDidMount() {
    setConfiguration('API_ROOT', API_ROOT);
    setTimeout(() => SplashScreen.hide(), 2000);
    if (Platform.OS == 'android') {
      this.requestLocationPermission();
    }
    if (!global.btoa) {
      global.btoa = encode;
    }
  }

  async requestLocationPermission() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: '',
          message: strings.accessLocation,
          buttonNegative: strings.Cancel,
          buttonPositive: strings.Ok,
        },
      );
      console.log(granted);
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        // this.getCurrentLocation();
      } else {
      }
    } catch (err) {
      console.log(err);
    }
  }

  getCurrentLocation() {
    Geolocation.getCurrentPosition(
      (position) => {
        console.log(position);
      },
      (error) => {
        console.log('Location Error222', error);
      },
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 10000,
        distanceFilter: 100,
      },
    );
  }

  render() {
    return (
      <Provider store={store}>
        <StatusBar backgroundColor="black" barStyle="light-content" />

        <PersistGate loading={null} persistor={persistor}>
          <Navigation />
          <LoadingView />
        </PersistGate>
      </Provider>
    );
  }
}
