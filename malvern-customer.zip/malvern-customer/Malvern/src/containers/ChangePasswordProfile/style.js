import {StyleSheet, Platform} from 'react-native';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.White,
  },
  lowerView: {
    flex: 1,
    marginTop: Platform.OS === 'ios' ? 40 : 0,
  },
  tile: {
    backgroundColor: 'transparent',
    width: '82%',
    alignSelf: 'center',
    marginTop: wp('5.33%'),
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0.5,
    borderColor: Colors.bottomBorder,
  },
  searchTextInput: {
    width: '100%',
    paddingBottom: 10,
    backgroundColor: 'transparent',
    borderColor: 'gray',
    borderRadius: 0,
    fontSize: wp('4.8%'),
    fontFamily: Fonts.Regular,
    color: Colors.FontDarkColor,
  },
  touchableArrow: {
    backgroundColor: 'transparent',
    position: 'absolute',
    bottom: wp('20%'),
    right: wp('10%'),
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
  },
});

export default styles;
