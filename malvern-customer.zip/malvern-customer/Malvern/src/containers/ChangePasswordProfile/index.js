import ChangePasswordProfile from './ChangePasswordProfile';
export default ChangePasswordProfile;
