import React from 'react';
import {View, Image, TextInput, TouchableOpacity, Keyboard} from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import {connect} from 'react-redux';
import {changeRequest} from './../../modules/ChangePassword/actions';
import {isEmpty} from '../../utils/CommonFunctions';
import {strings} from '../../constants/languagesString';
import Images from '../../constants/Images';
import styles from './style';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import Colors from '../../constants/Colors';

class ChangePasswordProfile extends React.Component {
  that = this;
  constructor(props) {
    super(props);
    this.state = {
      password: '',
      confirmPassword: '',
      oldPassword: '',
      fcmToken: '',
    };
  }

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  goToNextScreen() {
    this.changePasswordAPI();
  }

  verifyCredentials = () => {
    const {oldPassword, password, confirmPassword} = this.state;
    if (isEmpty(oldPassword)) {
      alert(strings.plsenterCurrentPassword);
      return false;
    } else if (isEmpty(password)) {
      alert(strings.passwordAlert);
      return false;
    } else if (password.length < 6) {
      alert(strings.passwordLength);
      return false;
    } else if (isEmpty(confirmPassword)) {
      alert(strings.confirmPasswordAlert);
      return false;
    } else if (password !== confirmPassword) {
      alert(strings.passwordDoNotMatched);
      return false;
    }
    return true;
  };

  changePasswordAPI = () => {
    const {navigation, changeRequest} = this.props;
    const {password, oldPassword} = this.state;
    if (this.verifyCredentials()) {
      NetInfo.fetch().then((state) => {
        if (state.isConnected == false) {
          this.showAlert(strings.noInternet, 300);
        } else {
          changeRequest(password, oldPassword, navigation);
        }
      });
    }
  };

  render() {
    return (
      <View style={styles.container}>
        <RenderHeader
          back={true}
          title={strings.ChangePassword}
          navigation={this.props.navigation}
        />

        <View style={styles.lowerView}>
          <KeyboardAwareScrollView>
            <View style={styles.tile}>
              <TextInput
                style={styles.searchTextInput}
                placeholder={strings.oldPassword}
                placeholderTextColor={Colors.FontDarkColor}
                autoCorrect={false}
                secureTextEntry={true}
                returnKeyType="next"
                onChangeText={(oldPassword) => this.setState({oldPassword})}
                onSubmitEditing={() => this.password.focus()}
                value={this.state.oldPassword}
              />
            </View>
            <View style={styles.tile}>
              <TextInput
                style={styles.searchTextInput}
                placeholder={strings.NewPassword}
                placeholderTextColor={Colors.FontDarkColor}
                autoCorrect={false}
                secureTextEntry={true}
                onChangeText={(password) => this.setState({password})}
                returnKeyType="next"
                onSubmitEditing={() => this.confirmPassword.focus()}
                ref={(password) => (this.password = password)}
                value={this.state.password}
              />
            </View>
            <View style={styles.tile}>
              <TextInput
                style={styles.searchTextInput}
                placeholder={strings.ConfirmPassword}
                placeholderTextColor={Colors.FontDarkColor}
                autoCorrect={false}
                secureTextEntry={true}
                returnKeyType="next"
                onChangeText={(confirmPassword) =>
                  this.setState({confirmPassword})
                }
                ref={(confirmPassword) =>
                  (this.confirmPassword = confirmPassword)
                }
                value={this.state.confirmPassword}
              />
            </View>
          </KeyboardAwareScrollView>
        </View>

        <TouchableOpacity
          style={styles.touchableArrow}
          onPress={() => this.goToNextScreen()}>
          <Image
            resizeMode="contain"
            style={styles.arrowIcon}
            source={Images.rightImg}
          />
        </TouchableOpacity>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  resetData: state.changePReducer.data,
});
const mapDispatchToProps = (dispatch) => ({
  changeRequest: (password, oldPassword, navigation) =>
    dispatch(changeRequest(password, oldPassword, navigation)),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ChangePasswordProfile);
