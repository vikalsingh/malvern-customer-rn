import React from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  ImageBackground,
  Keyboard,
  ScrollView,
  BackHandler,
  Alert,
  Linking,
} from 'react-native';
import { Platform } from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import Images from '../../constants/Images';
import ValidationMessage from '../../constants/ValidationMessage';
import styles from './style';
import VersionCheck from 'react-native-version-check';
import { getConfiguration, setConfiguration } from '../../utils/configuration';
import AsyncStorage from '@react-native-async-storage/async-storage';
import strings from '../../constants/languagesString';
import {
  appleAuth,
  AppleButton,
} from '@invertase/react-native-apple-authentication';

import {
  AccessToken,
  LoginManager,
  GraphRequest,
  GraphRequestManager,
} from 'react-native-fbsdk-next';

import { GoogleSignin } from '@react-native-google-signin/google-signin';
import Fonts from '../../constants/Fonts';
import DummySplash from '../../components/DummySplash';

import { LoginButtons } from '../../components/Buttons/Button';
import { InputTextWithCountry } from '../../components/InputTexts/Inputext';
import { RenderHeader2 } from './../../components/CustomComponent/renderHeader';
import { LanguagePop } from '../../components/Popups/LanguagePop';
import Config from '../../constants/Config';
import { fcmService } from '../../components/Notification/FCMService';
import LoadingView from '../../components/CLoader';
import NetInfo from '@react-native-community/netinfo';
import Colors from '../../constants/Colors';

export default class Login extends React.Component {
  that = this;
  constructor(props) {
    super(props);
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
    this.backHandler = null;
    this.state = {
      phone: '',
      autoLogin: false,
      countryCode: '+44',
      googleId: '',
      facebookId: '',
      appleId: '',
      mainViewTop: 0,
      socialData: '',
      photo: '',
      countryName: 'GB',
      IOSVersion: '',
      appVersion: '',
      forceUpdateVisible: false,
      appUrl: '',
      socialLoginCheck: true,
      languageList: [],
      IsLangSelected: true,
      Langid: '',
      termsCheck: false,
    };
  }

  componentWillMount() {
    // this.initLang();
    this.getData();
    // this.checkVersionUpdate();
  }

  async checkVersionUpdate() {
    try {
      const isNetConnected = await NetInfo.fetch().then((state) => {
        return state.isConnected;
      });
      if (isNetConnected) {
        let updateNeeded = await VersionCheck.needUpdate();
        console.log('updateNeeded', updateNeeded);
        if (updateNeeded != undefined) {
          this.setState({
            appUrl: updateNeeded.storeUrl,
            forceUpdateVisible: updateNeeded.isNeeded,
          });
        }
      }
    } catch (e) {
      console.log('e');

      console.log(e);
    }
  }

  componentDidMount() {
    SplashScreen.hide();
    this.init();
    this.initNotification();
  }

  initNotification() {
    fcmService.registerAppWithFCM();
    fcmService.register(onRegister);
    function onRegister(token) {
      console.log('[App] fcm token: ', token);
      if (token) {
        AsyncStorage.setItem('fcmToken', token);
        setConfiguration('fcmToken', token);
        this.setState({
          fcmToken: token,
        });
      } else {
        setConfiguration('fcmToken', 'none');
      }
    }
  }

  async initLang() {
    const languageCode = await AsyncStorage.getItem('language');
    if (languageCode != null) {
      const languageId = await AsyncStorage.getItem('languageId');
      this.setState({ Langid: languageId });

      this.setState({ IsLangSelected: true });

      strings.setLanguage(languageCode);
      setConfiguration('language', languageCode);
    } else {
      setConfiguration('user_id', '');
      setConfiguration('token', '');
      this.props.appLanguageRequest();
      setConfiguration('language', '');
      this.setState({ IsLangSelected: false });
    }
  }

  init() {
    GoogleSignin.configure({
      webClientId:
        '866633223886-cstl0rno8e189v80p06mmahcmv37pbpn.apps.googleusercontent.com',
      offlineAccess: true,
      iosClientId:
        '866633223886-bujktjrm76o6fqjd2ofmdpnque0860um.apps.googleusercontent.com',
    });

    this.Listners();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.languageList !== this.props.languageList) {
      this.setState({ languageList: this.props.languageList });
    }
    if (prevProps.profileData !== this.props.profileData) {
      this.setState({ autoLogin: false });
    }
    if (prevProps.contactsData !== this.props.contactsData) {
      console.log('My App INfo', this.props.contactsData);
    }

    if (prevProps.socialData !== this.props.socialData) {
      this.setState({ socialData: this.props.socialData }, () => {
        if (
          this.state.socialData != '' &&
          this.state.socialData != 'null' &&
          this.state.socialData != null
        ) {
          var data = this.state.socialData;
          this.afterSocialLogin(data);
        }
      });
    }
  }

  Listners() {
    this.backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
  }

  async getData() {
    try {
      this.setState({autoLogin: true});

      const us = await AsyncStorage.getItem('user_id');
      const tok = await AsyncStorage.getItem('token');
      console.log('us');
      console.log(us);
      setConfiguration('language', 'en');
      if (us) {
        setConfiguration('user_id', us);
        setConfiguration('token', tok);
        this.UpdateForce(true);
      } else {
        this.setState({ autoLogin: false });
        setConfiguration('user_id', '');
        setConfiguration('token', '');
        this.UpdateForce(false);
      }
    } catch (e) {
      console.log(e);
      this.setState({autoLogin: false});
    }
  }

  async UpdateForce(isLogin) {
    // this.props.hideLoading(true);
    await this.props.contactsRequest(this.props.navigation);
    let updateNeeded = await VersionCheck.needUpdate();

    if (updateNeeded == undefined || !updateNeeded.isNeeded) {
      if (isLogin) {
        this.getProfile();
      }
    }
  }

  afterSocialLogin = async (data) => {

    console.log("socail login", data)
    if (data.exist) {
      var token = data.data.token;
      setConfiguration('token', token);
      var user_id = data.data._id;
      setConfiguration('user_id', user_id);
      await AsyncStorage.setItem('user_id', user_id);
      await AsyncStorage.setItem('token', token);
      this.getData();
    } else {
      this.props.hideLoading(true);
      this.props.navigation.navigate('Register', {
        googleId: this.state.googleId,
        facebookId: this.state.facebookId,
        appleId: this.state.appleId,
        name: this.state.name,
        email: this.state.email,
        countryCode: this.state.countryCode,
        countryName: this.state.countryName,
        photo: this.state.photo,
        registerType: 'Social',
        verified: false,
      });
    }
  };

  verifyPhone = () => {
    const { phone } = this.state;
    if (phone.length === 0) {
      alert(ValidationMessage.mobileRequired);
      return false;
    }
    if (phone.length < 8) {
      alert(ValidationMessage.mobileValid);
      return false;
    }
    return true;
  };

  afterLogin = async () => {
    Keyboard.dismiss();
    setConfiguration('token', '');
    setConfiguration('user_id', '');

    const { countryCode, countryName, phone } = this.state;
    if (this.verifyPhone()) {
      this.props.mobileRequest(
        countryCode,
        phone,
        countryName,
        this.props.navigation,
      );
    }

  };

  getProfile() {
    this.props.profileRequest(this.props.navigation);
  }

  handleBackButtonClick = () => {
    if (this.props.navigation.isFocused()) {
      Alert.alert(
        strings.exit,
        strings.exitApp,
        [
          { text: strings.Cancel, onPress: () => { }, style: 'cancel' },
          { text: strings.exit, onPress: () => BackHandler.exitApp() },
        ],
        { cancelable: false },
      );
      return true;
    } else {
      return false;
    }
  };

  async checkVersion() {
    let updateNeeded = await VersionCheck.needUpdate();
    console.log('updateNeeded', updateNeeded);
    this.setState({ appUrl: updateNeeded.storeUrl });
    return updateNeeded;
  }

  async signInGoogle() {
    try {
      GoogleSignin.signIn()
        .then((user) => {
          this.props.showLoading(false);
          var fullname = user.user.givenName + ' ' + user.user.familyName;
          this.socialLogin(
            '',
            user.user.id,
            '',
            fullname,
            user.user.email,
            'google',
          );
          this.setState({
            googleId: user.user.id,
            facebookId: '',
            appleId: '',
            name: fullname,
            email: user.user.email,
            photo: user.user.photo,
          });

          GoogleSignin.signOut();
        })
        .catch((err) => {
          console.log('WRONG SIGNIN', err);
        })
        .done();
    } catch (e) {
      console.log(e);
    }
  }

  socialLogin(fbId, gId, aId, name, email, type) {
    setConfiguration('token', '');
    setConfiguration('user_id', '');
    let data = {
      fbid: fbId,
      gid: gId,
      appleid: aId,
      name: name,
      email: email,
      type: type,
    };
    this.props.loginWithSocialRequest(data, this.props.navigation);
  }

  fetchAndUpdateCredentialState = async () => {
    console.log('this.user', this.user);
    if (this.user === null) {
      this.setState({ credentialStateForUser: 'N/A' });
    } else {
      const credentialState = await appleAuth.getCredentialStateForUser(
        this.user,
      );
      console.log('credState', credentialState);
      if (credentialState === AppleAuthCredentialState.AUTHORIZED) {
        this.setState({ credentialStateForUser: 'AUTHORIZED' });
        console.log('cred', credentialState);
      } else {
        this.setState({ credentialStateForUser: credentialState });
        console.log('cred22', credentialState);
      }
    }
  };

  signInApple = async () => {
    console.warn('Beginning Apple Authentication');
    try {
      const appleAuthRequestResponse = await appleAuth.performRequest({
        requestedOperation: appleAuth.Operation.LOGIN,
        requestedScopes: [appleAuth.Scope.EMAIL, appleAuth.Scope.FULL_NAME],
      });

      // const credentialState = await appleAuth.getCredentialStateForUser(
      //   appleAuthRequestResponse.user,
      // );

      console.log('appleAuthRequestResponse', appleAuthRequestResponse);
      let name =
        appleAuthRequestResponse.fullName.givenName +
        ' ' +
        appleAuthRequestResponse.fullName.familyName;
      this.setState({
        googleId: '',
        facebookId: '',
        appleId: appleAuthRequestResponse.user,
        name:
          appleAuthRequestResponse.fullName.givenName +
          ' ' +
          appleAuthRequestResponse.fullName.familyName,
        email: appleAuthRequestResponse.email,
        photo: '',
      });
      this.socialLogin(
        '',
        '',
        appleAuthRequestResponse.user,
        name,
        appleAuthRequestResponse.email,
        'apple',
      );
      const {
        user: newUser,
        email,
        nonce,
        identityToken,
        realUserStatus /* etc */,
      } = appleAuthRequestResponse;

      this.user = newUser;
      this.fetchAndUpdateCredentialState()
        .then((res) => {
          console.log('EE3', res);
          this.setState({ credentialStateForUser: res });
        })
        .catch((error) => {
          this.setState({ credentialStateForUser: `Error: ${error.code}` }),
            console.log(error, 'EE2');
        });
      if (identityToken) {
        // e.g. sign in with Firebase Auth using `nonce` & `identityToken`
        //  console.log(nonce, identityToken);
      } else {
        // no token - failed sign-in?
      }

      console.warn(`Apple Authentication Completed, ${this.user}, ${email}`);
    } catch (error) {
      if (error.code === appleAuth.Error.CANCELED) {
        console.log('User canceled Apple Sign in.');
      } else {
        console.log(error);
      }
    }
  };

  handleFacebookLogin() {
    var that2 = this;
    // if (LoginManager.getInstance() != null) {
    //   LoginManager.getInstance().logOut();
    // }
    LoginManager.logOut();
    if (Platform.OS === 'android') {
      LoginManager.setLoginBehavior('web_only');
    }

    LoginManager.logInWithPermissions(['public_profile', 'email']).then(
      function (result) {
        if (result.isCancelled) {
          console.log('Login cancelled');
        } else {
          console.log('resuttttttt', result);
          AccessToken.getCurrentAccessToken().then((data) => {
            let accessToken = data.accessToken;

            const responseInfoCallback = (error, result) => {
              if (error) {
                console.log(error);
                alert('Error fetching data: ' + error.toString());
              } else {
                console.log(result);
                var api = `https://graph.facebook.com/v2.3/${result.id}?fields=name,email,picture&access_token=${accessToken}`;

                fetch(api)
                  .then((response) => response.json())
                  .then((responseData) => {
                    that2.props.showLoading(false);
                    console.log(
                      '------------responseData-------------------: ',
                      responseData,
                    );
                    that2.setState({
                      googleId: '',
                      facebookId: responseData.id,
                      appleId: '',
                      name: responseData.name,
                      email: responseData.email,
                      photo: responseData.picture.data.url,
                    });
                    that2.socialLogin(
                      responseData.id,
                      '',
                      '',
                      responseData.name,
                      responseData.email,
                      'facebeook',
                    );
                  });
              }
            };

            const infoRequest = new GraphRequest(
              '/me',
              {
                accessToken: accessToken,
                parameters: {
                  fields: {
                    string: 'email,name,first_name,middle_name,last_name',
                  },
                },
              },
              responseInfoCallback,
            );

            // Start the graph request.
            new GraphRequestManager().addRequest(infoRequest).start();
          });
        }
      },
      function (error) {
        console.log('Login fail with error: ' + error);
      },
    );
  }

  getCountryCode() {
    var country = this.phone.getCountryCode();
    var name = this.phone.getISOCode();
    console.log('---country code----- ', name);
    this.setState({ countryCode: '+' + country, countryName: name });
  }

  onSelectCountry = (country) => {
    console.log(country);
    this.setState({
      countryName: country.cca2,
      countryCode: '+' + country.callingCode[0],
      showFlag: false,
    });
  };

  onSignupClick = () => {
    this.props.navigation.navigate(Config.Register, {
      mobileNumber: '',
      countryCode: this.state.countryCode,
      countryName: this.state.countryName,
      otp: '',
      verified: false,
    });
  };

  setLanguage(item) {
    console.log('languageId', item._id);
    this.setState({ IsLangSelected: true });
    AsyncStorage.setItem('languageId', item._id);
    AsyncStorage.setItem('language', item.languageCode);
    strings.setLanguage(item.languageCode);
  }

  updateApp() {
    try {
      console.log('goToPlayStore', this.state.appUrl);
      Linking.openURL(this.state.appUrl);
    } catch (e) {
      console.log('eee');
      console.log(e);
    }
  }

  render() {
    if (!this.state.IsLangSelected) {
      return (
        <LanguagePop
          languageList={this.state.languageList}
          setLanguage={(item) => this.setLanguage(item)}
        />
      );
    } else if (this.state.forceUpdateVisible) {
      return (
        <View style={styles.containerBlack}>
          <ImageBackground
            style={{ height: '100%', width: '100%', justifyContent: 'center' }}
            source={Images.loginBGplan}
            resizeMode="stretch">
            <TouchableOpacity
              style={{ position: 'absolute', right: 20, top: 50 }}
              onPress={() => {
                this.setState({ forceUpdateVisible: false });
                this.getProfile();
              }}>
              <Image
                source={Images.iconCan}
                style={{
                  width: 50,
                  height: 50,
                  resizeMode: 'contain',

                  tintColor: Colors.PrimaryColor,
                }}
              />
            </TouchableOpacity>
            <View
              style={{
                width: '100%',
                height: 'auto',
                alignItems: 'center',
                marginBottom: 200,
              }}>
              <Image
                style={{ height: 150, width: 150 }}
                source={Images.inovation}
                resizeMode="contain"
              />

              <Text
                style={{
                  color: 'black',
                  fontFamily: Fonts.Semibold,
                  fontSize: 30,
                }}>
                Better and faster
              </Text>
              <Text
                style={{
                  color: 'black',
                  fontFamily: Fonts.Semibold,
                  fontSize: 30,
                  marginBottom: 5,
                }}>
                Version Available
              </Text>
              <Text
                style={{
                  color: 'black',
                  fontFamily: Fonts.Regular,
                  fontSize: 16,
                  textAlign: 'center',
                  width: '90%',
                  alignSelf: 'center',
                }}>
                An update with new features and fixes is available. it typically
                takes less then 1 minute.
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => this.updateApp()}
              style={{
                backgroundColor: Colors.PrimaryColor,
                width: '80%',
                alignSelf: 'center',
                height: 40,
                borderRadius: 20,
                justifyContent: 'center',
              }}>
              <Text
                style={{
                  color: 'white',
                  fontSize: 20,
                  fontFamily: Fonts.Semibold,
                  alignSelf: 'center',
                }}>
                Update Now
              </Text>
            </TouchableOpacity>
          </ImageBackground>
        </View>
      );
    } else {
      return (
        <View style={styles.container}>
          <RenderHeader2
            title={strings.Login}
            navigation={this.props.navigation}
          />

          <View style={styles.HeaderImage}>
            <View style={{ marginVertical: '5%' }}>
              <Image
                resizeMode="contain"
                style={{ width: '100%', height: '70%' }}
                source={Images.loginLogo}
              />
            </View>
            <Text style={styles.enterNumberText}>
              {strings.EnterYourMobileNumber.toUpperCase()}
            </Text>
            {/* <Text style={styles.loginDesTextStyle}>{strings.loginDesText}</Text> */}
          </View>

          <ScrollView keyboardShouldPersistTaps="handled">
            <InputTextWithCountry
              placeholder={true}
              editable={true}
              cnName={this.state.countryName}
              cnCode={this.state.countryCode}
              showFlag={this.state.showFlag}
              onSelect={(country) => this.onSelectCountry(country)}
              onShowFlag={() => this.setState({ showFlag: true })}
              phone={this.state.phone}
              onChangePhone={(text) => this.setState({ phone: text })}
            />

            {/* <View
              style={{
                width: '85%',
                alignSelf: 'center',
                marginTop: '6%',
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <TouchableOpacity
                onPress={() =>
                  this.setState({ termsCheck: !this.state.termsCheck })
                }>
                <Image
                  source={
                    this.state.termsCheck ? Images.Check : Images.unchecked
                  }
                  style={{
                    width: 20,
                    height: 20,
                    tintColor: Colors.PrimaryColor,
                  }}
                />
              </TouchableOpacity>
              <Text style={{ marginLeft: 8 }}>
                {'I Agree To '}
                <Text
                  style={{ color: Colors.PrimaryColor }}
                  onPress={() =>
                    this.props.navigation.navigate(Config.TermsConditions)
                  }>
                  {'Terms & Conditions'}
                </Text>
                {' and '}
                <Text
                  style={{ color: Colors.PrimaryColor }}
                  onPress={() =>
                    this.props.navigation.navigate(Config.PrivacyPolicy)
                  }>
                  {'Privacy Policy'}
                </Text>
              </Text>
            </View> */}

            <LoginButtons
              text={strings.next}
              onClick={() => this.afterLogin()}
            />

            <View style={styles.orSignWithView}>
              <View style={styles.grayLine} />
              <Text style={styles.signinwithtext}>{strings.orsignWith}</Text>
              <View style={styles.grayLine} />
            </View>

            {this.state.socialLoginCheck ? (
              <View style={styles.socialBtnContainer}>
                <View>
                  <TouchableOpacity onPress={() => this.handleFacebookLogin()}>
                    <Image
                      resizeMode="contain"
                      style={styles.socialBtn}
                      source={Images.fbIcon}
                    />
                  </TouchableOpacity>
                </View>

                <View>
                  <TouchableOpacity onPress={() => this.signInGoogle()}>
                    <Image
                      resizeMode="contain"
                      style={styles.socialBtn}
                      source={Images.googleIcon}
                    />
                  </TouchableOpacity>
                </View>
                <View>
                  {Platform.OS != 'android' && appleAuth.isSupported ? (
                    <TouchableOpacity onPress={() => this.signInApple()}>
                      <Image
                        resizeMode="contain"
                        style={styles.socialBtn}
                        source={Images.appleIcon}
                      />
                    </TouchableOpacity>
                  ) : null}
                </View>
              </View>
            ) : null}

            {/* <Text style={styles.noAccountText}>
            {strings.donotaccount}
            {'  '}
            <Text onPress={this.onSignupClick} style={styles.signupTexts}>
              {strings.SignUp}
            </Text>
          </Text> */}

            <View style={{ height: 40 }} />
          </ScrollView>

          {this.state.autoLogin ? <DummySplash /> : null}
        </View>
      );
    }
  }
}
