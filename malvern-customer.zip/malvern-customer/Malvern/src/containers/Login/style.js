import {StyleSheet} from 'react-native';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  containerBlack: {
    flex: 1,
    backgroundColor: 'black',
    justifyContent: 'center',
  },
  HeaderImage: {
    alignSelf: 'center',
    justifyContent: 'flex-end',
    backgroundColor: '#ffffff',
    height: '30%',
    width: '85%',
  },
  headingBG: {
    marginTop: wp('5.33%'),
    width: '100%',
    height: 'auto',
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
  },
  touchableArrow: {
    backgroundColor: Colors.background,
    position: 'absolute',
    right: 0,
    bottom: 0,
    height: wp('15%'),
    width: wp('15%'),
    borderRadius: wp('7.5%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  socialBtnContainer: {
    backgroundColor: 'transparent',
    width: '100%',
    height: 50,
    marginTop: Platform.OS === 'ios' ? wp('5%') : wp('5%'),
    marginHorizontal: -10,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  socialBtn: {marginLeft: wp('5%'), width: wp('12%'), height: '100%'},
  orTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    marginTop: 50,
  },
  orText: {
    fontFamily: Fonts.Thin,
    color: 'black',
    fontSize: wp('4.8%'),
  },
  signinwithtext: {
    color: Colors.FontDarkColor,
    fontSize: wp('3.5%'),
    fontFamily: Fonts.Semibold,
    width: '40%',
    alignSelf: 'center',
    textAlign: 'center',
  },
  orSignWithView: {
    width: '85%',
    alignSelf: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    marginTop: hp('6%'),
  },
  grayLine: {
    width: '30%',
    height: 0.5,
    backgroundColor: 'grey',
    backgroundColor: 'gray',
  },
  enterNumberText: {
    fontFamily: Fonts.Semibold,
    fontSize: wp('4.5%'),
    color: Colors.FontDarkColor,
  },
  loginDesTextStyle: {
    marginTop: wp('1%'),
    fontFamily: Fonts.Regular,
    fontSize: wp('3.5%'),
    color: Colors.FontMediumDark,
    marginBottom: wp('6%'),
    marginRight: wp('4%'),
  },
  noAccountText: {
    color: Colors.colorLight,
    alignSelf: 'center',
    marginTop: wp('20%'),
    fontFamily: Fonts.Thin,
    fontSize: wp('4%'),
  },
  signupTexts: {
    fontFamily: Fonts.Semibold,
    color: Colors.ColorSignup,
  },
  updateContainerImage: {
    height: '100%',
    width: '100%',
    justifyContent: 'center',
  },
  updateView: {
    width: '100%',
    height: 'auto',
    alignItems: 'center',
    marginBottom: 200,
  },
  bettertxt: {
    color: 'white',
    fontFamily: Fonts.Semibold,
    fontSize: 30,
  },
  versionAvatxt: {
    color: 'white',
    fontFamily: Fonts.Semibold,
    fontSize: 30,
    marginBottom: 5,
  },
  descriptionTxt: {
    color: 'white',
    fontFamily: Fonts.Regular,
    fontSize: 16,
    textAlign: 'center',
  },
});
export default styles;
