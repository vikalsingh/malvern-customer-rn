import Login from './Login';
import {connect} from 'react-redux';
import {
  mobileRequest,
  loginWithSocialRequest,
} from './../../modules/Login/actions';
import {contactsRequest} from './../../modules/GetContacts/actions';
import {profileRequest} from './../../modules/GetProfile/actions';
import {
  appConfigRequest,
  appLanguageRequest,
} from './../../modules/GetAppConfig/actions';
import {hideLoading, showLoading} from '../../components/CLoader/action';

const mapStateToProps = (state) => ({
  socialData: state.mobileReducer.socialData,
  profileData: state.GetProfileReducer.profileData,
  contactsData: state.getContactsReducer.App_Settings,
  AppConfigData: state.GetAppConfigReducer.AppConfigData,
  languageList: state.GetAppConfigReducer.languageData,
});

const mapDispatchToProps = (dispatch) => ({
  mobileRequest: (countryCode, mobileNumber, countryName, navigation) =>
    dispatch(mobileRequest(countryCode, mobileNumber, countryName, navigation)),
  loginWithSocialRequest: (data, navigation) =>
    dispatch(loginWithSocialRequest(data, navigation)),
  profileRequest: (navigation) => dispatch(profileRequest(navigation)),
  contactsRequest: (navigation) => dispatch(contactsRequest(navigation)),
  appConfigRequest: (navigation) => dispatch(appConfigRequest(navigation)),
  appLanguageRequest: () => dispatch(appLanguageRequest()),
  showLoading: (navigation) => dispatch(showLoading(navigation)),
  hideLoading: (navigation) => dispatch(hideLoading(false, '')),
});
export default connect(mapStateToProps, mapDispatchToProps)(Login);
