import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import {Image as ImageEle} from 'react-native-elements';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Fonts from '../../constants/Fonts';
import Config from '../../constants/Config';
import Images from '../../constants/Images';
import Colors from '../../constants/Colors';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import {LoginButtons} from '../../components/Buttons/Button';

export default class Profile extends React.PureComponent {
  render() {
    var {name, profileImage, email, mobileNumber, address, langName} = '';
    if (this.props.loginData != null && this.props.loginData != '') {
      console.log(this.props.loginData);
      let userData = this.props.loginData;
      name = userData.name;
      profileImage = userData.profileImage;
      email = userData.email;
      mobileNumber = userData.countryCode + '-' + userData.mobileNumber;
      address = userData.address;
      langName = userData.languageDetails
        ? userData.languageDetails.languageName
        : '';
    }
    return (
      <View style={{flex: 1, backgroundColor: '#ffffff'}}>
        <RenderHeader
          title={strings.Profile}
          navigation={this.props.navigation}
        />

        <TouchableOpacity
          style={styles.editIcon}
          onPress={() => this.props.navigation.navigate(Config.EditProfile)}>
          <Image source={Images.edit_profile_Ic} style={styles.editpro} />
        </TouchableOpacity>

        <View style={styles.profileView}>
          <View style={styles.profileimg}>
            <ImageEle
              style={styles.profileImg}
              source={
                profileImage == '' ||
                profileImage == 'null' ||
                profileImage == null ||
                profileImage == 'none'
                  ? Images.drawerProfileBG
                  : {uri: profileImage}
              }
              PlaceholderContent={
                <View style={styles.indicatorView}>
                  <ActivityIndicator style={styles.activityInd} />
                </View>
              }
            />
          </View>
          <Text style={styles.profileName}>{name}</Text>
        </View>

        <View style={styles.detailsView}>
          <View style={styles.tile}>
            <Image style={styles.tileIcon} source={Images.WhitePhone} />
            <Text numberOfLines={1} style={styles.inputTxt}>
              {mobileNumber}
            </Text>
          </View>
          <View style={styles.separtorline} />

          <View style={styles.tile}>
            <Image style={styles.tileIcon} source={Images.Email_Ic} />
            <Text numberOfLines={1} style={styles.inputTxt}>
              {email}
            </Text>
          </View>
          <View style={styles.separtorline} />

          <View style={styles.tile}>
            <Image style={styles.tileIcon} source={Images.Address_Ic} />
            <Text numberOfLines={1} style={styles.inputTxt}>
              {address ? address : 'Address'}
            </Text>
          </View>
          {/* <View style={styles.separtorline} /> */}

          {/* <View style={styles.tile}>
            <Image style={styles.tileIcon} source={Images.langProfile} />
            <Text numberOfLines={1} style={styles.inputTxt}>
              {langName}
            </Text>
          </View> */}
        </View>

        <View style={{position: 'absolute', bottom: wp('15%'), width: '100%'}}>
          <LoginButtons
            text={strings.ChangePassword}
            onClick={() =>
              this.props.navigation.navigate(Config.ChangePasswordProfile)
            }
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  profileView: {
    width: '100%',
    alignItems: 'center',
  },
  profileimg: {
    height: hp('12%'),
    width: hp('12%'),
    overflow: 'hidden',
    elevation: 1,
    borderColor: Colors.White,
    borderRadius: 60,
    backgroundColor: 'transparent',
  },
  profileName: {
    color: Colors.FontDarkColor,
    fontFamily: Fonts.Semibold,
    fontSize: wp('5%'),
    marginTop: hp('1%'),
  },
  activityInd: {
    marginRight: 10,
    marginBottom: 8,
    backgroundColor: 'transparent',
  },
  inputTxt: {
    color: Colors.FontDarkColor,
    marginLeft: 20,
    fontSize: 16,
    height: 20,
    fontFamily: Fonts.Semibold,
    marginBottom: 2,
    width: '80%',
  },
  title: {
    fontSize: wp('4.0%'),
    color: 'white',
    fontFamily: Fonts.Semibold,
  },
  tile: {
    alignSelf: 'center',
    width: '90%',
    paddingVertical: wp('3%'),
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  tileIcon: {
    width: 30,
    height: 40,
    resizeMode: 'contain',
  },
  profileImg: {
    width: '100%',
    height: '100%',
    borderRadius: 45,
    resizeMode: 'cover',
  },
  indicatorView: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  editIcon: {
    alignSelf: 'flex-end',
    marginRight: wp('5%'),
    marginTop: wp('7%'),
  },
  editpro: {
    height: 35,
    width: 35,
  },
  detailsView: {
    width: '85%',
    backgroundColor: 'white',
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    borderRadius: 15,
    elevation: 5,
    alignSelf: 'center',
    marginTop: 25,
  },
  separtorline: {
    height: 1,
    marginLeft: '20%',
    backgroundColor: Colors.FontDarkColor,
    opacity: 0.5,
  },
});
