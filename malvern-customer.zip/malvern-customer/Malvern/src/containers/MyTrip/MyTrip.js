import React from 'react';
import {
  Alert,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  FlatList,
  ScrollView,
  BackHandler,
  ImageBackground,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import moment from 'moment';
import { widthPercentageToDP as wp } from 'react-native-responsive-screen';
import { strings } from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import { RenderHeaderBack } from './../../components/CustomComponent/renderHeader';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';
import { TabOption, Rating } from './components/MytripComponents';

class MyTrips extends React.PureComponent {
  constructor(props) {
    super(props);
    this.backHandler = null;
    this.state = {
      type: 1,
      upcomingData: [],
      pastData: [],
      detailView: false,
      itemDetail: '',
      myTripsData: '',
      currency: '£',
    };

    const { navigation } = props;
    this.didFocusListener = navigation.addListener(
      'focus',
      this.componentDidFocus,
    );
  }

  handleBackButtonClick = () => {
    if (this.props.navigation.isFocused()) {
      if (this.state.detailView == true) {
        this.setState({ detailView: false });
        return true;
      } else {
        this.props.navigation.goBack();
        return true;
      }
    } else {
      return false;
    }
  };

  componentDidMount() {
    let currency = this.props.contactsData.App_Settings.Admin_Currency_Code;
    this.setState({ currency: currency });
    this.backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
  }

  componentWillUnmount() {
    BackHandler.removeEventListener(
      'hardwareBackPress',
      this.handleBackButtonPressAndroid,
    );
    this.didFocusListener();
  }

  componentDidFocus = () => {
    this.getTripsData();
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.myTripsData !== this.props.myTripsData) {
      this.setState({ myTripsData: this.props.myTripsData }, () => {
        var data = this.state.myTripsData;
        this.afterGetTripsData(data);
      });
    }
    if (prevProps.cancelTripData !== this.props.cancelTripData) {
      this.setState({ cancelTripData: this.props.cancelTripData }, () => {
        if (this.state.cancelTripData.status === 'success') {
          this.afterCancelTrip();
        }
      });
    }
  }

  getTripsData = () => {
    this.props.myTripsRequest();
  };

  afterGetTripsData = (data) => {
    var upcomingData = data.upcomingBooking;
    var pastData = data.pastBooking;

    this.setState({
      upcomingData: upcomingData,
      pastData: pastData,
    });
  };

  showAlert(message, duration) {
    this.setState({ autoLogin: false });
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  goToDetails(item, type) {
    console.log(JSON.stringify(item));
    if (item.tripStatus == 'schedule') {
      this.setState({ detailView: true, itemDetail: item, itemType: type });
    } else {
      this.setState({ detailView: true, itemDetail: item, itemType: type });
    }
  }

  upcomingClick() {
    this.setState({ type: 1 });
    this.getTripsData();
  }

  pastClick() {
    this.setState({ type: 2 });
    this.getTripsData();
  }

  cancelTrip(item) {
    Alert.alert(
      strings.Alert,
      'Want to cancel this trip?',
      [
        { text: strings.Cancel, onPress: () => { }, style: 'cancel' },
        { text: strings.Yes, onPress: () => this.callCancelTrip(item) },
      ],
      { cancelable: false },
    );
  }

  callCancelTrip(item) {
    let data = {
      tripId: item,
    };
    this.props.cancelTripRequest(data, this.props.navigation);
    this.setState({ detailView: false });
  }

  afterCancelTrip() {
    // this.getTripsData();
  }

  getDateAndTime(dateTime, type) {
    if (type == 'schedule') {
      var dateUTC = new Date(dateTime);
      var dateUTC = dateUTC.getTime();
      var dateIST = new Date(dateUTC);
      dateIST.setHours(dateIST.getHours() - 5);
      dateIST.setMinutes(dateIST.getMinutes() - 15);
      var newDate = moment(dateIST).format('DD/MM/YYYY');
      var newTime = moment(dateIST).format('hh:mm A');
      return newDate + ' ' + ',' + ' ' + newTime;
    } else {
      var newDate = moment(dateTime).format('DD/MM/YYYY');
      var newTime = moment(dateTime).format('hh:mm A');
      return newDate + ' ' + ',' + ' ' + newTime;
    }
  }
  openDrawerClick() {
    this.setState({ detailView: false });
  }

  renderItems(item, index, data, type) {
    return (
      <TouchableOpacity
        onPress={() => this.goToDetails(item, type)}
        style={[
          styles.loadDetail,
          { marginBottom: data.length - 1 == index ? 60 : 0 },
        ]}>
        {/* {item.trip_type == 'schedule' ? (
          <View style={styles.ratingView} />
        ) : (
          <View style={styles.ratingView}>
            <Text style={{fontSize: 16, fontFamily: Fonts.Regular}}>
              {parseFloat(item.review.driverRating).toFixed(1)}
            </Text>
            <Image source={Images.rated_star} style={styles.starRatingIcon} />
          </View>
        )} */}

        <View style={[styles.priceTile, { marginTop: 10 }]}>
          <Text style={styles.txtDate}>
            {item.trip_type == 'schedule'
              ? moment(item.scheduleDate).format('DD/MM/YYYY') +
              ', ' +
              item.scheduleTime
              : this.getDateAndTime(item.tripEndedAt)}
          </Text>

          <View>
            {item.trip_type == 'schedule' ? (
              <Text style={styles.txtAmount}>
                {this.state.currency}{' '}
                {parseFloat(item.estimatedCost).toFixed(2)}
              </Text>
            ) : (
              <View>
                {item.tripStatus == 'Completed' ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text style={styles.txtAmount}>
                      {this.state.currency} {parseFloat(item.cost).toFixed(2)}
                    </Text>

                    <Image
                      source={Images.success_green_ic}
                      style={{
                        width: 15,
                        height: 15,
                        resizeMode: 'contain',
                        marginLeft: 7,
                      }}
                    />
                  </View>
                ) : (
                  <Text style={styles.statusCancelText}>
                    {strings.Cancelled.toUpperCase()}
                  </Text>
                )}
              </View>
            )}
          </View>
        </View>

        <View style={styles.seprator} />

        <View style={styles.sourceAddressBG}>
          <View style={{ width: '15%', height: 100, alignItems: 'center' }}>
            <Image style={styles.destIcon} source={Images.desti_his} />
            <View style={styles.blackLine} />
            <Image style={styles.sourceIcon} source={Images.source_his} />
          </View>
          <View
            style={{
              width: '85%',
              height: 100,
              justifyContent: 'space-between',
            }}>
            <Text numberOfLines={2} style={styles.txtSource}>
              {item.startLocationAddr}
            </Text>

            <Text numberOfLines={2} style={styles.txtDest}>
              {item.endLocationAddr}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  sendEmail() {
    this.refs.viewShot.capture().then((uri) => {
      console.log('do something with ', uri);
      var that = this;
      async function requestExternalWritePermission() {
        try {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
            {
              title: 'Ride O Ride App External Storage Write Permission',
              message:
                'Ride O Ride App needs access to Storage data in your SD Card ',
            },
          );
          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            //changing the state to show Create PDF option
            that.convertToPDFMail(uri);
          } else {
            alert('WRITE_EXTERNAL_STORAGE permission denied');
          }
        } catch (err) {
          alert('Write permission err', err);
          console.log(err);
        }
        //Calling the External Write permission function
      }
      if (Platform.OS === 'android') {
        requestExternalWritePermission();
      } else {
        this.convertToPDFMail(uri);
      }
    });
  }

  render() {
    const { type, upcomingData, pastData, detailView, itemDetail } = this.state;

    return (
      <View style={{ flex: 1, backgroundColor: 'white' }}>
        <RenderHeader
          back={true}
          title={strings.MyTrips}
          navigation={this.props.navigation}
        />
        <View style={{ flex: 1 }}>
          <View
            style={{ flexDirection: 'row', height: wp(10), marginTop: wp('4%') }}>
            <TabOption
              color={type === 1 ? Colors.FontDarkColor : 'white'}
              title={strings.Upcoming}
              onClick={() => this.upcomingClick()}
            />
            <TabOption
              color={type === 2 ? Colors.FontDarkColor : 'white'}
              title={strings.Past}
              onClick={() => this.pastClick()}
            />
          </View>

          <View style={{ flex: 1 }}>
            <FlatList
              style={{ flex: 1 }}
              data={this.state.type == 1 ? upcomingData : pastData}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item, index }) =>
                this.renderItems(
                  item,
                  index,
                  type == 1 ? upcomingData : pastData,
                  type,
                )
              }
              ListEmptyComponent={
                <Text
                  style={{
                    width: wp('100%'),
                    marginTop: 20,
                    textAlign: 'center',
                  }}>
                  {' '}
                  {strings.Nobookingsavailable}{' '}
                </Text>
              }
            />
          </View>
        </View>

        {detailView ? (
          <View
            style={{
              width: '100%',
              height: '100%',
              backgroundColor: 'white',
              position: 'absolute',
            }}>
            <RenderHeaderBack
              onBack={() => this.setState({ detailView: false })}
              title={type == 2 ? strings.myTripDetail : strings.myTripDetailUp}
            />

            <View style={{ width: '90%', alignSelf: 'center', marginTop: 40 }}>
              <View style={styles.priceTile}>
                <Text style={styles.txtDate}>
                  {type == 2
                    ? this.getDateAndTime(itemDetail.tripEndedAt)
                    : itemDetail.scheduleDate + ', ' + itemDetail.scheduleTime}
                </Text>

                {type == 2 ? (
                  <View>
                    {itemDetail.tripStatus == 'Completed' ? (
                      <Text style={styles.statusText}>
                        {strings.Completed.toUpperCase()}
                      </Text>
                    ) : (
                      <Text style={styles.statusCancelText}>
                        {strings.Cancelled.toUpperCase()}
                      </Text>
                    )}
                  </View>
                ) : (
                  <Text style={styles.txtAmount}>
                    {this.state.currency} {parseFloat(itemDetail.estimatedCost).toFixed(2)}
                  </Text>
                )}
              </View>

              <View style={styles.seprator} />
              {/* <View style={styles.ratingView}>
                <Text style={{fontSize: 16, fontFamily: Fonts.Regular}}>
                  {parseFloat(itemDetail.review.customerRating).toFixed(1)}
                </Text>
                <Image
                  source={Images.rated_star}
                  style={styles.starRatingIcon}
                />
              </View> */}
            </View>

            <View style={styles.sourceAddressBG}>
              <View style={{ width: '15%', height: 100, alignItems: 'center' }}>
                <Image style={styles.destIcon} source={Images.desti_his} />
                <View style={styles.blackLine} />
                <Image style={styles.sourceIcon} source={Images.source_his} />
              </View>
              <View
                style={{
                  width: '85%',
                  height: 100,
                  justifyContent: 'space-between',
                }}>
                <Text numberOfLines={2} style={styles.txtSource}>
                  {itemDetail.startLocationAddr}
                </Text>

                <Text numberOfLines={2} style={styles.txtDest}>
                  {itemDetail.endLocationAddr}
                </Text>
              </View>
            </View>

            {type == 2 && itemDetail.tripStatus == 'Completed' ? (
              <View style={styles.driverDetailCard}>
                <View style={styles.driverDetailView}>
                  <Image
                    source={
                      itemDetail.driverImage == 'null' ||
                        itemDetail.driverImage == null
                        ? Images.drawerProfileBG
                        : { uri: itemDetail.driverRefId.profileImage }
                    }
                    style={styles.profileimg}
                  />
                  <Text style={styles.driverName}>{itemDetail.driverName}</Text>
                </View>
                <View style={styles.driverDetailViews}>
                  <View style={styles.carNumberView}>
                    <Text style={styles.carPlateNumber}>
                      {itemDetail.driverRefId.selectedCar.plateNumber}
                    </Text>
                  </View>
                  <Text style={styles.carName}>
                    {itemDetail.driverRefId.selectedCar.carName}
                  </Text>
                  {/* <Text style={[styles.carName]}>
                    {'Tip ' + itemDetail.tipAmount + ' ' + this.state.currency}
                  </Text> */}
                </View>
                <View
                  style={{
                    width: '30%',
                    height: '100%',
                  }}>
                  <View style={styles.ratingView}>
                    <Text style={{ fontSize: 16, fontFamily: Fonts.Regular }}>
                      {parseFloat(itemDetail.review.driverRating).toFixed(1)}
                    </Text>
                    <Image
                      source={Images.rated_star}
                      style={styles.starRatingIcon}
                    />
                  </View>
                  <Text
                    style={[
                      styles.txtAmount,
                      {
                        position: 'absolute',
                        top: '40%',
                        bottom: 0,
                        right: 10,
                      },
                    ]}>
                    {this.state.currency}{' '}
                    {parseFloat(itemDetail.cost).toFixed(2)}
                  </Text>
                </View>
              </View>
            ) : null}

            {type == 1 ? (
              <TouchableOpacity
                onPress={() => this.cancelTrip(itemDetail._id)}
                style={{
                  marginTop: 10,
                  alignItems: 'center'
                }}>
                <Text style={styles.cancelText}> Cancel Trip </Text>
              </TouchableOpacity>
            ) : null}
          </View>
        ) : null}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  noBookingTxt: {
    width: wp('100%'),
    marginTop: 20,
    textAlign: 'center',
    fontSize: 18,
    fontFamily: Fonts.Medium,
  },
  loadDetail: {
    width: '94%',
    alignSelf: 'center',
    backgroundColor: 'white',
    shadowColor: 'gray',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    elevation: 5,
    borderRadius: 12,
    marginTop: 15,
    padding: 10,
  },
  sourceAddressBG: {
    marginTop: wp('2%'),
    backgroundColor: 'transparent',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  priceTile: {
    flexDirection: 'row',
    backgroundColor: 'transparent',
    width: '100%',
    justifyContent: 'space-between',
  },
  txtAmount: {
    fontFamily: Fonts.Semibold,
    color: Colors.Black,
    fontSize: 18,
  },
  txtDate: {
    fontFamily: Fonts.Semibold,
    fontSize: 14,
    color: Colors.Black,
  },
  txtSource: {
    fontFamily: Fonts.Regular,
    marginLeft: 10,
    marginRight: 10,
    fontSize: 14,
  },
  txtDest: {
    fontFamily: Fonts.Regular,
    marginTop: 10,
    marginLeft: 10,
    fontSize: 14,
  },
  destIcon: {
    height: 12,
    width: 18,
    resizeMode: 'contain',
  },
  blackLine: {
    height: 60,
    width: 1,
    backgroundColor: 'black',
    marginTop: 3,
    marginBottom: 3,
  },
  sourceIcon: {
    height: 12,
    width: 18,
    resizeMode: 'contain',
    marginRight: 2,
    tintColor: '#4B545A',
  },
  seprator: {
    height: 1,
    backgroundColor: 'grey',
    marginTop: 7,
    marginBottom: 14,
    opacity: 0.4,
  },
  starRatingIcon: {
    width: 20,
    height: 20,
    resizeMode: 'contain',
    marginLeft: 5,
    marginRight: 10,
  },
  ratingView: {
    alignSelf: 'flex-end',
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 8,
  },
  statusText: {
    fontFamily: Fonts.Semibold,
    fontSize: 14,
    color: Colors.buttonsColor,
  },
  statusCancelText: {
    fontFamily: Fonts.Semibold,
    fontSize: 14,
    color: 'red',
  },
  driverDetailCard: {
    marginTop: 40,
    width: '90%',
    alignSelf: 'center',
    height: 120,
    borderWidth: 1,
    borderColor: Colors.graylight,
    flexDirection: 'row',
  },
  profileimg: {
    width: 60,
    height: 60,
    resizeMode: 'cover',
    borderRadius: 30,
    borderWidth: 1,
    borderColor: Colors.graylight,
  },
  driverDetailView: {
    width: '30%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  driverDetailViews: {
    width: '40%',
    height: '100%',

    justifyContent: 'center',
  },
  driverName: {
    fontFamily: Fonts.Semibold,
    marginTop: 5,
  },
  carNumberView: {
    backgroundColor: Colors.graylights,
    padding: 5,
    paddingLeft: 20,
    paddingRight: 20,
    borderRadius: 20,
  },
  carPlateNumber: {
    fontFamily: Fonts.Bold,
    fontSize: 16,
  },
  carName: {
    fontFamily: Fonts.Regular,
    fontSize: 17,
  },
  cancelText: {
    color: 'red',
    borderWidth: 1,
    borderRadius: 15,
    borderColor: 'red', padding: 7
  }
});

export default MyTrips;
