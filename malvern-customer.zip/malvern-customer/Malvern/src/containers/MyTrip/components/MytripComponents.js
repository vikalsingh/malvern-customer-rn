import React from 'react';
import {TouchableOpacity, Text, Image} from 'react-native';
import Fonts from '../../../constants/Fonts';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import Colors from '../../../constants/Colors';
import Images from '../../../constants/Images';

function TabOption({color, title, onClick}) {
  return (
    <TouchableOpacity
      style={{
        flex: 1,
        borderBottomWidth: 2,
        borderColor: color,
        justifyContent: 'center',
        alignItems: 'center',
      }}
      onPress={() => onClick()}>
      <Text
        style={{
          color: Colors.FontDarkColor,
          fontFamily: Fonts.Semibold,
          fontSize: wp(4),
        }}>
        {title.toUpperCase()}
      </Text>
    </TouchableOpacity>
  );
}

function Rating() {
  return (
    <Image
      style={{
        height: 20,
        width: 20,
        resizeMode: 'contain',
        tintColor: Colors.PrimaryColor,
      }}
      source={Images.starBlack}
    />
  );
}

export {TabOption, Rating};
