import MyTrip from './MyTrip';
import {myTripsRequest} from './../../modules/MyTrips/actions';
import {cancelTripRequest} from '../../modules/Trip/actions';
import {connect} from 'react-redux';
const mapStateToProps = (state) => ({
  myTripsData: state.myTripsReducer.data,
  cancelTripData: state.tripReducer.cancelTripData,
  contactsData: state.getContactsReducer.contactsData,
});
const mapDispatchToProps = (dispatch) => ({
  myTripsRequest: () => dispatch(myTripsRequest()),
  cancelTripRequest: (data, navigation) => dispatch(cancelTripRequest(data, navigation)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MyTrip);
