import {StyleSheet} from 'react-native';
import Colors from '../../constants/Colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

const styles = StyleSheet.create({
  title: {
    fontSize: 20,
    color: 'white',
  },
  loadDetail: {
    backgroundColor: 'white',
    borderColor: 'gray',
    marginBottom: 6,
    marginLeft: '3%',
    width: '94.5%',
    marginTop: 8,
    borderRadius: 14,
    padding: 6,
    shadowRadius: 5,
    borderBottomWidth: 0.0,
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
  },
  listItem: {
    flexDirection: 'row',
    margin: 5,
    alignItems: 'center',
  },
  itemDelete: {
    width: 30,
    height: 30,
    alignItems: 'center',
  },
  addCard: {
    backgroundColor: 'transparent',
    position: 'absolute',
    bottom: wp('20%'),
    right: wp('10%'),
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
    // position: 'absolute',
    // bottom: 50,
    // right: 35,
    // backgroundColor: 'transparent',
    // height: wp('16%'),
    // width: wp('16%'),
    // borderRadius: 30,
    // alignItems: 'center',
    // justifyContent: 'center',
  },
  cardView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
  },
});
export default styles;
