import AccountDetail from './AccountDetail';
import {connect} from 'react-redux';
import {PaymentMethodListRequest} from './../../modules/GetPaymentMethodList/actions';
import {posDeleteRequest} from './../../modules/DeletePOS/actions';

const mapStateToProps = (state) => ({
  PaymentListData: state.paymentListReducer.paymentMethodData,
});
const mapDispatchToProps = (dispatch) => ({
  PaymentMethodListRequest: (navigation) =>
    dispatch(PaymentMethodListRequest(navigation)),
  posDeleteRequest: (posID, navigation) =>
    dispatch(posDeleteRequest(posID, navigation)),
});
export default connect(mapStateToProps, mapDispatchToProps)(AccountDetail);
