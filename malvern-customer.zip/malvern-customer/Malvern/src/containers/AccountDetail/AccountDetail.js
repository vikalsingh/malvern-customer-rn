import React, {Component} from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  FlatList,
  Alert,
} from 'react-native';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Images from '../../constants/Images';
import styles from './style';

export default class AccountDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
    };
    // const {navigation} = props;
    // this.didFocusListener = navigation.addListener(
    //   'focus',
    //   this.componentDidFocus,
    // );
  }
  componentDidMount() {
    this.getPaymentMethodsList();
  }
  componentWillUnmount() {
    // this.didFocusListener();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.PaymentListData !== this.props.PaymentListData) {
      this.setState({dataSource: this.props.PaymentListData}, () => {
        this.afterGetPaymentMethodList();
      });
    }
  }

  // componentDidFocus = (payload) => {};
  getPaymentMethodsList = () => {
    console.log(this.props.PaymentListData);
    this.setState({dataSource: this.props.PaymentListData});
  };

  afterGetPaymentMethodList() {
    console.log(this.props.PaymentListData);
    this.setState({
      dataSource: this.props.PaymentListData,
    });
  }

  addCardAction() {
    this.props.navigation.navigate('AddCard');
  }

  deleteCard(cardId) {
    Alert.alert(strings.Alert, strings.Areyousureyouwanttoremovethiscard, [
      {text: strings.Ok, onPress: () => this.deleteCard1(cardId)},
      {
        text: strings.Cancel,
        onPress: () => console.log('Cancel Pressed'),
        style: strings.Cancel,
      },
    ]);
  }

  deleteCard1(cardId) {
    this.props.posDeleteRequest(cardId, this.props.navigation);
  }

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  render() {
    return (
      <View style={{flex: 1, backgroundColor: 'white'}}>
        <RenderHeader
          back={true}
          title={strings.PaymentMethod}
          navigation={this.props.navigation}
        />
        <View style={{flex: 1, marginTop: 20}}>
          <FlatList
            data={this.state.dataSource}
            showsVerticalScrollIndicator={false}
            renderItem={({item}) => (
              <View style={styles.loadDetail}>
                <View style={styles.listItem}>
                  <View style={{width: '20%'}}>
                    <Image
                      resizeMode="contain"
                      style={{height: 40, width: 40}}
                      source={{uri: item.logo}}
                    />
                  </View>
                  {item.type === 'Cash' ? (
                    <Text style={{alignSelf: 'center'}}>
                      {strings.cashPayment}
                    </Text>
                  ) : item.type === 'Wallet' ? (
                    <View>
                      <Text style={{alignSelf: 'center'}}>{item.type}</Text>
                    </View>
                  ) : item.type === 'Paypal' ? (
                    <View>
                      <Text style={{alignSelf: 'center'}}>{item.type}</Text>
                    </View>
                  ) : (
                    <View style={styles.cardView}>
                      <View style={{alignSelf: 'center'}}>
                        <Text style={{marginRight: 20}}>
                          ***********{item.lastd}
                        </Text>
                      </View>
                      <TouchableOpacity
                        onPress={() => this.deleteCard(item._id)}
                        style={styles.itemDelete}>
                        <Image
                          resizeMode="contain"
                          style={{width: '100%', height: '100%'}}
                          source={require('../../../assets/deleteAddr.png')}
                        />
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              </View>
            )}
            keyExtractor={(item) => item._id}
          />
        </View>
        <TouchableOpacity
          onPress={() => this.addCardAction()}
          style={styles.addCard}>
          <Image
            resizeMode="contain"
            style={{height: '100%', width: '100%'}}
            source={Images.addIcon}
          />
        </TouchableOpacity>
      </View>
    );
  }
}
