import React from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  Keyboard,
  BackHandler,
  StyleSheet,
} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Geolocation from 'react-native-geolocation-service';
import { isEmpty } from '../../utils/CommonFunctions';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';
import Config from '../../constants/Config';
const regEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
import strings from '../../constants/languagesString';
import { RenderHeader2 } from '../../components/CustomComponent/renderHeader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  InputTextWithCountry,
  SignUpInputText,
  SignUpInputTextPassword,
} from '../../components/InputTexts/Inputext';
import {
  EnterAddressPopup,
  googleAutocomplete,
} from '../../components/Popups/Popup';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Fonts from '../../constants/Fonts';


import MapView, { Callout, PROVIDER_GOOGLE, Marker } from 'react-native-maps';


export default class Track extends React.Component {
  constructor(props) {
    super(props);

    const LATITUDE_DELTA = 0.009;
    const LONGITUDE_DELTA = 0.009;
    const LATITUDE = 18.7934829;
    const LONGITUDE = 98.9867401;

    this.state = {
      latitude: LATITUDE,
      longitude: LONGITUDE,
      error: null,
      termsCheck: false,
    };
  }

  async componentDidMount() {
    await Geolocation.getCurrentPosition(
      position => {
        console.log("********9", position);
        this.setState({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          error: null
        });
      },
      error => this.setState({ error: error.message }),
      { enableHighAccuracy: true, timeout: 200000, maximumAge: 1000 }
    );
  }

  // getCurrentLocation = async () => {
  //   this.getCurrentLocation();
  //   await Geolocation.getCurrentPosition(
  //     (position) => {
  //       this.setState({
  //         curLatitude: position.coords.latitude,
  //         curLongitude: position.coords.longitude,
  //       });
  //     },
  //     (error) => {
  //       this.setState({ error: error.message });
  //     },
  //     {
  //       enableHighAccuracy: true,
  //       timeout: 20000,
  //       maximumAge: 10000,
  //     },
  //   );
  // };

  getCurrentLocation = async () => {
    await Geolocation.watchPosition(
      position => {
        console.log('asdadas get cur...', position);
        this.setState(
          {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            // angle: angle,
            error: null,
          }
        );
      },
      error => this.setState({ error: error.message }),
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 1000,
        distanceFilter: 10,
      },
    );
  };



  render() {
    return (
      <View
        style={{
          flex: 1,
        }}>
        <MapView
          // provider={PROVIDER_GOOGLE}
          ref={(ref) => (this.mapsView = ref)}
          style={{ width: '100%', height: '100%', }}
          region={{
            latitude: this.state.latitude,
            longitude: this.state.longitude,
            latitudeDelta: 0.009,
            longitudeDelta: 0.009
          }}
        >
          <Marker
            // coordinate={this.getMapRegion()}
            coordinate={{
              latitude: this.state.latitude,
              longitude: this.state.longitude,
            }} />
        </MapView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  orTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: wp('8%'),
    marginTop: wp('8%'),
    marginHorizontal: wp('5.33%'),
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },

  signupTexts: {
    fontFamily: Fonts.Semibold,
    color: Colors.PrimaryColor,
  },
});
