import React from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  Keyboard,
  BackHandler,
  StyleSheet,
} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Geolocation from 'react-native-geolocation-service';
import { isEmpty } from '../../utils/CommonFunctions';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';
import Config from '../../constants/Config';
const regEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
import strings from '../../constants/languagesString';
import { RenderHeader2 } from './../../components/CustomComponent/renderHeader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  InputTextWithCountry,
  SignUpInputText,
  SignUpInputTextPassword,
} from '../../components/InputTexts/Inputext';
import {
  EnterAddressPopup,
  googleAutocomplete,
} from '../../components/Popups/Popup';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Fonts from '../../constants/Fonts';

export default class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      phone: this.props.route.params
        ? this.props.route.params.mobileNumber
        : '',
      password: '',
      confirmPassword: '',
      address: '',
      refCode: '',
      name: this.props.route.params ? this.props.route.params.name : '',
      email: this.props.route.params ? this.props.route.params.email : '',
      registerType: this.props.route.params
        ? this.props.route.params.registerType
        : '',
      countryCode:
        this.props.route.params && this.props.route.params.countryCode
          ? this.props.route.params.countryCode
          : '+44',
      countryName:
        this.props.route.params && this.props.route.params.countryName
          ? this.props.route.params.countryName
          : 'GB',
      predictions: [],
      showSuggestion: false,
      sourceLocation: '',
      addressModel: false,
      modalVisible: false,
      curLatitude: '',
      curLongitude: '',
      securePassword: true,
      confirmsecurePassword: true,
      verified: this.props.route.params
        ? this.props.route.params.verified
        : false,
      Langid: '',
      termsCheck: false,
    };
  }

  async componentDidMount() {
    if (
      this.props.route.params &&
      this.props.route.params.registerType === 'Social'
    ) {
      this.setState({
        countryCode: this.props.route.params && this.props.route.params.countryCode
          ? this.props.route.params.countryCode
          : '+44',
        countryName: this.props.route.params && this.props.route.params.countryName
          ? this.props.route.params.countryName
          : 'GB'
      });
    }
    // this.backHandler = BackHandler.addEventListener(
    //   'hardwareBackPress',
    //   this.handleBackButtonClick,
    // );
    setTimeout(() => this.getCurrentLocation(), 2000);

    const languageId = await AsyncStorage.getItem('languageId');
    this.setState({ Langid: languageId });
  }

  getCurrentLocation = async () => {
    await Geolocation.getCurrentPosition(
      (position) => {
        this.setState({
          curLatitude: position.coords.latitude,
          curLongitude: position.coords.longitude,
        });
      },
      (error) => {
        this.setState({ error: error.message });
      },
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 10000,
      },
    );
  };

  // handleBackButtonClick = () => {
  //   return true;
  // };

  goToLogin = () => {
    this.props.navigation.reset({
      routes: [{ name: Config.Login }],
    });
  };

  verifyCredentials = () => {
    const {
      name,
      email,
      password,
      confirmPassword,
      address,
      phone,
      termsCheck,
      countryCode,
    } = this.state;
    if (name == undefined || name == null || name.length <= 0) {
      alert(strings.nameAlert);
      return false;
    } else if (name.length < 3) {
      alert(strings.nameValidAlert);
      return false;
    } else if (email == undefined || email.length <= 0) {
      alert(strings.emailAlert);
      return false;
    } else if (!regEmail.test(email)) {
      alert(strings.validEmail);
      return false;
    } else if (isEmpty(password.trim())) {
      alert(strings.passwordAlert);
      return false;
    } else if (password.length < 6) {
      alert(strings.passwordLength);
      return false;
    } else if (phone.length < 8) {
      alert(strings.mobileLength);
      return false;
    } else if (password != confirmPassword) {
      alert(strings.passwordDoNotMatched);
      return false;
    } else if (!termsCheck) {
      alert(strings.acceptconditions);
      return false;
    }
    return true;
  };

  goToNextScreen() {
    if (this.verifyCredentials()) {
      const {
        name,
        phone,
        email,
        password,
        confirmPassword,
        address,
        Langid,
        refCode,
        countryCode,
      } = this.state;
      var data = {
        name: name,
        address: address,
        email: email,
        countryCode: countryCode,
        mobileNumber: phone,
        password: password,
        // languageId: Langid,
        // referalCodeFrom: refCode,
        gid: this.props.route.params.googleId,
        fbid: this.props.route.params.facebookId,
        appleid: this.props.route.params.appleId,
        OTP: this.props.route.params.otp,
        // profileImage: this.props.route.params.photo,
      };
      console.log('aaa', data);
      this.props.regRequest(data, this.props.navigation);
    }
  }

  async onChangeSource(sourceLocation) {
    this.setState({
      sourceLocation: sourceLocation,
    });
    var json = await googleAutocomplete(
      sourceLocation,
      this.state.curLatitude,
      this.state.curLongitude,
    );
    // console.log(JSON.stringify(json));
    try {
      var adress_data = json.predictions;
      this.setState({
        predictions: adress_data,
        showSuggestion: true,
        myaddress_list: adress_data,
      });

      if (json.predictions.length == 0) {
        this.setState({
          showSuggestion: false,
        });
      }
    } catch (err) {
      this.showAlert(err.message, 300);
    }
  }

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  async setSourceLocation(placeId, description) {
    Keyboard.dismiss();
    this.setState({
      sourceLocation: description,
      showSuggestion: false,
      selSourcePlaceId: placeId,
      address: description,
      modalVisible: false,
    });
  }

  openAddressModel(visible) {
    this.setState({ modalVisible: visible });
  }

  onSelectCountry = (country) => {
    console.log(country);
    this.setState({
      countryName: country.cca2,
      countryCode: '+' + country.callingCode[0],
      showFlag: false,
    });
  };

  render() {
    return (
      <View
        style={{
          flex: 1,
          marginTop: this.state.mainViewTop,
          backgroundColor: 'white',
        }}>
        <RenderHeader2
          title={strings.SignUp}
          navigation={this.props.navigation}
        />
        <KeyboardAwareScrollView
          style={[
            styles.lowerView,
            {
              paddingTop: this.state.scrollPadding,
              backgroundColor: Colors.background,
            },
          ]}>
          <SignUpInputText
            header={strings.Name}
            icon={Images.profileIcon}
            onChangeText={(name) => this.setState({ name })}
            text={this.state.name}
          />

          <SignUpInputText
            header={strings.Email}
            icon={Images.WhiteEmail}
            onChangeText={(email) => this.setState({ email })}
            keyboardType={'email-address'}
            text={this.state.email}
          />

          <InputTextWithCountry
            header={strings.Password}
            cnName={this.state.countryName}
            cnCode={this.state.countryCode}
            showFlag={this.state.showFlag}
            editable={!this.state.verified}
            onSelect={(country) => this.onSelectCountry(country)}
            onShowFlag={() => this.setState({ showFlag: true })}
            phone={this.state.phone}
            onChangePhone={(text) => this.setState({ phone: text })}
          />

          <SignUpInputTextPassword
            header={strings.Password}
            icon={Images.passwordIcon}
            isPassword={true}
            onChangeText={(confirmPassword) => this.setState({ confirmPassword })}
            text={this.state.confirmPassword}
            showEye={this.state.securePassword}
            onClickEye={() =>
              this.setState({ securePassword: !this.state.securePassword })
            }
          />

          <SignUpInputTextPassword
            header={strings.confirmPassword}
            icon={Images.passwordIcon}
            isPassword={true}
            onChangeText={(password) => this.setState({ password })}
            text={this.state.password}
            showEye={this.state.confirmsecurePassword}
            onClickEye={() =>
              this.setState({ confirmsecurePassword: !this.state.confirmsecurePassword })
            }
          />

          <View
            style={{
              width: '85%',
              alignSelf: 'center',
              marginTop: '6%',
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <TouchableOpacity
              onPress={() =>
                this.setState({ termsCheck: !this.state.termsCheck })
              }>
              <Image
                source={
                  this.state.termsCheck ? Images.Check : Images.unchecked
                }
                style={{
                  width: 20,
                  height: 20,
                  tintColor: Colors.PrimaryColor,
                }}
              />
            </TouchableOpacity>
            <Text style={{ marginLeft: 8 }}>
              {'Accept the GDPR Compliance '}
              <Text
              style={{ color: Colors.PrimaryColor }}
              onPress={() =>
                this.props.navigation.navigate(Config.TermsConditions)
              }
              >
                {'Terms & Conditions, Privacy Policy, '}
              </Text>
              {' and '}
              <Text
              // style={{ color: Colors.PrimaryColor }}
              // onPress={() =>
              //   this.props.navigation.navigate(Config.PrivacyPolicy)
              // }
              >
                {'Cookie Policy'}
              </Text>
            </Text>
          </View>



          {/* <SignUpInputText
            header={strings.Address}
            icon={Images.WhiteAddress}
            onChangeText={(address) => this.setState({address})}
            onTouchable={true}
            onTouchStart={() => this.openAddressModel()}
            text={this.state.address}
          /> */}

          {/* <SignUpInputText
            header={strings.Refferal}
            icon={Images.referralIc}
            onChangeText={(refCode) =>
              this.setState({refCode: refCode.toUpperCase()})
            }
            text={this.state.refCode}
          /> */}

          <View style={styles.arrowTile}>
            <TouchableOpacity onPress={() => this.goToNextScreen()}>
              <Image style={styles.tickIcon} source={Images.rightImg} />
            </TouchableOpacity>
          </View>

          <Text style={styles.noAccountText}>
            {strings.Alreadyhaveanaccount}
            {'  '}
            <Text onPress={this.goToLogin} style={styles.signupTexts}>
              {strings.SignIn}
            </Text>
          </Text>

          <View style={styles.orTile} />

          <EnterAddressPopup
            isOpen={this.state.modalVisible}
            onClose={() => this.setState({ modalVisible: false })}
            sourceLocation={this.state.sourceLocation}
            onChangeSource={(sourceLocation) =>
              this.onChangeSource(sourceLocation)
            }
            showSuggestion={this.state.showSuggestion}
            predictions={this.state.predictions}
            setSourceLocation={(place_id, description) =>
              this.setSourceLocation(place_id, description)
            }
          />
        </KeyboardAwareScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  orTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: wp('8%'),
    marginTop: wp('8%'),
    marginHorizontal: wp('5.33%'),
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  lowerView: {
    backgroundColor: Colors.White,
    width: wp('100%'),
    height: 'auto',
    marginTop: 0,
  },
  arrowTile: {
    width: 'auto',
    height: 75,
    backgroundColor: 'transparent',
    alignSelf: 'flex-end',
    marginTop: hp('4%'),
    right: 25,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  tickIcon: {
    height: 60,
    width: 60,
    marginTop: wp('10%'),
    resizeMode: 'contain',
  },
  noAccountText: {
    color: Colors.colorLight,
    alignSelf: 'center',
    marginTop: wp('20%'),
    fontFamily: Fonts.Thin,
    fontSize: wp('4%'),
  },
  signupTexts: {
    fontFamily: Fonts.Semibold,
    color: Colors.PrimaryColor,
  },
});
