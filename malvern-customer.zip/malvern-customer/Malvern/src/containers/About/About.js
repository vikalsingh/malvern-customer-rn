import React, {Component} from 'react';
import {StyleSheet, View} from 'react-native';
import {WebView} from 'react-native-webview';
import {DrawerActions} from '@react-navigation/native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {strings} from '../../constants/languagesString';
import Colors from '../../constants/Colors';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Config from '../../constants/Config';

export default class About extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      message: '',
    };
    const {navigation} = props;
    this.didFocusListener = navigation.addListener(
      'focus',
      this.componentDidFocus,
    );
  }

  componentDidFocus = (payload) => {
    this.setState({name: ''});
  };

  componentWillUnmount() {
    this.didFocusListener();
  }

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  afterSupportAPI() {
    this.props.navigation.goBack();
  }

  sendMessage() {
    this.props
      .supportAPI(this.state.name, this.state.message)
      .then(() => this.afterSupportAPI())
      .catch((e) => this.showAlert(e.message, 300));
  }

  showAlert(message, duration) {
    this.setState({autoLogin: false});
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  openDrawerClick() {
    this.props.navigation.dispatch(DrawerActions.openDrawer());
  }

  render() {
    //StatusBar.setHidden(true, 'none');

    return (
      <View style={{flex: 1, backgroundColor: Colors.White}}>
        <RenderHeader
          back={true}
          title={strings.AboutUs}
          navigation={this.props.navigation}
        />

        <View style={styles.gridViewBackground}>
          <View
            style={{
              width: '100%',
              flex: 1,
              overflow: 'hidden',
              marginBottom: 100,
              backgroundColor: 'white',
            }}>
            <WebView
              source={{
                uri: Config.URL + Config.aboutUsUrl,
              }}
              style={{
                width: '100%',
                height: '100%',
                backgroundColor: 'white',
              }}
            />
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },

  headerView: {
    height: 60,
    width: '100%',
    backgroundColor: '#1c1c1a',
    borderColor: '#0082cb',
    borderWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    color: 'white',
  },
  gridViewBackground: {
    height: '100%',
    width: '100%',
    marginTop: 10,
    borderColor: '#f5f6f8',
    borderWidth: 0,
    backgroundColor: 'white',
  },
  backTouchable: {
    position: 'absolute',
    width: 50,
    height: 60,
    top: 0,
    backgroundColor: 'transparent',
    left: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    width: 22,
    height: 22,
    top: 0,
    left: 0,
    backgroundColor: 'transparent',
  },
  tileIcon: {
    width: 20,
    height: 40,
    marginLeft: 20,
    marginTop: -5,
  },
  tile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: wp('13.33%'),
    marginTop: 0,
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 1.0,
    borderColor: '#818e97',
  },
  searchTextInput: {
    height: 'auto',
    width: '100%',
    paddingHorizontal: 20,
    backgroundColor: 'transparent',
    borderColor: 'gray',
    borderRadius: 0,
    fontSize: wp('4.8%'),
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
  },
  touchableArrow: {
    backgroundColor: '#375064',
    position: 'absolute',
    right: 0,
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  arrowTile: {
    backgroundColor: 'transparent',
    width: '100%',
    height: 50,
    marginTop: 20,

    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0,
    borderColor: '#818e97',
  },

  tileFeedback: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: 120,
    marginTop: 30,
    marginHorizontal: 20,

    borderBottomWidth: 1.0,
    borderColor: '#818e97',
    borderRadius: 5,
  },
});
