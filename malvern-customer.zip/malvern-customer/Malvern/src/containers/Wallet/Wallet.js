import React, {Component} from 'react';
import {View, Text, FlatList, Image, ActivityIndicator} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {strings} from '../../constants/languagesString';
import styles from './style';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Images from '../../constants/Images';
import Fonts from '../../constants/Fonts';
import moment from 'moment';
import Colors from '../../constants/Colors';
import {TouchableOpacity} from 'react-native-gesture-handler';
import Config from '../../constants/Config';

export default class Wallet extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      walletText: '',
      walletBalance: '0',
      refreshing: true,
      currency: '',
    };
    this.didFocusListener = this.props.navigation.addListener(
      'focus',
      this.componentDidFocus,
    );
  }
  componentDidFocus = () => {
    // this.getWalletList();
    this.getWalletBalance();
  };

  componentDidMount() {
    let currency = this.props.contactsData.App_Settings.Admin_Currency_Code;
    this.setState({currency: currency});
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.ProfileData !== this.props.ProfileData) {
      console.log(this.props.ProfileData.walletCredit);
      this.setState({
        walletBalance: this.props.ProfileData.userWallet.walletAmount,
      });
    }
    if (prevProps.WalletList !== this.props.WalletList) {
      console.log('this.props.WalletList');

      console.log(this.props.WalletList);
      this.setState({
        dataSource: this.props.WalletList.reverse(),
        refreshing: false,
      });
    }
  }

  getWalletBalance = () => {
    this.props.getWalletListRequest(this.props.navigation);
    this.props.profileRequest(this.props.navigation);
    // console.log('Wallet ', this.props.ProfileData);
    // this.setState({
    //   walletBalance: this.props.ProfileData.userWallet.walletAmount,
    // });
  };

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  render() {
    return (
      <View style={styles.container}>
        <RenderHeader
          title={strings.myWallet}
          navigation={this.props.navigation}
        />
        <View style={styles.balanceHeaderView}>
          <Text style={styles.balanceTxt}>{strings.balance}</Text>
          <Text style={styles.balaceValueTxt}>
            {this.state.currency +
              ' ' +
              parseFloat(this.state.walletBalance).toFixed(2)}
          </Text>
        </View>
        <View style={[styles.balanceHeaderView, {alignItems: 'flex-start'}]}>
          <Text style={styles.balanceTxt} />
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate(Config.AddAmtWallet)}
            style={{backgroundColor: Colors.PrimaryColor, borderRadius: 25}}>
            <Text style={styles.balaceValueTxt1}>{'Add balance'}</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.sepratorLine} />

        <FlatList
          data={this.state.dataSource}
          style={{marginBottom: 40}}
          showsVerticalScrollIndicator={false}
          renderItem={({item, index}) => (
            <View
              style={{
                width: '100%',
                borderColor: 'gray',
                borderBottomWidth: 1,
                padding: 15,
                paddingLeft: '5%',
                paddingRight: '5%',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <Image
                  source={
                    item.type == 'redeem' ? Images.debit_ic : Images.credit_ic
                  }
                  style={{width: 30, height: 30}}
                />
                <View style={{marginLeft: 15}}>
                  <Text style={{fontSize: 16, fontFamily: Fonts.Semibold}}>
                    {item.type == 'addmoney'
                      ? 'Money Added'
                      : item.type == 'earned'
                      ? 'Earned '
                      : 'Redeem '}
                  </Text>
                  <Text
                    style={{
                      fontSize: 14,
                      fontFamily: Fonts.Regular,
                      color: 'gray',
                    }}>
                    {moment
                      .parseZone(item.createdAt)
                      .format('DD/MM/YYYY hh:mm')}
                  </Text>
                </View>
              </View>
              <View>
                <Text style={{fontSize: 16, fontFamily: Fonts.Semibold}}>
                  {item.type == 'addmoney'
                    ? '+' + item.addMoney
                    : item.type == 'earned'
                    ? '+' + item.earnedPoints
                    : '-' + item.redeemPoints}
                  {' ' + this.state.currency}
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    fontFamily: Fonts.Regular,
                    color: 'gray',
                  }}>
                  Transfer
                </Text>
              </View>
            </View>
          )}
          keyExtractor={(item) => item._id.toString()}
          ListEmptyComponent={
            <View style={{marginTop: 20}}>
              {this.state.refreshing ? (
                <ActivityIndicator size="large" />
              ) : (
                <Text style={styles.NocoupanAvaibleText}>
                  {strings.NoTransaction}
                </Text>
              )}
            </View>
          }
        />
      </View>
    );
  }
}
