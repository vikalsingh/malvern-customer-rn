import {StyleSheet, Platform} from 'react-native';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  balanceHeaderView: {
    height: 80,
    width: '90%',
    backgroundColor: 'transparent',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  balanceTxt: {
    fontSize: wp('6.5%'),
    fontFamily: Fonts.Semibold,
  },
  balaceValueTxt: {
    fontSize: wp('6.5%'),
    fontFamily: Fonts.Semibold,
    color: Colors.PrimaryColor,
  },
  balaceValueTxt1: {
    fontSize: 18,
    fontFamily: Fonts.Semibold,
    color: Colors.White,
    paddingLeft: 10,
    paddingRight: 10,
    paddingTop: 8,
    paddingBottom: 8,
  },
  NocoupanAvaibleText: {
    width: wp('100%'),
    marginTop: 20,
    textAlign: 'center',
  },
  sepratorLine: {
    borderBottomWidth: 1,
    borderColor: Colors.graylight,
  },
});
export default styles;
