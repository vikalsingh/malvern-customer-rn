import Wallet from './Wallet';
import {
  addWalletBalanceRequest,
  getWalletListRequest,
} from './../../modules/AddWallet/actions';
import {connect} from 'react-redux';
import {profileRequest} from './../../modules/GetProfile/actions';

const mapStateToProps = (state) => ({
  PaymentListData: state.paymentListReducer.paymentMethodData,
  ProfileData: state.GetProfileReducer.profileData,
  WalletList: state.addWalletBalanceReducer.walletList,
  contactsData: state.getContactsReducer.contactsData,
});

const mapDispatchToProps = (dispatch) => ({
  addWalletBalanceRequest: (count, item_id, navigation) =>
    dispatch(addWalletBalanceRequest(count, item_id, navigation)),
  getWalletListRequest: (navigation) =>
    dispatch(getWalletListRequest(navigation)),
  profileRequest: (navigation) => dispatch(profileRequest(navigation)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Wallet);
//export default Wallet;
