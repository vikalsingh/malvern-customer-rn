import Coupon from './Coupon';
import {promoListRequest} from '../../modules/PromoCodes/actions';
import {connect} from 'react-redux';
const mapStateToProps = (state) => ({
  promoCodesData: state.promoCodesReducer.promoListData,
});
const mapDispatchToProps = (dispatch) => ({
  promoListRequest: () => dispatch(promoListRequest()),
});
export default connect(mapStateToProps, mapDispatchToProps)(Coupon);
