import React, {Component} from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ImageBackground,
  Image,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import moment from 'moment';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';

export default class Coupon extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      dataSourcePast: [],
      selTab: '0',
      underLineLeft: 0,
      termsModal: false,
      terms: '',
    };
    const {navigation} = props;
    this.didFocusListener = navigation.addListener(
      'focus',
      this.componentDidFocus,
    );
  }

  componentWillUnmount() {
    this.didFocusListener();
  }
  componentDidFocus = (payload) => {
    this.getData();
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.promoCodesData !== this.props.promoCodesData) {
      var data = this.props.promoCodesData;
      this.afterGetData(data);
    }
  }
  afterGetData = (data) => {
    console.log(data);
    this.setState({
      dataSource: data.reverse(),
    });
  };

  getData = () => {
    this.props.promoListRequest();
  };

  getExpiryDate(dat) {
    var newDate = moment(dat).format('DD MMM, YYYY');
    var newDate1 = strings.validUntill + newDate;
    return newDate1;
  }

  openTermsModal(terms) {
    this.setState({termsModal: true, terms: terms});
  }

  closeTermsModal() {
    this.setState({termsModal: false});
  }

  render() {
    return (
      <View style={{flex: 1}}>
        <RenderHeader
          back={true}
          title={strings.Promotions}
          navigation={this.props.navigation}
        />

        {this.state.dataSource.length > 0 ? (
          <FlatList
            data={this.state.dataSource}
            style={{marginBottom: hp('10%')}}
            showsVerticalScrollIndicator={false}
            renderItem={({item}) => (
              <View style={styles.loadDetail}>
                <ImageBackground
                  style={{height: 135, padding: 12, backgroundColor: 'white'}}
                  resizeMode="stretch">
                  <Text style={styles.coupanNameTxt}>{item.name}</Text>
                  <Text style={styles.exipryDateTxt}>
                    {this.getExpiryDate(item.upto)}
                  </Text>
                  <Text style={styles.promoCodeText}>
                    <Text>Code : </Text>
                    {item.promocode}
                  </Text>
                  {/* <TouchableOpacity
                    onPress={() => this.openTermsModal(item.TC)}
                    style={{position: 'absolute', bottom: 10, right: 10}}>
                    <Text style={styles.termsConTxt}>{strings.TC}</Text>
                  </TouchableOpacity> */}
                </ImageBackground>
              </View>
            )}
            keyExtractor={(item) => item._id.toString()}
          />
        ) : (
          <Text style={styles.NocoupanAvaibleText}>
            {strings.NoCoupanvailable}
          </Text>
        )}

        {this.state.termsModal ? (
          <View style={styles.modalContainer}>
            <View style={styles.texbtView}>
              <Text style={styles.termsText}>{this.state.terms}</Text>
              <View style={{height: 10}} />
              <TouchableOpacity
                onPress={() => this.closeTermsModal()}
                style={styles.cancelBtView}>
                <Image
                  resizeMode="contain"
                  style={styles.redCancelErrorIcon}
                  source={Images.iconCan}
                />
              </TouchableOpacity>
            </View>
          </View>
        ) : null}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  exipryDateTxt: {
    fontFamily: Fonts.Regular,
    fontSize: 16,
    marginLeft: 30,
    marginTop: 10,
  },
  coupanNameTxt: {
    color: Colors.Black,
    fontSize: 18,
    fontFamily: Fonts.Semibold,
    marginLeft: 30,
    marginTop: 10,
  },
  promoCodeText: {
    fontSize: 16,
    fontFamily: Fonts.Regular,
    marginLeft: 30,
  },
  termsConTxt: {
    fontFamily: Fonts.Semibold,
    fontSize: 16,
  },
  title: {
    fontSize: 20,
    color: 'white',
  },
  loadDetail: {
    backgroundColor: 'transparent',
    borderColor: 'gray',
    marginLeft: '2%',
    width: '90%',
    marginTop: 20,
    borderRadius: 5,
    shadowRadius: 5,
    borderBottomWidth: 0.0,
    justifyContent: 'center',
    alignSelf: 'center',
  },
  list: {
    justifyContent: 'center',
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  NocoupanAvaibleText: {
    width: wp('100%'),
    marginTop: 20,
    textAlign: 'center',
  },
  modalContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: '#000000',
    opacity: 0.8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  texbtView: {
    backgroundColor: 'white',
    borderRadius: 5,
    width: wp('80%'),
    height: 'auto',
  },
  termsText: {
    width: 'auto',
    fontFamily: Fonts.Regular,
    color: 'black',
    textAlign: 'center',
    padding: 10,
    fontSize: wp('4.33%'),
  },
  cancelBtView: {
    right: -10,
    position: 'absolute',
    marginTop: -10,
    height: 30,
    width: 30,
  },
  redCancelErrorIcon: {
    height: 30,
    width: 30,
    tintColor: 'red',
  },
});
