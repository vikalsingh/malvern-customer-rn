import React, {Component} from 'react';
import {
  View,
  Image,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  Platform,
  Alert,
} from 'react-native';
import Contacts from 'react-native-contacts';
import {PermissionsAndroid} from 'react-native';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import Images from '../../constants/Images';
import styles from './style';
import {showAlert} from '../../utils/CommonFunctions';

export default class AddContacts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      contacts: [],
      text: '',
      arrayHooder: [],
    };
  }

  componentDidMount() {
    if (Platform.OS === 'ios') {
      this.getIOSContacts();
    } else if (Platform.OS === 'android') {
      this.requestContactPermission();
      // this.getAllContacts();
    }
  }

  getIOSContacts() {
    Contacts.getAll((err, contacts) => {
      if (err) {
        if (err == 'denied') {
          Alert.alert(
            strings.AccessDenied,
            strings.Pleasegrantpermissiontoaccesscontactssettings,
            [
              {
                text: strings.Ok,
                onPress: () => this.props.navigation.goBack(),
              },
            ],
          );
        } else {
          throw err;
        }
      }

      contacts.sort((a, b) =>
        a.givenName !== b.givenName ? (a.givenName < b.givenName ? -1 : 1) : 0,
      );
      this.setState({contacts, arrayHooder: contacts});
    });
  }

  async requestContactPermission() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
        {
          title: strings.Contacts,
          message: strings.Thisappwouldliketoviewyourcontacts,
          buttonNegative: strings.Cancel,
          buttonPositive: strings.Ok,
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.getAllContacts();
      } else {
      }
    } catch (err) {}
  }

  getAllContacts() {
    Contacts.getAll((err, contacts) => {
      if (err === 'denied') {
      } else {
        console.log(contacts);
        contacts.sort((a, b) =>
          a.givenName !== b.givenName
            ? a.givenName < b.givenName
              ? -1
              : 1
            : 0,
        );
        const result = contacts.filter(ct => ct.phoneNumbers.length > 0);
        this.setState({contacts: result, arrayHooder: result});
      }
    });
  }

  showAlert(message, duration) {
    this.setState({autoLogin: false});
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  addContact(namestr, number) {
    this.props.addContactRequest(namestr, number, this.props.navigation);
  }

  selectContact(item) {
    console.log('item', item);
    if (
      item != undefined &&
      item.phoneNumbers != undefined &&
      item.phoneNumbers.length != 0 &&
      item.phoneNumbers[0].number != undefined
    ) {
      var number = item.phoneNumbers[0].number;
      var namedt =
        item.familyName != '' &&
        item.familyName != null &&
        item.familyName != undefined
          ? item.givenName + ' ' + item.familyName
          : item.givenName;
      this.addContact(namedt, number);
    } else {
      showAlert(strings.somewrongcontact, 300);
    }
  }

  SearchFilterFunction(text) {
    const newData = this.state.arrayHooder.filter(function (item) {
      let name = item.givenName + ' ' + item.familyName;
      const itemData = name ? name.toUpperCase() : ''.toUpperCase();
      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    this.setState({
      contacts: newData,
      text: text,
    });
  }

  render() {
    return (
      <View style={styles.container}>
        <RenderHeader
          back={true}
          title={strings.addNewContact}
          navigation={this.props.navigation}
        />
        <View style={styles.gridViewBackground}>
          <TextInput
            style={{
              height: 40,
              width: '95%',
              backgroundColor: '#f1f1f1',
              alignSelf: 'center',
              marginTop: 10,
              padding: 10,
            }}
            onChangeText={(text) => this.SearchFilterFunction(text)}
            value={this.state.text}
            underlineColorAndroid="transparent"
            placeholder={strings.searchHere}
          />
          <View style={{flex: 1}}>
            <FlatList
              data={this.state.contacts}
              renderItem={({item, index}) => (
                <TouchableOpacity
                  onPress={() => this.selectContact(item)}
                  style={{
                    flexDirection: 'row',
                    padding: 10,
                    marginBottom:
                      this.state.contacts.length - 1 == index ? 140 : 0,
                  }}>
                  <Image
                    resizeMode="contain"
                    style={{height: 50, width: 50}}
                    source={Images.dummyUser}
                  />
                  <View style={{justifyContent: 'center'}}>
                    {item.familyName != '' &&
                    item.familyName != null &&
                    item.familyName != undefined ? (
                      <Text style={styles.contact_details}>
                        {`${item.givenName + ' ' + item.familyName} `}
                      </Text>
                    ) : (
                      <Text style={styles.contact_details}>
                        {`${item.givenName} `}
                      </Text>
                    )}
                  </View>
                </TouchableOpacity>
              )}
              numColumns={1}
              keyExtractor={(item, index) => index.toString()}
            />
          </View>
        </View>
      </View>
    );
  }
}
