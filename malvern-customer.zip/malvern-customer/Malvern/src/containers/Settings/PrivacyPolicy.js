import React from 'react';
import {StyleSheet, View, Dimensions} from 'react-native';
import {WebView} from 'react-native-webview';
import {strings} from '../../constants/languagesString';
import Config from '../../constants/Config';
import {RenderHeaderBack} from './../../components/CustomComponent/renderHeader';
const {width, height} = Dimensions.get('window');

export default function PrivacyPolicy(props) {
  return (
    <View style={{flex: 1, backgroundColor: '#ffffff'}}>
      <RenderHeaderBack
        title={strings.PrivacyPolcies}
        onBack={() => props.navigation.goBack()}
      />

      <View style={styles.viewFWebView}>
        <WebView
          source={{
            uri: Config.URL + Config.privacyURL,
          }}
          style={styles.webview}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  viewFWebView: {
    width: '100%',
    flex: 0.9,
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  webview: {
    width: width,
    height: height,
  },
});
