import React from 'react';
import {StyleSheet, View, Text} from 'react-native';
import {WebView} from 'react-native-webview';
import {strings} from '../../constants/languagesString';
import Config from '../../constants/Config';
import {RenderHeaderBack} from './../../components/CustomComponent/renderHeader';

export default function TermsConditions(props) {
  return (
    <View style={{flex: 1, backgroundColor: '#ffffff'}}>
      <RenderHeaderBack
        title={strings.TermsConditions}
        onBack={() => props.navigation.goBack()}
      />

      <View style={styles.viewFWebView}>
        <WebView
          source={{
            uri: Config.URL + Config.termsAndConditionsURL,
          }}
          style={styles.webview}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  viewFWebView: {
    width: '100%',
    flex: 0.9,
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  webview: {
    width: '100%',
    height: '100%',
    backgroundColor: 'white',
  },
});
