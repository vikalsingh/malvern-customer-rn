import React from 'react';
import {View, Image, Text, TouchableOpacity} from 'react-native';
import {RenderHeaderBack} from './../../components/CustomComponent/renderHeader';
import Config from '../../constants/Config';
import Images from '../../constants/Images';
import styles from './style';
import AsyncStorage from '@react-native-async-storage/async-storage';
import strings from '../../constants/languagesString';
import {SignUpInputTextPassword} from '../../components/InputTexts/Inputext';
import {isEmpty} from '../../utils/CommonFunctions';

export default class Password extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      password: '',
      securePassword: true,
      fcmToken: 'none',
    };
  }

  async componentDidMount() {
    let fcmToken = await AsyncStorage.getItem('fcmToken');
    if (fcmToken != null) {
      this.setState({
        fcmToken: fcmToken,
      });
    }
    console.log('----fcm-----', fcmToken);
  }

  forgotPassword() {
    this.props.navigation.navigate(Config.VerifyOTP, {
      mobileNumber: this.props.route.params.mobileNumber,
      forgot: true,
      countryCode: this.props.route.params.countryCode,
    });
  }

  onLoginRequest = () => {
    const {password, fcmToken} = this.state;

    if (isEmpty(password.trim())) {
      alert(strings.passwordAlert);
      return false;
    } else {
      const {loginRequest, navigation, route} = this.props;

      console.log(route.params.countryCode, route.params.mobileNumber);

      console.log(
        route.params.countryCode,
        route.params.mobileNumber,
        password,
        fcmToken,
      );

      loginRequest(
        route.params.countryCode,
        route.params.mobileNumber,
        password,
        fcmToken,
        navigation,
      );
    }
  };

  onGoBack = () => {
    this.props.navigation.reset({
      routes: [{name: Config.Login}],
    });
  };

  render() {
    return (
      <View style={styles.container}>
        <RenderHeaderBack title={strings.Login} onBack={this.onGoBack} />
        <View style={styles.lowerView}>
          <SignUpInputTextPassword
            header={strings.Password}
            icon={Images.passwordIcon}
            onChangeText={(password) => this.setState({password})}
            text={this.state.password}
            showEye={this.state.securePassword}
            onClickEye={() =>
              this.setState({securePassword: !this.state.securePassword})
            }
          />

          <View style={styles.forgotTile}>
            <TouchableOpacity
              style={styles.touchableForgotPassword}
              onPress={() => this.forgotPassword()}>
              <Text style={styles.forgot}>
                {' '}
                {strings.ForgotPassword.toUpperCase()}{' '}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.bottomView}>
            <View style={styles.arrowTile}>
              <TouchableOpacity
                style={styles.touchableArrow}
                onPress={this.onLoginRequest}>
                <Image style={styles.arrowIcon} source={Images.rightImg} />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    );
  }
}
