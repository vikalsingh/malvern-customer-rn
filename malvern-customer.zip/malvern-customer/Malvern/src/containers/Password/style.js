import {StyleSheet} from 'react-native';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.White,
  },
  forgot: {
    color: Colors.FontDarkColor,
    fontSize: wp('3.5%'),
    fontFamily: Fonts.Semibold,
  },
  lowerView: {
    flex: 1,
    marginTop: 0,
  },
  forgotTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: 40,
    marginTop: 10,
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0,
    borderColor: '#818e97',
  },
  touchableForgotPassword: {
    backgroundColor: 'transparent',
    height: 30,
  },
  arrowTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: wp('16%'),
    marginTop: wp('8%'),
    marginBottom: 10,
    alignItems: 'center',
    flexDirection: 'row',
    marginHorizontal: wp('5.33%'),
    borderBottomWidth: 0,
    // borderColor: '#818e97',
  },
  touchableArrow: {
    backgroundColor: 'transparent',
    position: 'absolute',
    right: 0,
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  title: {
    fontSize: wp('4.8%'),
    color: 'white',
    fontFamily: Fonts.Semibold,
  },
  bottomView: {position: 'absolute', bottom: 40, width: '100%'},
});
export default styles;
