import {StyleSheet} from 'react-native';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';
const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: 'white'},
  title: {
    fontSize: 20,
    color: 'white',
  },
  listContainer: {width: '100%', height: 100},
  listItem: {
    // borderBottomWidth: 1,
    borderColor: 'grey',
    flexDirection: 'row',
    padding: 10,
    // height: 55,
    marginTop: 5,
    justifyContent: 'space-between',
  },
  deleteButton: {
    width: 80,
    height: 30,
    alignSelf: 'center',
  },
  gridViewBackground: {
    flex: 1,
    marginTop: 0,
    marginBottom: -50,
    borderWidth: 0.0,
  },
  arrowTile: {
    backgroundColor: 'transparent',
    height: wp('16%'),
    position: 'absolute',
    right: wp('5.33%'),
    left: wp('5.33%'),
    bottom: wp('18%'),
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 0,
    borderColor: 'blue',
  },
  touchableArrow: {
    position: 'absolute',
    right: 0,
    height: wp('16%'),
    width: wp('16%'),
    bottom: 0,
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
  },
  txtNoLoads: {
    marginTop: 60,
    width: '100%',
    textAlign: 'center',
  },
  contact_details: {
    fontFamily: Fonts.Semibold,
    color: 'black',
    marginLeft: 15,
    fontSize: wp('4.8%'),
  },
  contact_details1: {
    fontFamily: Fonts.Regular,
    color: 'black',
    marginLeft: 15,
    fontSize: wp('3.8%'),
  },
});
export default styles;
