import React, {Component} from 'react';
import {
  View,
  Image,
  Text,
  FlatList,
  TouchableOpacity,
  Alert,
  PermissionsAndroid,
} from 'react-native';
import Contacts from 'react-native-contacts';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Images from '../../constants/Images';
import styles from './style';
import { getConfiguration } from '../../utils/configuration';

export default class Emergency extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      ifPermission: false,
    };
    const {navigation} = props;
    this.didFocusListener = navigation.addListener(
      'focus',
      this.componentDidFocus,
    );
  }

  componentDidFocus = () => {
    const data = {
      customerid: getConfiguration('user_id'),
      tken: getConfiguration('token')
    }
    this.props.contactListRequest(data, this.props.navigation);
    this.setState({dataSource: this.props.contactListData});
    this.checkPermission();
  };

  componentWillUnmount() {
    this.didFocusListener();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.contactListData !== this.props.contactListData) {
      this.setState({dataSource: this.props.contactListData}, () => {
        this.afterGetContactList();
      });
    }
  }
  afterGetContactList = () => {
    this.setState({
      dataSource: this.props.contactListData,
    });
  };

  checkPermission() {
    if (Platform.OS === 'ios') {
      console.log("hereee")
      Contacts.getAll((err, contacts) => {
        console.log("hereee2")
        if (err) {
          if (err == 'denied') {
            Alert.alert(
              strings.AccessDenied,
              strings.Pleasegrantpermissiontoaccesscontactssettings,
              [
                {
                  text: strings.Ok,
                  onPress: () => this.props.navigation.goBack(),
                },
              ],
            );
          } else {
            throw err;
          }
        } else {
          // contacts returned
          this.setState({contacts, ifPermission: true});
        }
      });
    } else if (Platform.OS === 'android') {
      this.requestContactPermission();
    }
  }

  getAndroidContacts() {
    Contacts.getAll((err, contacts) => {
      console.log('per:', err);
      if (err === 'denied') {
      } else {
        
        this.setState({contacts});
      }
    });
  }

  async requestContactPermission() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
        {
          title: strings.Contacts,
          message: strings.Thisappwouldliketoviewyourcontacts,
          buttonNegative: strings.Cancel,
          buttonPositive: strings.Ok,
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.getAndroidContacts();
        this.setState({ifPermission: true});
      } else {
      }
    } catch (err) {
      console.warn(err);
    }
  }

  addEmergency() {
    console.log(this.state.ifPermission);
    if (this.state.ifPermission) {
      this.props.navigation.navigate('AddContacts');
    } else {
      this.checkPermission();
    }
  }

  deleteContact(item) {
    this.props.deleteContactRequest(item._id, this.props.navigation);
  }

  render() {
    return (
      <View style={styles.container}>
        <RenderHeader
          back={true}
          title={strings.EmergencyContact}
          navigation={this.props.navigation}
        />

        <View style={styles.gridViewBackground}>
          {this.state.dataSource != null && this.state.dataSource != '' ? (
            <FlatList
              style={styles.listContainer}
              data={this.state.dataSource}
              renderItem={({item}) => (
                <View style={styles.listItem}>
                  <View style={{flexDirection: 'row'}}>
                    <Image
                      resizeMode="contain"
                      style={{height: 50, width: 50}}
                      source={Images.dummyUser}
                    />
                    <View>
                      <Text style={styles.contact_details}>
                        {`${item.name} `}
                      </Text>
                      <Text style={styles.contact_details1}>
                        {`${item.contactNumber} `}
                      </Text>
                    </View>
                  </View>
                  <TouchableOpacity
                    onPress={() => this.deleteContact(item)}
                    style={styles.deleteButton}>
                    <Image
                      resizeMode="contain"
                      style={{height: 30, width: 30}}
                      source={Images.deleteAddr}
                    />
                  </TouchableOpacity>
                </View>
              )}
              keyExtractor={(item) => item._id.toString()}
            />
          ) : (
            <Text style={styles.txtNoLoads}>{strings.NoEmergencyContacts}</Text>
          )}
        </View>

        <View style={styles.arrowTile}>
          <TouchableOpacity
            style={styles.touchableArrow}
            onPress={() => this.addEmergency()}>
            <Image
              resizeMode="contain"
              style={styles.arrowIcon}
              source={Images.addIcon}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}
