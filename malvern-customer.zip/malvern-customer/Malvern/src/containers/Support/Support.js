import React, {Component} from 'react';
import {StyleSheet, View, Text} from 'react-native';
import {WebView} from 'react-native-webview';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Config from '../../constants/Config';
import {LoginButtons} from '../../components/Buttons/Button';
import Fonts from '../../constants/Fonts';

export default class Support extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      name: '',
    };
  }

  sendMessage() {
    this.props.navigation.navigate('SupportMessage');
  }

  render() {
    return (
      <View style={{flex: 1, backgroundColor: '#ffffff'}}>
        <RenderHeader
          back={true}
          title={strings.HelpSupport}
          navigation={this.props.navigation}
        />

        <View style={styles.gridViewBackground}>
          <View style={styles.viewFWebView}>
            <WebView
              source={{
                uri: Config.URL + Config.helpSupport,
              }}
              style={styles.webview}
            />
          </View>
          <View style={styles.arrowTile}>
            <Text style={styles.stillTxt}>{strings.stillStuck}</Text>
            <LoginButtons
              text={strings.SENDAMESSAGE}
              onClick={() => this.sendMessage()}
            />
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  gridViewBackground: {
    flex: 1,
    marginTop: 0,
    marginBottom: 0,
    borderColor: 'white',
    borderWidth: 0.0,
    backgroundColor: 'white',
  },
  arrowTile: {
    flex: 0.2,
    width: '100%',
    alignSelf: 'center',
    alignContent: 'center',
  },
  viewFWebView: {
    width: '100%',
    flex: 0.9,
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  webview: {
    width: '100%',
    height: '100%',
    backgroundColor: 'white',
  },
  stillTxt: {
    fontFamily: Fonts.Semibold,
    fontWeight: 'bold',
    fontSize: 16,
    color: 'black',
    alignSelf: 'center',
  },
});
