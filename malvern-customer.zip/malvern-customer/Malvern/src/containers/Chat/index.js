import {connect} from 'react-redux';
import {chatHistoryRequest} from '../../modules/Conversation/actions';
import Chat from './Chat';

const mapStateToProps = (state) => ({
  chatHistoryData: state.ConversationReducer.chatHistoryData,
  getTripData: state.tripReducer.getTripData,
  loginData: state.loginReducer.loginData,
});

const mapDispatchToProps = (dispatch) => ({
  chatHistoryRequest: (driverId, navigation) =>
    dispatch(chatHistoryRequest(driverId, navigation)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Chat);
