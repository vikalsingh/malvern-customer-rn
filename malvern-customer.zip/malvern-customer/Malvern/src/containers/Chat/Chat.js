import React, {Component} from 'react';
import {
  Text,
  StyleSheet,
  View,
  FlatList,
  Image,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Keyboard,
  Alert,
  Dimensions,
} from 'react-native';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import {strings} from '../../constants/languagesString';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';
import {getConfiguration, setConfiguration} from '../../utils/configuration';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
let {height, width} = Dimensions.get('window');
import moment from 'moment';
import Config from '../../constants/Config';

export default class Chat extends Component {
  constructor(props) {
    super(props);
    this.state = {
      driverId: this.props.route.params.driverId,
      chatId: '',
      message: '',
      dataSource: [],
      mainViewTop: 0,
      historyGet: false,
      UserName: '',
      Firebasetoken: '',
    };
  }

  _keyboardDidShow(e) {
    if (Platform.OS == 'android') {
      this.setState({
        mainViewTop: 22,
      });
    } else {
      this.setState({
        mainViewTop: e.endCoordinates.height,
      });
    }
  }

  _keyboardDidHide() {
    this.setState({
      mainViewTop: 0,
    });
  }

  componentDidMount() {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow.bind(this),
    );
    this.keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      this._keyboardDidHide.bind(this),
    );
    this.getChatHistoryWebApi();

    var socketVar = getConfiguration('Socket');

    socketVar.on('newMessage', (data) => {
      setConfiguration('chat_id', data.chatId);
      var temp = this.state.dataSource || [];
      temp.push(data);
      this.setState({dataSource: temp});
    });
    this.getToken();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.getTripData != this.props.getTripData) {
      this.getToken();
    }
  }

  getToken() {
    console.log(
      'FirebaseToken:- ' + this.props.getTripData.driverRefId.firebaseToken,
    );
    this.setState({
      Firebasetoken: this.props.getTripData.driverRefId.firebaseToken,
      UserName: this.props.loginData.name,
    });
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  goBack = () => {
    this.props.navigation.goBack();
  };

  async getChatHistoryWebApi() {
    const data = await this.props.chatHistoryRequest(this.state.driverId);

    this.afterGetChat();
  }

  afterGetChat() {
    console.log(this.props.chatHistoryData);
    this.setState({dataSource: this.props.chatHistoryData});
  }

  sendMessage() {
    if (this.state.message.trim()) {
      var driverId = this.state.driverId;
      var socketVar = getConfiguration('Socket');
      socketVar.emit('sendMessage', {
        msg: this.state.message,
        customerId: getConfiguration('user_id'),
        driverId: driverId,
        byCustomer: true,
        byDriver: false,
      });
      if (this.state.Firebasetoken != '') {
        this.notificationApi(this.state.message, this.state.Firebasetoken);
      }
      this.setState({message: ''});
    } else {
      alert(strings.enterMessage);
    }
  }

  notificationApi = (msg, token) => {
    var myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    myHeaders.append('Authorization', 'key=' + Config.FirebaseServerKey);

    var raw = JSON.stringify({
      to: token,
      priority: 'high',
      data: {
        notificationType: 'chat',
      },
      notification: {
        title: 'New message',
        body: msg,
      },
    });

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw,
    };

    fetch('https://fcm.googleapis.com/fcm/send', requestOptions)
      .then((response) => response.json())
      .then((result) => console.log(result))
      .catch((error) => console.log('error', error));
  };

  render() {
    return (
      <View style={styles.container}>
        <RenderHeader
          back={true}
          title={strings.messageDriver}
          navigation={this.props.navigation}
        />
        <View style={{flex: 1, backgroundColor: '#f1f1f1'}}>
          <ScrollView
            ref="scrollView"
            scrollEnabled={true}
            style={{backgroundColor: Colors.White}}
            onContentSizeChange={(width, height) =>
              this.refs.scrollView.scrollTo({y: height})
            }>
            <FlatList
              style={{flex: 1, backgroundColor: Colors.White}}
              keyExtractor={(item, index) => index.toString()}
              data={this.state.dataSource}
              renderItem={({item}) => (
                <View
                  style={{
                    width: width,
                    marginVertical: 7,
                  }}>
                  {item.byCustomer == true ? (
                    <View style={styles.RightMsgView}>
                      <Text
                        style={{
                          color: 'white',
                          fontFamily: Fonts.Regular,
                          alignSelf: 'flex-end',
                          marginRight: 5,
                        }}>
                        {' '}
                        {item.msg}{' '}
                      </Text>
                      <Text style={styles.timeStamp2}>
                        {' '}
                        {moment(item.createdAt).format('hh:mm A')}{' '}
                      </Text>
                    </View>
                  ) : (
                    <View style={styles.msgViewLeft}>
                      <Text style={{fontFamily: Fonts.Regular}}>
                        {' '}
                        {item.msg}{' '}
                      </Text>

                      <Text style={styles.timeStamp}>
                        {' '}
                        {moment(item.createdAt).format('hh:mm A')}{' '}
                      </Text>
                    </View>
                  )}
                </View>
              )}
            />
          </ScrollView>
        </View>

        <View
          style={{
            width: '100%',
            height: 90,
            marginBottom: this.state.mainViewTop,
            shadowColor: '#000000',
            shadowOffset: {
              width: 0,
              height: 0,
            },
            shadowRadius: 1,
            shadowOpacity: 1.0,
            backgroundColor: 'white',
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View style={styles.textview}>
            <TextInput
              style={styles.searchTextInput}
              placeholder={strings.writeMessageHere}
              placeholderTextColor={'gray'}
              autoCorrect={false}
              returnKeyType={'done'}
              onChangeText={(message) => this.setState({message})}
              value={this.state.message}
            />
          </View>

          <TouchableOpacity
            style={styles.TouchSendIcon}
            onPress={() => this.sendMessage()}>
            <Image
              resizeMode="contain"
              style={styles.sendIcon}
              source={Images.Chatsubmit}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  textview: {
    height: 40,
    width: '80%',
    borderRadius: 20,
    backgroundColor: '#f1f1f1',
  },
  TouchSendIcon: {
    width: '12%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 5,
  },
  sendIcon: {
    width: 25,
    height: 25,
    marginLeft: 12,
    tintColor: Colors.PrimaryColor,
  },
  searchTextInput: {
    height: '100%',
    width: '100%',
    paddingHorizontal: 20,
    backgroundColor: 'transparent',
    borderColor: 'gray',
    borderRadius: 0,
    fontSize: 16,
    fontFamily: 'CharlieDisplay-Regular',
  },
  timeStamp: {
    fontFamily: Fonts.Regular,
    position: 'absolute',
    right: 5,
    bottom: 4,
    fontSize: 9,
  },
  msgViewLeft: {
    padding: 12,
    paddingBottom: 15,
    width: '50%',
    borderRadius: 7,
    backgroundColor: '#F6F6F6',
    justifyContent: 'center',
  },
  RightMsgView: {
    padding: 12,
    paddingBottom: 15,
    width: '50%',
    borderRadius: 7,
    backgroundColor: Colors.PrimaryColor,
    justifyContent: 'center',
    alignSelf: 'flex-end',
  },
  timeStamp2: {
    color: 'white',
    fontFamily: Fonts.Regular,
    position: 'absolute',
    right: 2,
    bottom: 2,
    fontSize: 9,
  },
});
