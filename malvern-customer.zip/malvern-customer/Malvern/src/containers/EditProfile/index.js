import EditProfile from './EditProfile';
import {
  profileImRequest,
  profileRequest,
} from './../../modules/EditProfile/actions';
import {connect} from 'react-redux';
const mapStateToProps = (state) => ({
  loginData: state.loginReducer.loginData,
  languageList: state.GetAppConfigReducer.languageData,
});
const mapDispatchToProps = (dispatch) => ({
  updateProfileData: (data, navigation) =>
    dispatch(profileRequest(data, navigation)),
  updateProfile: (data) => dispatch(profileImRequest(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(EditProfile);
//export default EditProfile;
