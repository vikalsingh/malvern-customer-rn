import React from 'react';
import {
  View,
  Image,
  Text,
  TextInput,
  Platform,
  Alert,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import {isEmpty} from '../../utils/CommonFunctions';
const regEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
import {Image as ImageEle} from 'react-native-elements';
import ImageResizer from 'react-native-image-resizer';
import Config from '../../constants/Config';
import Images from '../../constants/Images';
import styles from './style';
import NetInfo from '@react-native-community/netinfo';
import {strings} from '../../constants/languagesString';
import {getConfiguration} from '../../utils/configuration';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import {
  EnterAddressPopup,
  CameraOptionsPopup,
} from '../../components/Popups/Popup';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Dropdown} from 'react-native-material-dropdown';
import {requestCameraPermission} from '../../components/Popups/Permissions';

export default class EditProfile extends React.Component {
  constructor(props) {
    super(props);
    const {
      name,
      email,
      mobileNumber,
      profileImage,
      address,
      countryCode,
    } = this.props.loginData;
    this.state = {
      name: name,
      mobileNumber: mobileNumber,
      email: email,
      address: address,
      filePath: profileImage,
      fileName: '',
      countryCode: countryCode + ' -',
      predictions: [],
      showSuggestion: false,
      sourceLocation: '',
      addressModel: false,
      modalVisible: false,
      curLatitude: '',
      curLongitude: '',
      isOpen: false,
      languageList: [],
      LangId: '',
      LangName: '',
    };
  }

  componentDidMount() {
    this.getCurrentLocation();
    this.updateProfileData();
  }

  getCurrentLocation = async () => {
    const lat = getConfiguration('lat');
    const long = getConfiguration('long');
    if (lat && long) {
      this.setState({
        curLatitude: lat,
        curLongitude: long,
      });
    }
  };

  updateProfileData = () => {
    const Langdata = this.props.languageList;
    var temp = [];
    if (Langdata) {
      for (var i = 0; i < Langdata.length; i++) {
        var Lang = Langdata[i];
        temp.push({value: Lang.languageName, _id: Lang._id});
      }
    }
    const {
      name,
      email,
      mobileNumber,
      profileImage,
      address,
      countryCode,
      languageDetails,
    } = this.props.loginData;

    this.setState({
      name: name,
      mobileNumber: mobileNumber,
      countryCode: countryCode + '-',
      email: email,
      address: address,
      filePath: profileImage,
      fileName: '',
      languageList: temp,
      languageListOriginal: this.props.languageData,
      LangName: languageDetails ? languageDetails.languageName : '',
      LangId: languageDetails ? languageDetails._id : '',
    });
  };

  saveImage = (data) => {
    const {updateProfile} = this.props;
    const profiledata = new FormData();
    profiledata.append('profileImage', {
      uri:
        Platform.OS === 'android' ? data.uri : data.uri.replace('file://', ''),
      type: 'image/jpeg',
      name: 'profile',
    });
    updateProfile(profiledata);
  };

  profileImagePck = () => {
    this.setState({isOpen: true});
  };

  onOpenCamera = async () => {
    this.setState({isOpen: false});
    let data = await requestCameraPermission();

    if (data.isGraned) {
      try {
        launchCamera({mediaType: 'photo', cameraType: 'back'}, (response) => {
          console.log(response);
          if (response.didCancel) {
            // console.log('User cancelled image picker');
          } else if (response.errorCode) {
            // console.log('ImagePicker Error: ', response.error);
          } else if (response.customButton) {
            // console.log('User tapped custom button: ', response.customButton);
          } else {
            this.resize(response.uri);
          }
        });
      } catch (error) {
        console.log(error);
      }
    } else {
      alert(data.Message);
    }
  };

  onOpenGallery = () => {
    this.setState({isOpen: false});
    try {
      setTimeout(() => {
        launchImageLibrary({mediaType: 'photo'}, (response) => {
          console.log(response);

          if (response.didCancel) {
            // console.log('User cancelled image picker');
          } else if (response.error) {
            // console.log('ImagePicker Error: ', response.error);
          } else if (response.customButton) {
            // console.log('User tapped custom button: ', response.customButton);
          } else {
            this.resize(response.uri);
          }
        });
      }, 500);
    } catch (error) {
      console.log(error);
    }
  };

  resize = (sourceURI) => {
    ImageResizer.createResizedImage(sourceURI, 300, 300, 'PNG', 80)
      .then(({uri}) => {
        const source = {
          uri: uri,
          imageName: 'profile',
        };
        this.setState({
          filePath: source.uri,
        });
        this.saveImage(source);
      })
      .catch((err) => {
        console.log(err);
        return Alert.alert(strings.unablePhoto);
      });
  };

  verifyCredentials = () => {
    const {name, email, mobileNumber, address} = this.state;
    if (isEmpty(name.trim())) {
      alert(strings.nameAlert);
      return false;
    } else if (isEmpty(email.trim())) {
      alert(strings.emailAlert);
      return false;
    } else if (!regEmail.test(email.trim())) {
      alert(strings.validEmail);
      return false;
    } 
    // else if (isEmpty(mobileNumber.trim())) {
    //   alert(strings.mobileNumberAlert);
    //   return false;
    // } else if (isEmpty(address.trim())) {
    //   alert(strings.addressAlert);
    //   return false;
    // }
    return true;
  };

  saveProfileData = () => {
    if (this.verifyCredentials()) {
      const {email, name, mobileNumber, address, LangId} = this.state;
      var profileData = {
        name: name,
        email: email,
        mobileNumber: mobileNumber,
        address: address,
        languageId: LangId,
      };
      var data = {
        profileData: profileData,
        isRegister: false,
      };
      NetInfo.fetch().then((state) => {
        console.log('Connection type', state.type);
        console.log('Is connected?', state.isConnected);
        if (state.isConnected == false) {
          this.showAlert(strings.noInternet, 300);
        } else {
          this.props.updateProfileData(data, this.props.navigation);
        }
      });
    }
  };

  renderTextInput = (imageLeft, placeHolderText, value, key) => {
    return (
      <View style={styles.tile}>
        <Image
          resizeMode="contain"
          style={styles.tileIcon}
          source={imageLeft}
        />
        {key == 'mobileNumber' ? (
          <Text style={styles.searchTextInput2}>{this.state.countryCode}</Text>
        ) : null}
        <TextInput
          onTouchStart={key == 'address' ? () => this.openAddressModel() : null}
          style={
            key == 'mobileNumber'
              ? styles.searchTextInput1
              : styles.searchTextInput
          }
          placeholder={placeHolderText}
          placeholderTextColor={'gray'}
          autoCorrect={false}
          maxLength={key == 'email' ? 100 : 22}
          editable={key == 'mobileNumber' ? false : true}
          onChangeText={(value) => this.setState({[key]: value})}
          value={value}
          returnKeyType="next"
        />
      </View>
    );
  };

  openAddressModel(visible) {
    this.setState({modalVisible: visible});
  }

  googleAutocomplete = async (Location, curLat, curLong) => {
    const apiUrl =
      'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=' +
      Location +
      '&key=' +
      Config.GOOGLE_MAPS_APIKEY +
      '&location=' +
      curLat +
      ',' +
      curLong +
      '&radius=' +
      1000;
    const result = await fetch(apiUrl);
    const json = await result.json();
    return json;
  };

  async onChangeSource(sourceLocation) {
    this.setState({
      tentativePrice: '',
      showSuggestionDest: false,
      sourceLocation: sourceLocation,
    });
    var json = await this.googleAutocomplete(
      sourceLocation,
      this.state.curLatitude,
      this.state.curLongitude,
    );
    try {
      this.setState({
        predictions: json.predictions,
        showSuggestion: true,
      });
      var adress_data = json.predictions;

      this.setState({
        myaddress_list: adress_data,
      });

      if (json.predictions.length == 0) {
        this.setState({
          showSuggestion: false,
        });
      }
    } catch (err) {
      this.showAlert(err.message, 300);
    }
  }

  showAlert(message, duration) {
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }
  setSourceLocation = (placeId, description) => {
    this.setState({
      sourceLocation: description,
      showSuggestion: false,
      selSourcePlaceId: placeId,
      address: description,
      modalVisible: false,
    });
  };

  onChangeLanguageType = (value, index, data) => {
    console.log(data);
    var langId = data[index]._id;
    console.log(langId);
    this.setState({LangName: value, LangId: langId});
  };

  renderText = (imageLeft, placeHolderText, value, key) => {
    return (
      <View style={styles.tile}>
        <Image
          resizeMode="contain"
          style={styles.tileIcon}
          source={imageLeft}
        />

        <Dropdown
          dropdownPosition={0}
          fontSize={wp('4.8%')}
          value={this.state.LangName}
          data={this.state.languageList}
          containerStyle={styles.dropdownContainer}
          onChangeText={(talenttype, index, data) =>
            this.onChangeLanguageType(talenttype, index, data)
          }
          baseColor="#818e97"
          inputContainerStyle={{borderBottomWidth: 0}}
        />
      </View>
    );
  };
  render() {
    const {name, mobileNumber, email, filePath, address} = this.state;

    return (
      <View style={{flex: 1, backgroundColor: '#ffffff'}}>
        <RenderHeader
          back={true}
          title={strings.EditProfile}
          navigation={this.props.navigation}
        />
        <KeyboardAwareScrollView
          style={{
            marginTop: 40,
          }}>
          <View style={styles.profileView}>
            <TouchableOpacity onPress={this.profileImagePck}>
              <View style={styles.profileimg}>
                <ImageEle
                  style={styles.profileImag}
                  source={
                    filePath == '' ||
                    filePath == 'null' ||
                    filePath == null ||
                    filePath == 'none'
                      ? Images.drawerProfileBG
                      : {uri: filePath}
                  }
                  PlaceholderContent={
                    <View style={styles.loaderView}>
                      <ActivityIndicator style={styles.activityInd} />
                    </View>
                  }
                />
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => this.profileImagePck()}
              style={styles.cameraIcon}>
              <Image
                style={{
                  height: hp('3%'),
                  width: hp('3%'),
                  resizeMode: 'contain',
                }}
                source={Images.camera}
              />
            </TouchableOpacity>
            <TextInput
              style={styles.nameInputtxt}
              placeholder={'Name'}
              placeholderTextColor={'gray'}
              autoCorrect={false}
              maxLength={22}
              onChangeText={(name) => this.setState({name})}
              value={name}
              returnKeyType="next"
            />
          </View>

          {this.renderTextInput(
            Images.WhitePhone,
            strings.Phone,
            mobileNumber,
            'mobileNumber',
          )}
          <View style={styles.separtorline} />

          {this.renderTextInput(Images.Email_Ic, strings.Email, email, 'email')}
          <View style={styles.separtorline} />

          {this.renderTextInput(
            Images.Address_Ic,
            strings.Address,
            address,
            'address',
          )}
          <View style={styles.separtorline} />

          {/* {this.renderText(
            Images.langProfile,
            strings.Address,
            address,
            'address',
          )} */}
        </KeyboardAwareScrollView>

        <TouchableOpacity
          style={styles.touchableArrow}
          onPress={this.saveProfileData}>
          <Image
            resizeMode="contain"
            style={styles.arrowIcon}
            source={Images.rightImg}
          />
        </TouchableOpacity>

        <EnterAddressPopup
          isOpen={this.state.modalVisible}
          onClose={() => this.setState({modalVisible: false})}
          sourceLocation={this.state.sourceLocation}
          onChangeSource={(sourceLocation) =>
            this.onChangeSource(sourceLocation)
          }
          showSuggestion={this.state.showSuggestion}
          predictions={this.state.predictions}
          setSourceLocation={(place_id, description) =>
            this.setSourceLocation(place_id, description)
          }
        />

        <CameraOptionsPopup
          isOpen={this.state.isOpen}
          onClose={() => this.setState({isOpen: false})}
          openCamera={() => this.onOpenCamera()}
          openGallery={() => this.onOpenGallery()}
        />
      </View>
    );
  }
}
