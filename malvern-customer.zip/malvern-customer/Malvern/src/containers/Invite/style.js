import {StyleSheet} from 'react-native';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  inviteImageView: {
    width: '100%',
    height: hp('45%'),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
  },
  inviteLink: {
    color: 'black',
    fontFamily: Fonts.Regular,
    textAlign: 'center',
    fontSize: wp('3.5%'),
    marginTop: 5
  },
  inviteImage: {
    resizeMode: 'contain',
    width: '60%',
    height: '60%',
  },
  inviteTextView: {
    width: '100%',
    height: 'auto',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
  },
  inviteText: {
    fontSize: wp('6%'),
    color: 'black',
    fontFamily: Fonts.Semibold,
    marginTop: -45,
  },
  inviteRefer: {
    color: 'black',
    fontFamily: Fonts.Regular,
    textAlign: 'center',
    fontSize: wp('3.5%'),
  },
  inviteRefer1: {
    color: Colors.PrimaryColor,
    fontFamily: Fonts.Semibold,
    textAlign: 'center',
    fontSize: wp('7%'),
    marginTop: 15,
  },
  title: {
    fontSize: 20,
    color: 'white',
    alignSelf: 'center',
    marginTop: -10,
  },
  gridViewBackground: {
    height: '100%',
    width: '100%',
    flex: 1,
    borderColor: '#f5f6f8',
    borderWidth: 0,
    backgroundColor: 'white',
  },
  arrowTile: {
    width: '100%',
    height: 70,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    alignContent: 'center',
  },
  loadDetail: {
    justifyContent: 'center',
  },
  bottomView: {
    position: 'absolute',
    bottom: 40,
    width: '90%',
    height: 50,
    justifyContent: 'center',
    alignSelf: 'center',
  },
});
export default styles;
