import Invite from './Invite';
import {connect} from 'react-redux';
const mapStateToProps = (state) => ({
  contactsData: state.getContactsReducer.contactsData,
  loginData: state.loginReducer.loginData,
});

export default connect(mapStateToProps, null)(Invite);
