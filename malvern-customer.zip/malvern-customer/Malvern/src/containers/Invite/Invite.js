import React, { Component } from 'react';
import { View, Image, Text, Share, Platform, TouchableOpacity, Clipboard } from 'react-native';
import { strings } from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Images from '../../constants/Images';
import styles from './style';
import { LoginButtons } from '../../components/Buttons/Button';
import VersionCheck from 'react-native-version-check';

export default class Invite extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      message: '',
      shareMessage: strings.TaxtRefer,
      inViteLink: 'Download Link:- https://play.google.com/store',
      inviteCode: '',
    };
  }

  componentDidMount() {
    this.checkVersionUpdate();

    // this.setState({
    //   inviteCode: this.props.loginData.referalCodeTo,
    // });
  }
  async checkVersionUpdate() {
    let updateNeeded = await VersionCheck.needUpdate();
    console.log('updateNeeded', updateNeeded);
    if (updateNeeded != undefined)
      this.setState({
        inViteLink: 'Download Link:- ' + updateNeeded.storeUrl,
        forceUpdateVisible: updateNeeded.isNeeded,
        url: updateNeeded.storeUrl,
      });
  }

  goToNextScreen = async () => {
    try {
      const result = await Share.share({
        message:
          this.state.shareMessage +
          ' ' +
          ' ' +
          this.state.inViteLink,
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };

  render() {
    return (
      <View style={styles.container}>
        <RenderHeader
          back={true}
          title={strings.InviteFriend}
          navigation={this.props.navigation}
        />

        <View style={styles.gridViewBackground}>
          <View style={styles.inviteImageView}>
            <Image style={styles.inviteImage} source={Images.inviteTmage} />
          </View>

          <View style={styles.inviteTextView}>
            <Text style={styles.inviteText}>
              {strings.InviteYourFriends.toUpperCase()}
            </Text>
          </View>

          <View style={styles.inviteTextView} />

          <View style={styles.loadDetail}>
            <Text style={styles.inviteRefer}>
              {strings.TaxtRefer.toUpperCase()}
            </Text>
          </View>

          <TouchableOpacity onPress={() => Clipboard.setString('https://play.google.com/store')}>
              <View style={styles.loadDetail}>
                <Text style={styles.inviteLink}>
                  https://play.google.com/store
                </Text>
              </View>
            </TouchableOpacity>

          <LoginButtons
            text={strings.InviteFriend2}
            onClick={() => this.goToNextScreen()}
          />
        </View>
      </View>
    );
  }
}
