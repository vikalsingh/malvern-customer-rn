import Detail from './Detail';
export default Detail;
