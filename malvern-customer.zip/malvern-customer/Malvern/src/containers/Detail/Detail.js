import React from 'react';
import {View} from 'react-native';
import strings from '../../constants/languagesString';

export default class Detail extends React.Component {
  that = this;
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      status: '',
      ratingValue: 0,
      selectedItem: this.props.route.params.selectedItem,
    };
  }

  render() {
    return <View>{strings.Details}</View>;
  }
}
