import AddDispute from './AddDispute';
import {connect} from 'react-redux';
import {addDisputeRequest} from './../../modules/Dispute/actions';
const mapStateToProps = (state) => ({
  addDisputeData: state.DisputeReducer.AddDisputeData,
  loginData: state.loginReducer.loginData,
  contactsData: state.getContactsReducer.contactsData,
});
const mapDispatchToProps = (dispatch) => ({
  addDisputeRequest: (data, navigation) =>
    dispatch(addDisputeRequest(data, navigation)),
});
export default connect(mapStateToProps, mapDispatchToProps)(AddDispute);
