import React, {Component} from 'react';
import {View, Text, Alert, TextInput, StyleSheet, Keyboard} from 'react-native';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import Colors from '../../constants/Colors';
import {LoginButtons} from '../../components/Buttons/Button';
import {getConfiguration} from '../../utils/configuration';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import moment from 'moment';
import Config, {SUCCESS} from '../../constants/Config';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

export default class AddDispute extends Component {
  constructor(props) {
    super(props);
    this.state = {
      reason: '',
      message: '',
      tripDetails: this.props.route.params.tripData,
      currency: '',
      prevScreen: 'Payment',
      timeStamp: JSON.parse(this.props.route.params.day),
    };
  }

  componentDidMount() {
    let currency = this.props.contactsData.App_Settings.Admin_Currency_Code;
    this.setState({currency: currency});
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.addDisputeData !== this.props.addDisputeData) {
      // if(this.props.addDisputeData)
      console.log(this.props.addDisputeData);
      if (this.props.addDisputeData.status == SUCCESS) {
        this.afterDispute();
      }
    }
  }
  afterDispute() {
    setTimeout(() => {
      Alert.alert(
        'Alert',
        'Dispute sent successfully',
        [
          {
            text: 'Ok',
            onPress: () => this.props.navigation.goBack(),
          },
        ],
        {cancelable: false},
      );
    }, 200);
  }

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  goToNextScreen() {
    const {tripDetails, reason, message} = this.state;
    if (reason == '') {
      this.showAlert(strings.enterReason, 200);
      return;
    } else if (message == '') {
      this.showAlert(strings.enterMsg, 200);
      return;
    } else {
      const customerid = getConfiguration('user_id');
      let data = {
        customerName: this.props.loginData.name,
        customerId: customerid,
        driverName: tripDetails.driverName,
        driverId: tripDetails.driverId,
        disputAmount: tripDetails.cost,
        tripId: tripDetails._id,
        disputeReason: reason,
        disputeMessage: message,
      };
      this.props.addDisputeRequest(data, this.props.navigation);
    }
  }

  render() {
    const {tripDetails, currency, timeStamp} = this.state;
    return (
      <View style={{flex: 1, backgroundColor: Colors.White}}>
        <RenderHeader
          back={true}
          title={strings.Claim}
          navigation={this.props.navigation}
        />

        <KeyboardAwareScrollView>
          <View
            style={{
              marginTop: 20,
              width: '100%',
              borderBottomWidth: 1,
              borderColor: Colors.graylight,
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: '5%',
            }}>
            <Text style={styles.cardTitle}>{strings.amount}</Text>
            <Text style={styles.valueTitle}>
              {currency} {parseFloat(tripDetails.cost).toFixed(2)}
            </Text>
          </View>

          <View
            style={{
              width: '100%',
              borderBottomWidth: 1,
              borderColor: Colors.graylight,
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: '5%',
            }}>
            <Text style={styles.cardTitle}>{strings.customerName}</Text>
            <Text style={styles.valueTitle}>{this.props.loginData.name}</Text>
          </View>

          <View
            style={{
              width: '100%',
              borderBottomWidth: 1,
              borderColor: Colors.graylight,
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: '5%',
            }}>
            <Text style={styles.cardTitle}>{strings.driverName}</Text>
            <Text style={styles.valueTitle}>{tripDetails.driverName}</Text>
          </View>
          <View
            style={{
              width: '100%',
              borderBottomWidth: 1,
              borderColor: Colors.graylight,
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: '5%',
            }}>
            <Text style={styles.cardTitle}>{strings.disputeDateTim}</Text>
            <Text style={styles.valueTitle}>
              {moment(timeStamp).format('DD/MM/YYYY | hh:mm A')}
            </Text>
          </View>

          <View style={styles.tile}>
            <TextInput
              style={styles.searchTextInput}
              placeholder={strings.reasonDispute}
              placeholderTextColor={'#818e97'}
              autoCorrect={false}
              value={this.state.reason}
              onChangeText={(reason) => {
                if (reason.length == 1 && reason == ' ') {
                } else {
                  this.setState({reason});
                }
              }}
              onSubmitEditing={() => this.message.focus()}
            />
          </View>

          <View style={styles.tileFeedback}>
            <TextInput
              style={[styles.searchTextInput, {height: 110}]}
              placeholder={strings.msg}
              placeholderTextColor={'#818e97'}
              multiline={true}
              numberOfLines={5}
              autoCorrect={false}
              returnKeyType={'done'}
              blurOnSubmit={true}
              onSubmitEditing={() => {
                Keyboard.dismiss();
              }}
              textAlignVertical={'top'}
              onChangeText={(message) => {
                if (message.length == 1 && message == ' ') {
                } else {
                  this.setState({message});
                }
              }}
              value={this.state.message}
              ref={(message) => (this.message = message)}
            />
          </View>
          <LoginButtons
            text={strings.Send}
            style1={{marginTop: '15%', marginBottom: 40}}
            onClick={() => this.goToNextScreen()}
          />
        </KeyboardAwareScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  title: {
    fontSize: 20,
    color: 'white',
  },

  gridViewBackground: {
    flex: 1,
    marginTop: 20,
  },

  tileIcon: {
    width: 20,
    height: 40,
    marginLeft: 20,
    alignSelf: 'center',
  },
  tile: {
    alignSelf: 'center',
    backgroundColor: 'transparent',
    width: '90%',
    height: wp('13.5%'),
    marginTop: 40,
    marginHorizontal: 0,
  },
  searchTextInput: {
    marginTop: 5,
    width: '100%',
    height: '80%',
    paddingHorizontal: 20,
    backgroundColor: Colors.graylighted,
    borderColor: 'gray',
    borderRadius: 15,
    fontSize: wp('4.8%'),
    // alignContent: 'center'
    //  top: 4,
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
  },
  touchableArrow: {
    backgroundColor: 'transparent',
    position: 'absolute',
    right: 0,
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  arrowTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: wp('16%'),
    marginTop: 50,
    right: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0,
    borderColor: '#818e97',
  },
  bottomView: {position: 'absolute', bottom: 40, width: '100%'},
  cardTitle: {
    fontFamily: Fonts.Semibold,
    fontSize: 16,
    color: 'black',
  },
  valueTitle: {
    fontFamily: Fonts.Semibold,
    fontSize: 16,
    color: 'gray',
  },
  tileFeedback: {
    backgroundColor: 'white',
    width: 'auto',
    height: 140,
    marginTop: wp('5%'),
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 0.4,
    borderColor: '#818e97',
    borderRadius: 10,
    backgroundColor: Colors.graylights,
  },
  tile: {
    backgroundColor: 'white',
    width: 'auto',
    height: wp('13.33%'),
    marginTop: wp('5%'),
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 0.4,
    borderColor: '#818e97',
    borderRadius: 10,
    backgroundColor: Colors.graylights,
  },
  searchTextInput: {
    height: 'auto',
    width: '100%',
    marginLeft: 10,
    backgroundColor: 'transparent',
    borderColor: 'gray',
    borderRadius: 0,
    fontSize: wp('4.8%'),
    color: Colors.FontDarkColor,
    fontFamily: Fonts.Semibold,
  },
});
