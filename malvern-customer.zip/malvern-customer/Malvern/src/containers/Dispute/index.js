import Disputes from './Dispute';
import {
  getDisputeRequest,
  updateDisputeRequest,
} from '../../modules/Dispute/actions';
import {cancelTripRequest} from '../../modules/Trip/actions';
import {connect} from 'react-redux';
const mapStateToProps = (state) => ({
  myTripsData: state.myTripsReducer.data,
  cancelTripData: state.tripReducer.cancelTripData,
  GetDisputeData: state.DisputeReducer.GetDisputeData,
  updateDisputeData: state.DisputeReducer.updateDisputeData,
  contactsData: state.getContactsReducer.contactsData,
});

const mapDispatchToProps = (dispatch) => ({
  getDisputeRequest: (data, navigation) =>
    dispatch(getDisputeRequest(data, navigation)),
  updateDisputeRequest: (data, navigation) =>
    dispatch(updateDisputeRequest(data, navigation)),
  cancelTripRequest: (data) => dispatch(cancelTripRequest(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Disputes);
