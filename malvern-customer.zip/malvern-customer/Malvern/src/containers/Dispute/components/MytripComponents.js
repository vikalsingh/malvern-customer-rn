import React from 'react';
import {TouchableOpacity, Text} from 'react-native';
import Fonts from '../../../constants/Fonts';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import Colors from '../../../constants/Colors';

function TabOption({color, title, onClick}) {
  return (
    <TouchableOpacity
      style={{
        flex: 1,
        borderBottomWidth: 2,
        borderColor: color,
        justifyContent: 'center',
        alignItems: 'center',
      }}
      onPress={() => onClick()}>
      <Text
        style={{
          color: Colors.FontDarkColor,
          fontFamily: Fonts.Semibold,
          fontSize: wp(4),
        }}>
        {title.toUpperCase()}
      </Text>
    </TouchableOpacity>
  );
}

export {TabOption};
