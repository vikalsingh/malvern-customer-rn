import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  BackHandler,
  ScrollView,
  TextInput,
  Keyboard,
  Alert,
} from 'react-native';
import moment from 'moment';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';
import {TabOption} from './components/MytripComponents';
import {getConfiguration} from '../../utils/configuration';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {RenderHeaderBack} from './../../components/CustomComponent/renderHeader';
import {LoginButtons} from '../../components/Buttons/Button';

class Disputes extends React.PureComponent {
  constructor(props) {
    super(props);
    this.backHandler = null;
    this.state = {
      type: 1,
      upcomingData: [],
      pastBokking: [],
      detailView: false,
      disputeUpdate: false,
      itemDetail: '',
      myTripsData: '',
      currency: '£',
      message: '',
    };

    const {navigation} = props;
    this.didFocusListener = navigation.addListener(
      'focus',
      this.componentDidFocus,
    );
  }

  componentDidFocus = () => {
    this.getTripsData();
  };

  componentDidMount() {
    let currency = this.props.contactsData.App_Settings.Admin_Currency_Code;
    this.setState({currency: currency});
    this.backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
  }

  handleBackButtonClick = () => {
    if (this.props.navigation.isFocused()) {
      if (this.state.disputeUpdate == true) {
        this.setState({disputeUpdate: false, message: ''});
      } else if (this.state.detailView == true) {
        this.setState({detailView: false});
        return true;
      } else {
        this.props.navigation.goBack();
        return true;
      }
    } else {
      return false;
    }
  };

  componentWillUnmount() {
    BackHandler.removeEventListener(
      'hardwareBackPress',
      this.handleBackButtonPressAndroid,
    );
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.GetDisputeData !== this.props.GetDisputeData) {
      // console.log('Got');
      this.afterGetTripsData(this.props.GetDisputeData.data);
    }
    if (prevProps.updateDisputeData !== this.props.updateDisputeData) {
      // console.log(this.props.updateDisputeData.data.disputeMessage);
      let data = this.state.itemDetail;
      data.disputeMessage = this.props.updateDisputeData.data.disputeMessage;
      this.setState({itemDetail: data});

      setTimeout(() => {
        Alert.alert(
          'Alert',
          'Message updated successfully',
          [
            {
              text: 'Ok',
              onPress: () => {
                this.setState({disputeUpdate: false, message: ''});
              },
            },
          ],
          {cancelable: false},
        );
      }, 300);
    }
  }
  getTripsData = () => {
    const customerId = getConfiguration('user_id');
    let data = {customerId};
    this.props.getDisputeRequest(data, this.props.navigation);
  };

  afterGetTripsData = (data) => {
    var upcomingData = data.currentDisputes;
    var pastData = data.completedDisputes;
    // console.log('upcomingData value --- ', upcomingData);
    // console.log('pastData value --- ', pastData);
    this.setState({
      upcomingData: upcomingData.reverse(),
      pastBokking: pastData.reverse(),
    });
  };

  showAlert(message, duration) {
    this.setState({autoLogin: false});
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  goToDetails(item) {
    console.log(JSON.stringify(item));
    this.setState({detailView: true, itemDetail: item});
  }

  upcomingClick() {
    this.setState({type: 1});
    this.getTripsData();
  }

  pastClick() {
    this.setState({type: 2});
    this.getTripsData();
  }

  renderItems = (item, type) => {
    let driverimage = item.driverId.profileImage;
    let selectedCar = item.driverId.selectedCar;
    return (
      <TouchableOpacity onPress={() => this.goToDetails(item, type)}>
        <View style={styles.driverDetailCard}>
          <Text
            style={[
              styles.valueTitle,
              {
                color: 'black',
                alignSelf: 'flex-end',
                marginRight: 8,
                marginTop: 2,
              },
            ]}>
            {moment(item.createdAt).format('DD/MM/YYYY, hh:mm A')}
          </Text>
          <View style={{flexDirection: 'row'}}>
            <View style={styles.driverDetailView}>
              <Image
                source={
                  driverimage == 'null' || driverimage == null
                    ? Images.drawerProfileBG
                    : {uri: driverimage}
                }
                style={styles.profileimg}
              />
              <Text style={styles.driverName}>{item.driverName}</Text>
            </View>
            <View style={styles.driverDetailViews}>
              <View style={styles.carNumberView}>
                <Text style={styles.carPlateNumber}>
                  {selectedCar.plateNumber}
                </Text>
              </View>
              <Text style={styles.carName}>{selectedCar.carName}</Text>
            </View>
            <View
              style={{
                width: '30%',
                height: '100%',
              }}>
              <Text
                style={[
                  styles.txtAmount,
                  {
                    position: 'absolute',
                    top: '40%',
                    bottom: 0,
                    right: 10,
                  },
                ]}>
                {this.state.currency} {parseFloat(item.disputAmount).toFixed(2)}
              </Text>
            </View>
          </View>
          <Text style={[styles.valueTitle]}> </Text>
        </View>
      </TouchableOpacity>
    );
  };

  updateDispute() {
    const {message, itemDetail} = this.state;
    if (message == '') {
      this.showAlert(strings.enterMsg, 200);
      return;
    } else {
      let data = {
        disputeId: itemDetail._id,
        disputeMessage: message,
      };
      this.props.updateDisputeRequest(data, this.props.navigation);
    }
  }

  render() {
    const {type, detailView, itemDetail, currency, disputeUpdate} = this.state;

    return (
      <View style={{flex: 1, backgroundColor: 'white'}}>
        <RenderHeader
          back={true}
          title={strings.Disputes}
          navigation={this.props.navigation}
        />
        <View style={{flex: 1}}>
          <View
            style={{flexDirection: 'row', height: wp(10), marginTop: wp('4%')}}>
            <TabOption
              color={type === 1 ? Colors.FontDarkColor : 'white'}
              title={strings.current}
              onClick={() => this.upcomingClick()}
            />
            <TabOption
              color={type === 2 ? Colors.FontDarkColor : 'white'}
              title={strings.Completed}
              onClick={() => this.pastClick()}
            />
          </View>

          <View style={{flex: 1}}>
            <FlatList
              style={{flex: 1}}
              keyExtractor={(item, index) => index.toString()}
              data={
                this.state.type == 1
                  ? this.state.upcomingData
                  : this.state.pastBokking
              }
              renderItem={({item}) => this.renderItems(item, type)}
              ListEmptyComponent={
                <Text style={styles.noBookingTxt}>
                  {' '}
                  {strings.NoIssuesavailable}{' '}
                </Text>
              }
            />
          </View>
        </View>

        {detailView ? (
          <View
            style={{
              width: '100%',
              height: '100%',
              backgroundColor: 'white',
              position: 'absolute',
            }}>
            <RenderHeaderBack
              onBack={() => this.setState({detailView: false})}
              title={strings.claim}
            />

            <ScrollView>
              <View
                style={{
                  marginTop: 20,
                  width: '100%',
                  borderBottomWidth: 1,
                  borderColor: Colors.graylight,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  padding: '5%',
                }}>
                <Text style={styles.cardTitle}>{strings.amount}</Text>
                <Text style={styles.valueTitle}>
                  {currency} {parseFloat(itemDetail.disputAmount).toFixed(2)}
                </Text>
              </View>

              <View
                style={{
                  width: '100%',
                  borderBottomWidth: 1,
                  borderColor: Colors.graylight,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  padding: '5%',
                }}>
                <Text style={styles.cardTitle}>{strings.customerName}</Text>
                <Text style={styles.valueTitle}>{itemDetail.customerName}</Text>
              </View>

              <View
                style={{
                  width: '100%',
                  borderBottomWidth: 1,
                  borderColor: Colors.graylight,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  padding: '5%',
                }}>
                <Text style={styles.cardTitle}>{strings.driverName}</Text>
                <Text style={styles.valueTitle}>{itemDetail.driverName}</Text>
              </View>
              <View
                style={{
                  width: '100%',
                  borderBottomWidth: 1,
                  borderColor: Colors.graylight,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  padding: '5%',
                }}>
                <Text style={styles.cardTitle}>{strings.disputeDateTim}</Text>
                <Text style={styles.valueTitle}>
                  {moment(itemDetail.createdAt).format('DD/MM/YYYY | hh:mm A')}
                </Text>
              </View>

              <View
                style={{
                  width: '100%',

                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  padding: '5%',
                }}>
                <Text style={[styles.cardTitle, {color: 'green'}]}>
                  {strings.reasonDispute}
                </Text>
                <Text style={[styles.valueTitle, {color: 'black'}]}>
                  {itemDetail.disputeReason}
                </Text>
              </View>

              <View
                style={{
                  width: '100%',

                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  padding: '5%',
                }}>
                <Text style={[styles.cardTitle]}>{strings.issueDes}</Text>
                <Text style={styles.valueTitle} />
              </View>

              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  padding: '5%',
                  alignItems: 'center',
                }}>
                <Image
                  source={
                    itemDetail.driverId.profileImage == 'null' ||
                    itemDetail.driverId.profileImage == null
                      ? Images.drawerProfileBG
                      : {uri: itemDetail.driverId.profileImage}
                  }
                  style={[
                    styles.profileimg,
                    {height: 75, width: 75, borderRadius: 40},
                  ]}
                />
                <View style={{marginLeft: 10}}>
                  <Text
                    style={[
                      styles.valueTitle,
                      {color: 'black', fontFamily: Fonts.Semibold},
                    ]}>
                    {itemDetail.driverName}
                  </Text>
                  <Text style={[styles.valueTitle, {color: 'black'}]}>
                    {moment(itemDetail.createdAt).format('DD/MM/YYYY, hh:mm A')}
                  </Text>
                </View>
              </View>

              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  padding: '5%',
                  paddingBottom: 110,
                }}>
                <Text style={styles.valueTitle}>
                  {itemDetail.disputeMessage}
                </Text>
              </View>
              {this.state.type == 1 ? null : (
                <Text
                  style={[
                    styles.cardTitle,
                    {color: 'green', alignSelf: 'center'},
                  ]}>
                  {strings.refundSuccessfully}
                </Text>
              )}
              {this.state.type == 1 ? null : (
                <Text
                  style={[
                    styles.valueTitle,
                    {color: 'green', alignSelf: 'center', fontSize: 20},
                  ]}>
                  {currency} {parseFloat(itemDetail.refundAmount).toFixed(2)}
                </Text>
              )}
            </ScrollView>

            {this.state.type == 2 ? null : (
              <View style={{position: 'absolute', bottom: 40, width: '100%'}}>
                <LoginButtons
                  text={strings.addreply}
                  onClick={() => this.setState({disputeUpdate: true})}
                />
              </View>
            )}
          </View>
        ) : null}

        {disputeUpdate ? (
          <View
            style={{
              width: '100%',
              height: '100%',
              backgroundColor: 'white',
              position: 'absolute',
            }}>
            <RenderHeaderBack
              onBack={() => this.setState({disputeUpdate: false})}
              title={strings.Dispute}
            />

            <View
              style={{
                marginTop: 20,
                width: '100%',
                borderBottomWidth: 1,
                borderColor: Colors.graylight,
                flexDirection: 'row',
                justifyContent: 'space-between',
                padding: '5%',
              }}>
              <Text style={styles.cardTitle}>{strings.amount}</Text>
              <Text style={styles.valueTitle}>
                {currency} {parseFloat(itemDetail.disputAmount).toFixed(2)}
              </Text>
            </View>

            <View
              style={{
                width: '100%',
                borderBottomWidth: 1,
                borderColor: Colors.graylight,
                flexDirection: 'row',
                justifyContent: 'space-between',
                padding: '5%',
              }}>
              <Text style={styles.cardTitle}>{strings.customerName}</Text>
              <Text style={styles.valueTitle}>{itemDetail.customerName}</Text>
            </View>

            <View style={styles.tileFeedback}>
              <TextInput
                style={[styles.searchTextInput, {height: '100%'}]}
                placeholder={strings.msg}
                placeholderTextColor={'#818e97'}
                multiline={true}
                numberOfLines={5}
                autoCorrect={false}
                returnKeyType={'done'}
                blurOnSubmit={true}
                onSubmitEditing={() => {
                  Keyboard.dismiss();
                }}
                textAlignVertical={'top'}
                onChangeText={(message) => {
                  if (message.length == 1 && message == ' ') {
                  } else {
                    this.setState({message});
                  }
                }}
                value={this.state.message}
                ref={(message) => (this.message = message)}
              />
            </View>

            <View style={{position: 'absolute', bottom: 40, width: '100%'}}>
              <LoginButtons
                text={strings.updatedispute}
                onClick={() => this.updateDispute()}
              />
            </View>
          </View>
        ) : null}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  noBookingTxt: {
    width: wp('100%'),
    marginTop: 20,
    textAlign: 'center',
    fontSize: 18,
    fontFamily: Fonts.Medium,
  },
  loadDetail: {
    width: '94%',
    alignSelf: 'center',
    backgroundColor: 'white',
    shadowColor: 'gray',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
    borderRadius: 12,
    marginTop: 15,
    padding: 10,
  },
  sourceAddressBG: {
    marginTop: wp('2%'),
    backgroundColor: 'transparent',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  priceTile: {
    flexDirection: 'row',
    backgroundColor: 'transparent',
    width: '100%',
    justifyContent: 'space-between',
  },
  txtAmount: {
    fontFamily: Fonts.Semibold,
    color: Colors.Black,
    fontSize: 18,
  },
  txtDate: {
    fontFamily: Fonts.Semibold,
    fontSize: 14,
    color: Colors.Black,
  },
  txtSource: {
    fontFamily: Fonts.Regular,
    marginLeft: 10,
    marginRight: 10,
    fontSize: 14,
  },
  txtDest: {
    fontFamily: Fonts.Regular,
    marginTop: 10,
    marginLeft: 10,
    fontSize: 14,
  },
  destIcon: {
    height: 12,
    width: 18,
    resizeMode: 'contain',
  },
  blackLine: {
    height: 60,
    width: 1,
    backgroundColor: 'black',
    marginTop: 3,
    marginBottom: 3,
  },
  sourceIcon: {
    height: 12,
    width: 18,
    resizeMode: 'contain',
    marginRight: 2,
    tintColor: '#4B545A',
  },
  seprator: {
    height: 1,
    backgroundColor: 'grey',
    marginTop: 7,
    marginBottom: 14,
    opacity: 0.4,
  },
  starRatingIcon: {
    width: 20,
    height: 20,
    resizeMode: 'contain',
    marginLeft: 5,
    marginRight: 10,
  },
  ratingView: {
    alignSelf: 'flex-end',
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 8,
  },
  statusText: {
    fontFamily: Fonts.Semibold,
    fontSize: 14,
    color: Colors.buttonsColor,
  },
  statusCancelText: {
    fontFamily: Fonts.Semibold,
    fontSize: 14,
    color: 'red',
  },
  driverDetailCard: {
    marginTop: 40,
    width: '90%',
    alignSelf: 'center',
    height: 135,
    borderWidth: 1,
    borderColor: Colors.graylight,
  },
  profileimg: {
    width: 60,
    height: 60,
    resizeMode: 'cover',
    borderRadius: 30,
    borderWidth: 1,
    borderColor: Colors.graylight,
  },
  driverDetailView: {
    width: '30%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  driverDetailViews: {
    width: '35%',
    height: '100%',

    justifyContent: 'center',
  },
  driverName: {
    fontFamily: Fonts.Semibold,
    marginTop: 5,
  },
  carNumberView: {
    backgroundColor: Colors.graylights,
    padding: 5,
    // paddingLeft: 10,
    // paddingRight: 10,
    borderRadius: 20,
  },
  carPlateNumber: {
    fontFamily: Fonts.Bold,
    fontSize: 16,
    alignSelf: 'center',
  },
  carName: {
    fontFamily: Fonts.Regular,
    fontSize: 17,
  },
  cardTitle: {
    fontFamily: Fonts.Semibold,
    fontSize: 16,
    color: 'black',
  },
  valueTitle: {
    fontFamily: Fonts.Semibold,
    fontSize: 16,
    color: 'gray',
  },

  tileFeedback: {
    backgroundColor: 'white',
    width: 'auto',
    height: '50%',
    marginTop: wp('5%'),
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 0.4,
    borderColor: '#818e97',
    borderRadius: 10,
    backgroundColor: Colors.graylights,
  },
  searchTextInput: {
    marginTop: 5,
    width: '100%',
    height: '80%',
    paddingHorizontal: 20,
    backgroundColor: Colors.graylighted,
    borderColor: 'gray',
    borderRadius: 15,
    fontSize: wp('4.8%'),
    // alignContent: 'center'
    //  top: 4,
  },
});

export default Disputes;
