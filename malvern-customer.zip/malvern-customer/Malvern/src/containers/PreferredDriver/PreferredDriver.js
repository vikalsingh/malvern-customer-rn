import React, {Component} from 'react';
import {
  StyleSheet,
  View,
  Image,
  Text,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';
import Config from '../../constants/Config';
import Images from '../../constants/Images';

export default class PreferredDriver extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      calling: '',
      preferredDriverList: '',
    };
    const {navigation} = props;
    this.didFocusListener = navigation.addListener(
      'focus',
      this.componentDidFocus,
    );
  }

  componentDidFocus = (payload) => {
    console.log('call');
    this.getData();
  };

  componentWillUnmount() {
    this.didFocusListener();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.preferredDriverList !== this.props.preferredDriverList) {
      this.setState(
        {preferredDriverList: this.props.preferredDriverList[0]},
        () => {
          var data = this.state.preferredDriverList.prefferedDriver;
          this.afterPreferDriverList(data);
        },
      );
    }
  }

  getData() {
    this.props.preferredRequest();
  }

  afterPreferDriverList = (data) => {
    console.log(data);
    if (data.length > 0) {
      var PreferData = data;
      this.setState({
        dataSource: PreferData,
      });
    }
  };

  bookNow(driverId) {
    console.log(driverId);
    this.props.navigation.navigate(Config.MapSearchScreen, {
      driverId: driverId,
      prefDriverRide: 'yes',
    });
  }

  render() {
    return (
      <View style={{flex: 1, backgroundColor: 'white'}}>
        <RenderHeader
          back={true}
          title={strings.PreferredDriver}
          navigation={this.props.navigation}
        />
        <View style={styles.gridViewBackground}>
          {this.state.dataSource && this.state.dataSource.length > 0 ? (
            <FlatList
              style={{marginTop: 10}}
              data={this.state.dataSource}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({item}) => (
                <View style={styles.flatItemcontainer}>
                  <View style={styles.driverImgView}>
                    <Image
                      resizeMode="cover"
                      style={styles.driverImg}
                      source={
                        item.profileImage == '' ||
                        item.profileImage == 'null' ||
                        item.profileImage == null
                          ? Images.dummyUser
                          : {uri: item.profileImage}
                      }
                    />
                  </View>
                  <View style={{width: '50%'}}>
                    <View style={{width: '100%'}}>
                      <Text style={styles.itemName}>{item.name}</Text>
                    </View>
                    <View style={{flexDirection: 'row', width: '100%'}}>
                      <Text style={styles.cardNumber}>
                        {strings.CarNumber}:
                      </Text>
                      <Text style={styles.platenumber}>
                        {' ' + item.selectedCar.plateNumber}
                      </Text>
                    </View>
                    <View style={{width: '100%'}}>
                      {item.driverStatus == Config.DRIVER_FINDING_TRIPS ? (
                        <Text style={styles.Availabletxt}>
                          {strings.Available}
                        </Text>
                      ) : (
                        <Text style={styles.notAvailable}>
                          {' '}
                          {strings.NotAvailable}
                        </Text>
                      )}
                    </View>
                  </View>
                  <View style={{width: '22%', right: 10}}>
                    {item.driverStatus == Config.DRIVER_FINDING_TRIPS ? (
                      <TouchableOpacity
                        onPress={() => this.bookNow(item._id)}
                        style={styles.booknowbtTouch}>
                        <Text style={styles.booknowTxt}>
                          {' '}
                          {strings.BookNow}
                        </Text>
                      </TouchableOpacity>
                    ) : (
                      <Text> </Text>
                    )}
                  </View>
                </View>
              )}
            />
          ) : (
            <Text style={styles.txtNoLoads}> {strings.NoPreferredDriver} </Text>
          )}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  title: {
    fontSize: 18,
    color: 'white',
    marginTop: wp('2%'),
    alignSelf: 'center',
  },
  gridViewBackground: {
    flex: 1,
    marginTop: 0,
    marginBottom: -50,
    borderColor: 'black',
    borderWidth: 0.0,
    backgroundColor: 'white',
  },
  txtNoLoads: {
    marginTop: 20,
    width: '100%',
    textAlign: 'center',
  },
  driverImgView: {
    width: 76,
    height: 76,
    borderRadius: 76 / 2,
    alignSelf: 'center',
    marginLeft: 10,
  },
  driverImg: {
    width: 72,
    height: 72,
    borderRadius: 72 / 2,
  },
  flatItemcontainer: {
    borderWidth: 0.7,
    borderColor: '#818e97',
    paddingBottom: wp('3%'),
    paddingTop: wp('3%'),
    flexDirection: 'row',
    width: '95%',
    alignItems: 'center',
    justifyContent: 'space-between',
    alignSelf: 'center',
    marginTop: 15,
  },
  itemName: {
    fontFamily: Fonts.Semibold,
    fontSize: wp('4.3%'),
  },
  cardNumber: {
    fontFamily: Fonts.Regular,
    fontSize: wp('3.5%'),
    color: '#000000',
  },
  platenumber: {
    fontFamily: Fonts.Regular,
    width: '50%',
    fontSize: wp('3.5%'),
    top: 2,
  },
  Availabletxt: {
    fontFamily: Fonts.Semibold,
    color: '#0A7C06',
    fontSize: wp('3.3%'),
    marginTop: 3,
  },
  notAvailable: {
    fontFamily: Fonts.Semibold,
    fontSize: wp('3%'),
  },
  booknowbtTouch: {
    width: '100%',
    height: 35,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    backgroundColor: Colors.PrimaryColor,
  },
  booknowTxt: {
    color: 'white',
    fontFamily: Fonts.Semibold,
  },
});
