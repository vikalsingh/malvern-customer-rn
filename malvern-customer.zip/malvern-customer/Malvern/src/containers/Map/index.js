import MapSearch from './MapSearch';
import { PaypalRequest } from './../../modules/GetPaymentMethodList/actions';
import { estimateRequest, getNearBydriver } from './../../modules/EstimateCost/actions';
import { PaymentMethodListRequest } from './../../modules/GetPaymentMethodList/actions';
import { uploadvideoRequest } from '../../modules/Subscribe/actions';
import { addAddressRequest, AddressListRequest, removeAddressRequest, editAddrRequest } from '../../modules/AddAddress/actions';
import {
  addTripRequest,
  ratingRequest,
  panicRequest,
  preferDriverRequest,
  cancelTripRequest,
  couponRequest,
  getTripRequest,
  cancelRatingRequest,
  changeAddressRequest,
} from '../../modules/Trip/actions';
import { connect } from 'react-redux';
const mapStateToProps = (state) => ({
  PaymentListData: state.paymentListReducer.paymentMethodData,
  EstimateCostData: state.estimateCostReducer.estimateData,
  nearByDriverData: state.estimateCostReducer.nearByDriverData,
  ratingData: state.tripReducer.ratingData,
  panicData: state.tripReducer.panicData,
  preferDriverData: state.tripReducer.preferDriverData,
  cancelTripData: state.tripReducer.cancelTripData,
  couponData: state.tripReducer.couponData,
  getTripData: state.tripReducer.getTripData,
  addTripData: state.tripReducer.tripData,
  ProfileData: state.GetProfileReducer.profileData,
  contactsData: state.getContactsReducer.contactsData,
  addDisputeData: state.DisputeReducer.AddDisputeData,
  paypalData: state.paymentListReducer.paypalData,
  changeAddressData: state.tripReducer.ChangeAddressData,
  GetAddressList: state.AddAddressReducer.GetAddressList,

});
const mapDispatchToProps = (dispatch) => ({
  getTripRequest: (tripId, navigation) =>
    dispatch(getTripRequest(tripId, navigation)),
  ratingRequest: (data, navigation) =>
    dispatch(ratingRequest(data, navigation)),
  estimateRequest: (timezone, oneWayitem, stopsArray, dropOnewayitem, surgeData, navigation) =>
    dispatch(
      estimateRequest(timezone, oneWayitem, stopsArray, dropOnewayitem, surgeData, navigation),
    ),
  panicRequest: (data, navigation) => dispatch(panicRequest(data, navigation)),
  preferDriverRequest: (data, navigation) =>
    dispatch(preferDriverRequest(data, navigation)),
  cancelTripRequest: (data, navigation) =>
    dispatch(cancelTripRequest(data, navigation)),
  couponRequest: (data, navigation) =>
    dispatch(couponRequest(data, navigation)),
  cancelRatingRequest: (navigation) =>
    dispatch(cancelRatingRequest(navigation)),
  PaymentMethodListRequest: (navigation) =>
    dispatch(PaymentMethodListRequest(navigation)),
  addTripRequest: (details, navigation) =>
    dispatch(addTripRequest(details, navigation)),
  PaypalRequest: (data, navigation) =>
    dispatch(PaypalRequest(data, navigation)),
  uploadvideoRequest: (videoData, navigation) =>
    dispatch(uploadvideoRequest(videoData, navigation)),
  changeAddressRequest: (data, navigation) =>
    dispatch(changeAddressRequest(data, navigation)),
  addAddressRequest: (name, address, navigation) =>
    dispatch(addAddressRequest(name, address, navigation)),
  mySaveAddrRequest: (navigation) => dispatch(AddressListRequest(navigation)),
  removeAddressRequest: (addressId, navigation) => dispatch(removeAddressRequest(addressId, navigation)),
  editAddrRequest: (data, navigation) => dispatch(editAddrRequest(data, navigation)),
  getNearBydriver: navigation => dispatch(getNearBydriver(navigation)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MapSearch);
