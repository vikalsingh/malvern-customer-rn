import React from 'react';
import {
  View,
  StyleSheet,
  TextInput,
  Text,
  TouchableOpacity,
  Image,
  Platform,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { RFPercentage } from 'react-native-responsive-fontsize';
import Colors from '../../../constants/Colors';
import Images from '../../../constants/Images';

function EnterLocView({
  heading,
  refs,
  placeholder,
  loc,
  onChangeLocation,
  onClearLoc,
  focus,
}) {
  return (
    <View>
      <Text style={{color: 'gray', fontSize: RFPercentage(1.5), marginTop: '.5%'}}>
        {heading}
      </Text>
      <View style={styles.searchSection}>
        <TextInput
          ref={(ref) => {
            refs = ref;
          }}
          // editable={false}
          placeholder={placeholder}
          maxLength={40}
          placeholderTextColor="gray"
          onChangeText={(text) => {
            if (text.length == 1 && text == ' ') {
            } else {
              onChangeLocation(text);
            }
          }}
          // onFocus={() => focus(true)}
          onBlur={() => focus(false)}
          value={loc}
          style={[
            styles.pickuplocation,
            {padding: Platform.OS == 'ios' ? 0 : 0},
          ]}
        />
        {!loc && loc.length == 0 ? null : (
          <TouchableOpacity
            style={styles.clearLocation}
            onPress={() => onClearLoc()}>
            <Image
              resizeMode="contain"
              style={styles.searchIcon}
              source={Images.iconCan}
            />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

export {EnterLocView};

const styles = StyleSheet.create({
  searchSection: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: 'transparent',
  },
  pickuplocation: {
    fontSize: wp('3.4%'),
    height: 35,
    backgroundColor: 'white',
    width: '90%',
    paddingBottom: 10,
    color: 'black',
  },
  clearLocation: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 25,
    height: 25,
  },
  searchIcon: {
    padding: 10,
    width: 10,
    height: 10,
    tintColor: Colors.colorDark,
  },
});
