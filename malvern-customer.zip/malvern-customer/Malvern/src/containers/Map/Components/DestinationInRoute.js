import React, { useEffect } from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Keyboard,
  TouchableHighlight,
  Dimensions,
} from 'react-native';
import Fonts from '../../../constants/Fonts';
import Images from '../../../constants/Images';
import strings from '../../../constants/languagesString';
import Colors from '../../../constants/Colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { TextInput } from 'react-native';
import { RFPercentage } from 'react-native-responsive-fontsize';
let { width, height } = Dimensions.get('window');

function DestinationInRoute({
  driverImage,
  driverName,
  plateNumber,
  driverAvgRtaing,
  estimatedCost,
  preferredDone,
  rideTyp,
  currency,
  panicStatus,
  panicButtonAction,
  preferredAction,
  liveFeedAction,
  record,
  carName,
  AllData,
  onChangeAddress,
  IsChangeAddress,
  addressText,
  onChangeText,
  IsFocus,
  changeFocus,
  keyBoardHeight,
  newText,
  predictions1,
  showSuggestion1,
  changeSuggestion,
  onSelectAddress,
  showOK,
  onOkPress,
  endloaction,
}) {
  // const [isFocus, changeFocus] = useEffect(false);

  // console.log('AllData');
  // console.log(AllData);
  let currentAddress = '';
  if (AllData.stopsArray.length == 0) {
    currentAddress = AllData.endLocationAddr;
  } else {
    let new1 = AllData.stopsArray;
    let stopsArray = new1.sort((a, b) => a.stop - b.stop);
    for (let i = 0; i < stopsArray.length; i++) {
      // console.log(AllData.stopsArray[i]);
      if (stopsArray[i].status != 'completed') {
        currentAddress = stopsArray[i].address;
        break;
      } else {
        if (stopsArray.length - 1 == i) {
          currentAddress = endloaction;
        }
      }
    }
  }

  const predictions = predictions1.map((prediction, index) => (
    <TouchableHighlight
      style={styles.prediction}
      key={index}
      onPress={() => {
        onSelectAddress(prediction);
      }}>
      <Text style={{ margin: 10 }} key={prediction.id}>
        {prediction.description}
      </Text>
    </TouchableHighlight>
  ));
  console.log('update', endloaction);
  return (
    <View style={[styles.popContainer, { bottom: IsFocus ? keyBoardHeight : 0 }]}>
      {/* <View
        style={{
          width: '85%',
          height: 40,
          alignSelf: 'center',
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        {IsChangeAddress ? (
          <TextInput
            style={{width: '75%'}}
            placeholder={strings.Enteraddress}
            placeholderTextColor={'gray'}
            autoCorrect={false}
            returnKeyType={'done'}
            onFocus={() => changeFocus(true)}
            onBlur={() => changeFocus(false)}
            blurOnSubmit={true}
            onSubmitEditing={() => {
              Keyboard.dismiss();
            }}
            onChangeText={(text) => {
              if (text.length == 1 && text == ' ') {
              } else {
                onChangeText(text);
              }
            }}
            value={newText}
          />
        ) : (
          // <View style={{width: '75%', justifyContent: 'center', height: null}}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{height: null, paddingRight: 10}}>
            <Text
              numberOfLines={1}
              style={{
                fontSize: 15,
                fontFamily: Fonts.Regular,
              }}>
              {currentAddress}
            </Text>
          </ScrollView>
          // </View>
        )}

        <View style={{flexDirection: 'row', marginLeft: 10}}>
          {showOK ? (
            <Text
              onPress={() => onOkPress()}
              style={{
                fontSize: 15,
                fontFamily: Fonts.Semibold,
                color: Colors.PrimaryColor,
                marginRight: 10,
              }}>
              {'Ok'}
            </Text>
          ) : null}

          <Text
            onPress={() => {
              onChangeAddress(IsChangeAddress ? false : true);
              if (IsChangeAddress) {
                changeFocus(false);
                changeSuggestion();
              }
            }}
            style={{
              fontSize: 15,
              fontFamily: Fonts.Semibold,
              color: Colors.PrimaryColor,
            }}>
            {IsChangeAddress ? 'Cancel' : 'Change'}
          </Text>
        </View>
      </View> */}
      <View style={styles.poprowfirst}>
        <View style={styles.profileimgView}>
          <Image
            style={styles.profileimg}
            source={
              driverImage == '' ||
                driverImage == null ||
                driverImage == 'null' ||
                driverImage == 'none'
                ? Images.dummyUser
                : { uri: driverImage }
            }
          />
          <Text style={styles.driverNametxt}>{driverName}</Text>
        </View>

        <View
          style={{
            width: '30%',
            justifyContent: 'center',
            alignItems: 'flex-start',
            marginLeft: wp(4)
          }}>
          <View
            style={{
              borderRadius: 10,
              paddingTop: 2,
              paddingBottom: 2,
              paddingRight: 8,
              alignItems: 'center',

            }}>
            <View style={{ flexDirection: 'row' }}>
              <Text>Car Number: </Text>
              <Text style={styles.plateNum}>
                {plateNumber}
              </Text>
            </View>
          </View>

          <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <Text style={styles.carName}>
              {carName}
            </Text>
            <View style={{ flexDirection: 'row', marginLeft: wp(18), alignItems: 'center' }}>
              <Text>{driverAvgRtaing}</Text>
              <Image
                style={{
                  height: hp(4),
                  width: wp(4),
                  left: 3,
                  resizeMode: 'contain',
                }}
                source={Images.star_blackIcon}
              />
            </View>
          </View>

          <View style={{ flexDirection: 'row' }}>
            <Text style={{ alignSelf: 'center' }}>Price </Text>
            <Text style={styles.priceShow}> {currency}{estimatedCost}</Text>
          </View>
        </View>
        <View
          style={{
            width: '40%',
            alignItems: 'center',
          }}>
          {/* <TouchableOpacity
            onPress={() => {
              Keyboard.dismiss();
              changeFocus(false);
              record();
            }}
            style={styles.panicBtTouch}>
            <Image style={styles.panicButtonimg} source={Images.rec} />
          </TouchableOpacity> */}
          {/* <TouchableOpacity
            onPress={() => {
              Keyboard.dismiss();
              changeFocus(false);
              liveFeedAction();
            }}
            style={styles.panicBtTouch}>
            <Image style={styles.panicButtonimg1} source={Images.videoGroup} />
          </TouchableOpacity> */}
          <TouchableOpacity
            onPress={() => {
              Keyboard.dismiss();
              changeFocus(false);
              panicButtonAction();
            }}
            style={styles.panicBtTouch}>
            <Image style={styles.panicButtonimg1} source={Images.sos_ic} />
          </TouchableOpacity>
        </View>
      </View>

      {/* {!preferredDone ? (
        <TouchableOpacity
          onPress={() => {
            Keyboard.dismiss();
            changeFocus(false);
            preferredAction();
          }}
          style={styles.prefferedTouch2}>
          <Image style={styles.onlineImg} source={Images.perferDriver} />
          <Text style={[styles.liveFeedtext1, {width: '80%'}]}>
            {strings.preferredtxt}
          </Text>
        </TouchableOpacity>
      ) : null} */}

      {showSuggestion1 ? (
        <View style={{ position: 'absolute', top: 42, backgroundColor: 'white' }}>
          {predictions}
        </View>
      ) : null}
    </View>
  );
}

export { DestinationInRoute };

const styles = StyleSheet.create({
  popContainer: {
    backgroundColor: 'white',
    width: width,
    height: 140,
    bottom: 0,
    flexDirection: 'column',
  },
  poprowfirst: {
    backgroundColor: 'white',
    width: width,
    height: 100,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  profileimgView: {
    width: '30%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileimg: {
    width: 50,
    height: 50,
    borderRadius: 25,
    resizeMode: 'cover',
  },
  liveFeedtext1: {
    marginLeft: 10,
    fontSize: 15,
    color: 'white',
    fontFamily: Fonts.Regular,
  },
  liveFeedtext: {
    fontSize: 16,
    fontFamily: Fonts.Regular,
  },
  onlineImg: {
    width: 25,
    height: 25,
    borderRadius: 25,
    resizeMode: 'cover',
  },
  panicButtonimg1: {
    width: 42,
    height: 42,
    resizeMode: 'contain',
  },
  panicButtonimg: {
    width: 50,
    height: 50,
    resizeMode: 'contain',
  },
  panicBtTouch: {
    backgroundColor: 'white',
    width: '20%',
    height: '100%',
    justifyContent: 'center',
  },
  driverNametxt: {
    fontSize: 16,
    fontFamily: Fonts.Semibold,
    margin: 2,
  },
  livefeedActionTouch: {
    width: '50%',
    height: 60,
    backgroundColor: '#f2f2f2',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom: 10,
  },
  livefeedActionTouch2: {
    width: '100%',
    height: 60,
    backgroundColor: '#f2f2f2',
    flexDirection: 'row',
    justifyContent: 'center',
    paddingBottom: 15,
    alignItems: 'center',
  },
  prefferedChildTouch: {
    borderColor: 'red',
    borderWidth: 1,
    width: '100%',
    height: 60,
    backgroundColor: '#f2f2f2',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  prefferedTouch: {
    width: '50%',
    height: 60,
    backgroundColor: Colors.buttonsColor,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  prefferedTouch2: {
    width: '100%',
    height: 50,
    backgroundColor: Colors.buttonsColor,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  prediction: {
    paddingVertical: 5,
    borderBottomWidth: 1.0,
    borderColor: 'gray',
  },
  priceShow: {
    fontFamily: Fonts.Semibold,
    fontSize: RFPercentage(2.5)
  },
  carName: {
    color: 'black',
    marginTop: 5,
    alignItems: 'flex-start'
  },
  plateNum: {
    color: '#000',
    fontFamily: Fonts.Semibold,
    backgroundColor: Colors.graylighted,
  }
});
