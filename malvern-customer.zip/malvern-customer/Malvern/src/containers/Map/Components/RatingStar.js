import React from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  Keyboard,
} from 'react-native';
import Colors from '../../../constants/Colors';
import {strings} from '../../../constants/languagesString';
import Fonts from '../../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Images from '../../../constants/Images';
import {Platform} from 'react-native';

function Star({ratingValue, onPress}) {
  return (
    <TouchableOpacity onPress={() => onPress()}>
      {ratingValue ? (
        <Image style={styles.fillstar} source={Images.filled_star} />
      ) : (
        <Image style={styles.emptyStar} source={Images.empty_star} />
      )}
    </TouchableOpacity>
  );
}

function RatingFeedBack({
  currency,
  ratingValue,
  value,
  onChangeText,
  orderTotal,
  tip,
  ontip,
  CustomTip,
  onCustomTip,
  onPress,
  onSubmit,
  onDispute,
}) {
  return (
    <View style={styles.ratingViewContainer}>
      <View style={styles.emptyView} />

      <View style={styles.ratingViewTextContainer}>
        <Image
          source={Images.rightImg}
          style={{width: 65, height: 65, marginTop: 15}}
        />
        <Text style={styles.thankYouText}>{strings.thankYouForRide}</Text>

        <Text style={styles.totalValueText}>
          {currency + ' ' + parseFloat(orderTotal).toFixed(2)}
        </Text>
        <View style={styles.starContainer}>
          <Star ratingValue={ratingValue >= 1} onPress={() => onPress(1)} />
          <Star ratingValue={ratingValue >= 2} onPress={() => onPress(2)} />
          <Star ratingValue={ratingValue >= 3} onPress={() => onPress(3)} />
          <Star ratingValue={ratingValue >= 4} onPress={() => onPress(4)} />
          <Star ratingValue={ratingValue >= 5} onPress={() => onPress(5)} />
        </View>

        {/* <Text
          style={{
            marginTop: 20,
            fontSize: wp('4.8%'),
            fontFamily: Fonts.Semibold,
          }}>
          Tip
        </Text> */}

        {/* <View
          style={{
            width: '85%',
            height: 60,
            justifyContent: 'space-between',
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <TouchableOpacity
            style={{
              width: '15%',
              height: 30,
              borderRadius: 15,
              justifyContent: 'center',
              alignItems: 'center',
              shadowColor: Colors.graylight,
              shadowOffset: {width: 0, height: 1},
              shadowOpacity: 0.8,
              elevation: 5,
              backgroundColor:
                tip == '0' && CustomTip == '' ? Colors.buttonsColor : 'white',
            }}
            onPress={() => {
              Keyboard.dismiss();
              ontip('0');
            }}>
            <Text
              style={{
                fontFamily: Fonts.Semibold,
                fontSize: 15,
                color: tip == '0' && CustomTip == '' ? 'white' : 'black',
              }}>
              0 {currency}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              width: '15%',
              height: 30,
              borderRadius: 15,
              justifyContent: 'center',
              alignItems: 'center',
              shadowColor: Colors.graylight,
              shadowOffset: {width: 0, height: 1},
              shadowOpacity: 0.8,
              elevation: 5,
              backgroundColor:
                tip == '5' && CustomTip == '' ? Colors.buttonsColor : 'white',
            }}
            onPress={() => {
              Keyboard.dismiss();
              ontip('5');
            }}>
            <Text
              style={{
                fontFamily: Fonts.Semibold,
                fontSize: 15,
                color: tip == '5' && CustomTip == '' ? 'white' : 'black',
              }}>
              5 {currency}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              width: '15%',
              height: 30,
              borderRadius: 15,
              justifyContent: 'center',
              alignItems: 'center',
              shadowColor: Colors.graylight,
              shadowOffset: {width: 0, height: 1},
              shadowOpacity: 0.8,
              elevation: 5,
              backgroundColor:
                tip == '10' && CustomTip == '' ? Colors.buttonsColor : 'white',
            }}
            onPress={() => {
              Keyboard.dismiss();
              ontip('10');
            }}>
            <Text
              style={{
                fontFamily: Fonts.Semibold,
                fontSize: 15,
                color: tip == '10' ? 'white' : 'black',
              }}>
              10 {currency}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              width: '15%',
              height: 30,
              borderRadius: 15,
              justifyContent: 'center',
              alignItems: 'center',
              shadowColor: Colors.graylight,
              shadowOffset: {width: 0, height: 1},
              shadowOpacity: 0.8,
              elevation: 5,
              backgroundColor:
                tip == '20' && CustomTip == '' ? Colors.buttonsColor : 'white',
            }}
            onPress={() => {
              Keyboard.dismiss();
              ontip('20');
            }}>
            <Text
              style={{
                fontFamily: Fonts.Semibold,
                fontSize: 15,
                color: tip == '20' && CustomTip == '' ? 'white' : 'black',
              }}>
              20 {currency}
            </Text>
          </TouchableOpacity>
          <View
            style={{
              width: '25%',
              justifyContent: 'center',
              height: 30,
            }}>
            <TextInput
              placeholder={'custom'}
              value={CustomTip}
              returnKeyType={'done'}
              keyboardType={'number-pad'}
              style={{
                shadowColor: Colors.graylight,
                shadowOffset: {width: 0, height: 1},
                backgroundColor:
                  CustomTip == '' ? 'white' : Colors.buttonsColor,
                padding: 0,
                margin: 0,
                fontSize: 15,
                width: '100%',
                height: Platform.OS == 'ios' ? 30 : null,

                borderRadius: 15,
                shadowOpacity: 0.8,
                elevation: 5,

                color: CustomTip == '' ? 'black' : 'white',
                justifyContent: 'center',
                alignItems: 'center',
                textAlign: 'center',
              }}
              onChangeText={(text) => {
                onCustomTip(text.replace(/[^0-9]/g, ''));
              }}
            />
          </View>
        </View> */}

        <View
          style={{
            width: '85%',
            marginTop: 20,
            backgroundColor: Colors.graylighted,
            borderRadius: 8,
            padding: 10,
          }}>
          <TextInput
            style={styles.instructionsInput}
            placeholder={strings.enterMessage}
            placeholderTextColor={'gray'}
            multiline={true}
            autoCorrect={false}
            returnKeyType={'done'}
            blurOnSubmit={true}
            onSubmitEditing={() => {
              Keyboard.dismiss();
            }}
            onChangeText={(text) => {
              if (text.length == 1 && text == ' ') {
              } else {
                onChangeText(text);
              }
            }}
            value={value}
          />
        </View>
        <View
          style={{
            width: '100%',
            // flexDirection: 'row',
            // justifyContent: 'center',
            alignItems: 'center'
          }}>
          <TouchableOpacity
            onPress={() => onSubmit()}
            style={styles.submitTouc}>
            <Text style={styles.title}> {strings.Submit} </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => onDispute()}
            style={[
              styles.disputeTouc,
              {marginLeft: 10, backgroundColor: 'white'},
            ]}>
            <Text
              style={[
                styles.title,
                {color: 'black', fontFamily: Fonts.Regular},
              ]}>
              {' '}
              {'Dispute'}{' '}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
export {RatingFeedBack};

const styles = StyleSheet.create({
  ratingViewContainer: {
    flex: 1,
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: 'transparent',
  },
  emptyView: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: 'white',
    opacity: 0.9,
  },
  ratingViewTextContainer: {
    backgroundColor: 'white',
    borderRadius: 5,
    width: wp('85%'),
    alignItems: 'center',
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
  },
  thankYouText: {
    width: 'auto',
    fontFamily: Fonts.Semibold,
    textAlign: 'center',
    marginHorizontal: 25,
    marginTop: 20,
    fontSize: wp('4.8%'),
  },
  totalText: {
    width: 'auto',
    fontFamily: Fonts.Semibold,
    textAlign: 'center',
    marginHorizontal: 25,
    marginTop: 20,
    color: Colors.Black,
    fontSize: wp('5.86%'),
  },
  totalValueText: {
    width: 'auto',
    fontFamily: Fonts.Semibold,
    textAlign: 'center',
    marginHorizontal: 25,
    marginTop: 15,
    color: Colors.FontDarkColor,
    fontSize: wp('8%'),
  },
  starContainer: {
    height: 35,
    backgroundColor: 'transparent',
    marginTop: wp('2%'),
    width: 'auto',
    flexDirection: 'row',
  },
  fillstar: {
    width: wp('9%'),
    height: wp('9%'),
    resizeMode: 'contain',
  },
  emptyStar: {
    width: wp('9%'),
    height: wp('9%'),
    resizeMode: 'contain',
  },
  submitTouc: {
    width: '84%',
    height: wp('13%'),
    borderRadius: wp('13%'),
    marginTop: wp('8%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.PrimaryColor,
    // shadowColor: Colors.graylight,
    // shadowOffset: {width: 0, height: 1},
    // shadowOpacity: 0.8,
    // elevation: 5,
  },
  disputeTouc: {
    width: '32%',
    height: wp('8%'),
    marginTop: wp('4%'),
    marginBottom: wp(5),
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    color: 'white',
    fontFamily: Fonts.Semibold,
  },

  DeliveryFeeView: {
    marginTop: wp('1%'),
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '90%',
    alignSelf: 'center',
  },
  deliveryTitle: {
    backgroundColor: 'transparent',
    fontSize: wp('4.50%'),
    fontFamily: Fonts.Regular,
    color: Colors.PrimaryColor,
  },
  deliveryValue: {
    backgroundColor: 'transparent',
    fontSize: wp('4.50%'),
    fontFamily: Fonts.Regular,
    color: Colors.PrimaryColor,
  },
  instructionsInput: {
    height: 100,
    padding: 0,
    width: '100%',
    textAlignVertical: 'top',
    fontSize: 15,
  },
});
