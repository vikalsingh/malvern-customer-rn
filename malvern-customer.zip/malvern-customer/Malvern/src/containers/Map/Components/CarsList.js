import React from 'react';
import {
  TouchableOpacity,
  Keyboard,
  Image,
  Text,
  StyleSheet,
  View,
  TextInput,
  FlatList,
} from 'react-native';
import Fonts from '../../../constants/Fonts';
import Images from '../../../constants/Images';
import Colors from '../../../constants/Colors';
import {strings} from '../../../constants/languagesString';
import {RenderHeaderBack} from '../../../components/CustomComponent/renderHeader';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

//=============== Ride Type Name =================//
function RideNameType({type, text, onclick}) {
  return (
    <TouchableOpacity
      style={styles.standardOptionView}
      onPress={() => onclick()}>
      <Image
        resizeMode="contain"
        style={{width: 15, height: 15}}
        source={type ? Images.selected : Images.unselected}
      />
      <Text style={styles.carListOptionText}>{text}</Text>
    </TouchableOpacity>
  );
}

//=============== Ride Description View =================//

function RideDescription({onClose, value, onChangeText, onSubmit}) {
  return (
    <View style={styles.desViewContainer}>
      <View style={styles.desViewContainer2}>
        <RenderHeaderBack
          title={strings.RideDescription}
          onBack={() => onClose()}
        />

        <View
          style={{
            width: '85%',
            marginTop: 20,
            backgroundColor: Colors.graylighted,
            borderRadius: 8,
            padding: 10,
          }}>
          <TextInput
            style={styles.instructionsInput}
            placeholder={strings.enterMessage}
            placeholderTextColor={'gray'}
            multiline={true}
            autoCorrect={false}
            returnKeyType={'done'}
            blurOnSubmit={true}
            onSubmitEditing={() => {
              Keyboard.dismiss();
            }}
            onChangeText={(descriptionRideString) => {
              if (
                descriptionRideString.length == 1 &&
                descriptionRideString == ' '
              ) {
              } else {
                onChangeText(descriptionRideString);
              }
            }}
            value={value}
          />
        </View>

        <View
          style={{
            flexDirection: 'row',
            marginTop: 20,
            justifyContent: 'space-between',
            width: '85%',
            alignSelf: 'center',
          }}>
          <TouchableOpacity onPress={() => onSubmit()} style={styles.submitBt}>
            <Text style={styles.submitTxt}>{strings.Submit}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => onClose()}
            style={[styles.submitBt, {backgroundColor: 'white'}]}>
            <Text style={[styles.submitTxt, {color: 'black'}]}>
              {strings.CancelTrip}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

//====================== Ride Share Select Seat View ====================//
function ShareSelectSeats({
  currency,
  estimatedCost,
  seats,
  onSeatChange,
  onConfirm,
  onClose,
}) {
  return (
    <View style={styles.shareSeatContainer}>
      <View style={styles.shareSeatHeader}>
        <Text style={styles.shareText}>{strings.shareRide}</Text>
        <Text>
          {currency}
          {estimatedCost}
        </Text>
      </View>

      <View style={styles.sepratorLine} />

      <View style={styles.seatSelectingView}>
        <Text style={styles.seatavailbetext}>{strings.seatsAvailable}</Text>

        <View style={styles.arrowTile1}>
          <TouchableOpacity
            style={{
              backgroundColor: seats == 1 ? Colors.PrimaryColor : 'transparent',
              borderWidth: 2,
              borderColor: seats == 1 ? 'transparent' : 'black',
              marginLeft: 20,
              height: wp('8%'),
              width: wp('8%'),
              borderRadius: wp('8%'),
              justifyContent: 'center',
              alignItems: 'center',
            }}
            onPress={() => onSeatChange(1)}>
            <Text style={{color: seats == 1 ? 'white' : 'black'}}>1</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              backgroundColor: seats == 2 ? Colors.PrimaryColor : 'transparent',
              borderWidth: 2,
              borderColor: seats == 2 ? 'transparent' : 'black',
              marginLeft: 20,
              height: wp('8%'),
              width: wp('8%'),
              borderRadius: wp('8%'),
              justifyContent: 'center',
              alignItems: 'center',
            }}
            onPress={() => onSeatChange(2)}>
            <Text style={{color: seats == 2 ? 'white' : 'black'}}>2</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.seatShowView}>
        <View style={{flexDirection: 'column'}}>
          <Text style={styles.seatavailbetext}>{strings.seatSelect}</Text>
        </View>

        <View style={{position: 'absolute', right: 50}}>
          <Text>{seats}</Text>
        </View>
      </View>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'center',
          marginHorizontal: 30,
          marginTop: Platform.OS === 'ios' ? wp('14%') : wp('17%'),
        }}>
        <TouchableOpacity
          onPress={() => onConfirm()}
          style={styles.confirmSharetouch}>
          <Text style={styles.cancelWhite}>{strings.confirmShare}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => onClose()}
          style={styles.closeTouchView}>
          <Text style={styles.cancelWhite}>{strings.cancelShare}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

//========================= Payment List View =======================//

function PaymentList({PaymentListData, payAction, navigation, onCancel}) {
  return (
    <View style={styles.desViewContainer}>
      <View style={styles.paymentviewContainer}>
        <View style={styles.paymentheaderview}>
          <Text style={styles.paymentheaderText}>
            {strings.SelectPaymentMethod}
          </Text>
        </View>
        <FlatList
          data={PaymentListData}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => payAction(item)}
              style={
                item.type === 'Card' ? styles.loadDetail : styles.loadDetail2
              }>
              <View
                style={{
                  width: '20%',
                  marginLeft: item.type === 'Card' ? 7 : 0,
                }}>
                <Image
                  resizeMode="contain"
                  style={{height: 30, width: 30}}
                  source={{uri: item.logo}}
                />
              </View>
              <Text style={styles.paymentItemText}>
                {item.type === 'Card'
                  ? '***********' + item.lastd
                  : item.type === 'Wallet'
                  ? strings.appWallet
                  : item.type === 'Paypal'
                  ? 'Paypal'
                  : strings.cashPay}
              </Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item._id.toString()}
        />
        <TouchableOpacity
          onPress={() => navigation.navigate('AddCard')}
          style={styles.addCardTouch}>
          <Text style={styles.addCardText}>{strings.AddCard}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => onCancel()} style={styles.cancelTouch}>
          <Image source={Images.cancelWhite} style={styles.cancelIc} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

export {RideNameType, RideDescription, ShareSelectSeats, PaymentList};

const styles = StyleSheet.create({
  standardOptionView: {
    width: '30%',
    marginLeft: 10,
    height: 40,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    flexDirection: 'row',
    alignItems: 'center',
  },
  carListOptionText: {
    color: 'black',
    fontFamily: Fonts.Semibold,
    fontSize: 14,
    backgroundColor: 'transparent',
    marginLeft: 10,
  },
  desViewContainer: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  desViewContainer2: {
    width: '100%',
    height: '100%',
    backgroundColor: 'white',
    alignItems: 'center',
    opacity: 1,
    borderRadius: 5,
  },
  desHeader: {
    backgroundColor: Colors.PrimaryColor,
    borderTopRightRadius: 5,
    borderTopLeftRadius: 5,
    height: 48,
    width: '100%',
  },
  desHeaderTxt: {
    fontFamily: Fonts.Semibold,
    color: 'white',
    fontSize: 18,
    marginTop: 10,
  },
  closeTouch: {
    width: 45,
    height: 45,
    backgroundColor: 'transparent',
    right: 0,
    top: -35,
    left: '87%',
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 1,
  },
  submitBt: {
    width: '48%',
    height: 50,
    backgroundColor: Colors.PrimaryColor,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
  },
  submitTxt: {
    fontFamily: Fonts.Semibold,
    color: Colors.White,
    fontSize: 16,
  },
  instructionsInput: {
    height: hp('45%'),
    padding: 0,
    width: '100%',
    textAlignVertical: 'top',
    fontSize: 15,
  },

  paymentviewContainer: {
    width: '80%',
    height: 260,
    backgroundColor: 'white',
    marginTop: 8,
    borderRadius: 5,
  },
  paymentheaderview: {
    backgroundColor: Colors.PrimaryColor,
    borderTopRightRadius: 5,
    borderTopLeftRadius: 5,
    height: 50,
    width: '100%',
  },
  paymentheaderText: {
    marginLeft: 8,
    fontFamily: Fonts.Semibold,
    fontSize: 18,
    marginTop: 10,
    color: Colors.White,
  },
  loadDetail: {
    backgroundColor: '#E9E9E9',
    borderColor: '#E9E9E9',
    marginBottom: 8,
    marginLeft: '5%',
    marginRight: '5%',
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    padding: 10,
    shadowRadius: 5,
    borderBottomWidth: 0.0,
  },
  loadDetail2: {
    marginLeft: '5%',
    marginRight: '5%',
    height: 50,
    marginTop: 10,
    flexDirection: 'row',
    padding: 15,
    backgroundColor: '#E9E9E9',
    alignItems: 'center',
  },
  paymentItemText: {
    fontFamily: Fonts.Semibold,
    fontSize: 15,
  },
  addCardTouch: {
    marginBottom: '5%',
    justifyContent: 'flex-end',
    width: '100%',
  },
  addCardText: {
    fontFamily: Fonts.Semibold,
    fontSize: 18,
    alignSelf: 'flex-end',
    marginRight: '5%',
  },
  cancelTouch: {
    position: 'absolute',
    right: 2,
    top: 8,
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  cancelIc: {
    height: 15,
    width: 15,
    tintColor: 'white',
  },
  arrowTile1: {
    backgroundColor: 'transparent',
    flexDirection: 'row',
    position: 'absolute',
    right: 40,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0,
    borderColor: '#818e97',
  },
  shareSeatContainer: {
    height: 320,
    width: '100%',
    backgroundColor: 'white',
    position: 'absolute',
    bottom: 0,
  },
  shareSeatHeader: {
    flexDirection: 'row',
    backgroundColor: 'white',
    width: '85%',
    height: 40,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  shareText: {
    fontFamily: Fonts.Semibold,
    fontSize: 16,
  },
  sepratorLine: {
    borderBottomWidth: 2,
    borderBottomColor: '#CACDD4',
  },
  seatSelectingView: {
    flexDirection: 'row',
    backgroundColor: 'white',
    width: '100%',
    marginTop: wp('14%'),
  },
  seatavailbetext: {
    fontFamily: Fonts.Regular,
    fontSize: 15,
    left: 30,
  },
  seatShowView: {
    flexDirection: 'row',
    backgroundColor: 'white',
    width: '100%',
    marginTop: wp('10%'),
  },
  closeTouchView: {
    width: '50%',
    height: wp('12%'),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 27,
    backgroundColor: Colors.buttonRed,
  },
  cancelWhite: {
    color: 'white',
    fontFamily: Fonts.Semibold,
    fontSize: 18,
  },
  confirmSharetouch: {
    width: '50%',
    height: wp('12%'),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 27,
    marginRight: 10,
    backgroundColor: Colors.PrimaryColor,
  },
});
