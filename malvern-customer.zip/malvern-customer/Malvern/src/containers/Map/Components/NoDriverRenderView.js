import React from 'react';
import {
  View,
  StyleSheet,
  Image,
  Text,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import Colors from '../../../constants/Colors';
import Images from '../../../constants/Images';
import {strings} from '../../../constants/languagesString';
import {PulseIndicator} from 'react-native-indicators';
import {getStatusBarHeight} from '../../../utils/IPhoneXHelper';

function NoDriverRenderView({onClick}) {
  return (
    <View needsOffscreenAlphaCompositing={true} style={styles.container}>
      <View style={styles.UpperView}>
        <Image
          style={styles.NoDriverImg}
          source={Images.noDriver}
          resizeMode={'cover'}
        />
        <Text style={styles.oopsText}>{strings.OOPS}</Text>
        <Text style={styles.NearLocationText}>{strings.NoDriverFound}</Text>
        <Text style={styles.NearLocationText}>{strings.NearYourLocation}</Text>
      </View>

      <View style={styles.ButtonView}>
        <TouchableOpacity
          onPress={() => onClick()}
          style={styles.TouchViewButton}>
          <Text style={styles.ButtonText}>{strings.GotoDashboard}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function SearchingView({onPress}) {
  return (
    <View style={styles.container1}>
      <View style={styles.container2} />

      <PulseIndicator
        size={Dimensions.get('window').width * 0.3}
        color={'#000'}
      />

      {/* <ImageBackground style={styles.headerView3}>
        <TouchableOpacity style={styles.backtouch} onPress={() => onPress()}>
          <Image style={styles.backic} source={Images.cancel_ic} />
        </TouchableOpacity>
      </ImageBackground> */}
    </View>
  );
}

export {NoDriverRenderView, SearchingView};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    flex: 1,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  UpperView: {
    width: '100%',
    height: 200,
    backgroundColor: 'white',
    alignItems: 'center',
    opacity: 1,
  },
  NoDriverImg: {
    width: 70,
    height: 70,
    borderRadius: 35,
  },
  oopsText: {
    fontSize: 18,
    fontWeight: '500',
    color: Colors.buttonRed,
    top: 10,
  },
  NearLocationText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: 'black',
    top: 10,
  },
  ButtonView: {
    width: '100%',
    height: 100,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 1,
  },
  TouchViewButton: {
    width: '60%',
    height: 50,
    borderRadius: 25,
    backgroundColor: Colors.PrimaryColor,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ButtonText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: 'white',
  },

  container1: {
    flex: 1,
    height: '100%',
    width: '100%',
    position: 'absolute',
   
  },
  container2: {
    position: 'absolute',
    height: '100%',
    width: '100%',
    backgroundColor: 'black',
    opacity: 0.1,
  },
  headerView3: {
    height: Platform.select({
      ios: 40 + getStatusBarHeight(),
      android: 50,
    }),
    width: '100%',
    position: 'absolute',
    alignItems: 'center',
    paddingTop: Platform.select({
      ios: getStatusBarHeight(),
      android: 0,
    }),
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  backtouch: {
    marginLeft: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
    backgroundColor: 'white',
    borderRadius: 30,
  },
  backic: {
    resizeMode: 'contain',
    width: 15,
    height: 15,
  },
});
