import React from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  View,
  Image,
  Text,
  TextInput,
  TouchableOpacity,
  Keyboard,
  Platform,
  TouchableHighlight,
  Animated,
  PermissionsAndroid,
  Share,
  KeyboardAvoidingView,
  Dimensions,
  FlatList,
  Alert,
  ScrollView,
  BackHandler,
  AppState,
  Linking,
  PixelRatio,
  SafeAreaView,
} from 'react-native';
import SendSMS from 'react-native-sms';
const keyboardVerticalOffset = Platform.OS === 'ios' ? 0 : 0;
const widthCal = Dimensions.get('window').width;
const heightCal = Dimensions.get('window').height;
import DateTimePicker from 'react-native-modal-datetime-picker';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { RFPercentage } from 'react-native-responsive-fontsize';
import { DrawerActions } from '@react-navigation/native';
import MapView, { Callout, PROVIDER_GOOGLE } from 'react-native-maps';
import { isEmpty } from '../../utils/CommonFunctions';
import Geolocation from 'react-native-geolocation-service';
import Geocoder from 'react-native-geocoding';
Geocoder.init(Config.GOOGLE_MAPS_APIKEY);
import SocketIOClient from 'socket.io-client';
import BackgroundTimer from 'react-native-background-timer';
import { getConfiguration, setConfiguration } from '../../utils/configuration';
import MapViewDirections from 'react-native-maps-directions';
import { strings } from '../../constants/languagesString';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';
import VectorIcon from '../../utils/vectorIcons';
import { DotIndicator } from 'react-native-indicators';
import moment from 'moment-timezone';
import MapMarker from '../../components/Marker/MapMarker';
var qs = require('qs');
// import {AgoraView} from 'react-native-agora';
// import {RtcEngine, AgoraView} from 'react-native-agora';

import RtcEngine, {
  RtcLocalView,
  RtcRemoteView,
  VideoRenderMode,
} from 'react-native-agora';

import Icon from 'react-native-vector-icons/MaterialIcons';
import Config from '../../constants/Config';
import { fcmService } from '../../components/Notification/FCMService';
import { localNotificationService } from '../../components/Notification/LocalNotificationService';
import PushNotification from 'react-native-push-notification';

import { getStatusBarHeight } from '../../utils/IPhoneXHelper';
import {
  SearchingView,
  NoDriverRenderView,
  RideNameType,
  RideDescription,
  PaymentList,
  ShareSelectSeats,
  EnterLocView,
  DestinationInRoute,
  RatingFeedBack,
} from './Components/index';
import { WebView } from 'react-native-webview';
// import RecordScreen from 'react-native-record-screen';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import axios from 'axios';

let dimensions = {
  //get dimensions of the device to use in view styles
  width: Dimensions.get('window').width,
  height: Dimensions.get('window').height,
};
const ASPECT_RATIO = dimensions.width / dimensions.height;
const LATITUDE_DELTA = 0.0922;
//const LATITUDE_DELTA = 0.009;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
const timezone = moment.tz.guess();
let hit = 0;

export default class MapSearch extends React.Component {
  constructor(props) {
    super(props);
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
    this.backHandler = null;
    this.state = {
      dataSource: {},
      predictions: [],
      selSourcePlaceId: '',
      showSuggestion: false,
      curLatitude: 0,
      curLongitude: 0,
      isDatePickerVisible: false,
      isTimePickerVisible: false,
      sourceLocation: '',
      destinationLocation: '',
      FirstStopLocation: '',
      SecondStopLocation: '',
      destinationPlaceID: '',
      estimatedTime: 0,
      distance: 0,
      destLong: 0,
      destLat: 0,
      tripStatus: 'fresh',
      savedPlacesView: false,
      addPlacesVIew: false,
      addrName: '',
      addPlaceAddress: '',
      addPlaceAddressPlaceId: '',
      addressId: '',
      addressType: 'add',
      showAddressSuggestion: false,
      addrName: '',
      ratingValue: 0,
      FindDriver: false,
      NoDriverFoundView: false,
      panicStatus: false,
      driverLatitude: 0,
      driverLongitude: 0,
      shareMessage: '',
      endLocationAddr: '',
      preferredClick: false,
      driverId: '',
      preferredDone: false,
      prefDriverRide: 'none',
      driverIdPref: '',
      driverMobileCode: '',
      driverMobileNumber: '',
      showcoupon: true,
      Schedule: false,
      showitem: false,
      driverdetails: false,
      curLat: 0,
      curLong: 0,
      curAddress: '',
      destAddress: '',
      bikeSelected: '',
      estimationCostArr: [],
      paymentTap: false,
      cardList: [],
      selectedCardNum: strings.Selectcard,
      selectedCardImage: '',
      selectedCardID: '',
      promoCode: '',
      points: '',
      date: '',
      Time: '',
      tripId: '',
      estimatedCost: '',
      ScheduleSetup: false,
      minDateSel: '',
      walletBalance: 0,
      walletView: false,
      estimateComparision: '',
      PaymentVia: '',
      selectedRide: 'standard',
      RideDes: false,
      descriptionRideString: '',
      SourcePick: {
        address_components: '',
        formatted_address: '',
        place_id: '',
        location: {
          lat: '',
          long: '',
        },
      },
      dropOneway: {
        address_components: '',
        formatted_address: '',
        place_id: '',
        location: {
          lat: '',
          long: '',
        },
      },
      FirstLocationPick: {
        address_components: '',
        formatted_address: '',
        place_id: '',
        location: {
          lat: '',
          long: '',
        },
      },
      SecondLocationPick: {
        address_components: '',
        formatted_address: '',
        place_id: '',
        location: {
          lat: '',
          long: '',
        },
      },
      isShared: false,
      isSingle: 1,
      shareView: false,
      AddTripArray: [],
      rideTyp: 'standard',
      TimeZoneSelected: moment.tz.guess(),
      showCurLat: 0,
      showCurLng: 0,
      showdestLat: 0,
      ShowdestLng: 0,
      ChildVideo: false,
      currency: '£',
      peerIds: [], //Array for storing ctcted peers
      uid: Math.floor(Math.random() * 100), //Generate a UID for local user
      // appid: '78c6b199638444d49aa47b2fcf7e25db', //Enter the App ID generated from the Agora Website
      channelName: '1111122222', //Channel Name for the current session
      vidMute: true, //State variable for Video Mute
      audMute: true, //State variable for Audio Mute
      joinSucceed: false, //State variable for storing success
      // appid: 'e76630b77d5d42408dc0e575f0aefbd5',
      // appid: 'e964eee8d52e4d9e944573c837d3fd60',with TOken
      appid: 'f704b47d663440238ac95ad939ab1fb2',
      // without token
      tokenAgo:
        '006e964eee8d52e4d9e944573c837d3fd60IABqhhEN/UjKTD5F7Q0yf+wKqFAA6KK2K+qpHFOVAhd+OAJkFYoAAAAAEACbQyLuLwO/YAEAAQAuA79g',
      channelName: 'channel-x',
      // e964eee8d52e4d9e944573c837d3fd60
      estimateCost: [],
      stoplatlong: [],
      getTripData: '',
      addTripData: '',
      ratingData: '',
      panicData: '',
      preferDriverData: '',
      cancelTripData: '',
      couponData: '',
      PaymentListData: [],
      driverLocation: {
        latitude: 30.71335,
        longitude: 76.71701,
      },
      appState: AppState.currentState,
      StopsCount: 0,
      Loctype: '',
      Datos: '',
      StopsArray: [],
      carName: '',
      CancelView: false,
      feedbackTxt: '',
      tipAmount: '0',
      tripData: '',
      PaypalUrl: '',
      showModal: false,
      recording: false,
      CustomTip: '',
      addressPicker: false,
      sourcefocus: false,
      mapAddress: '',
      AllData: '',
      IsChangeAddress: false,
      IsFocus: false,
      keyBoardHeight: 0,
      newText: '',
      predictions1: [],
      showSuggestion1: false,
      showOK: false,
      new_address_components: '',
      new_formatted_address: '',
      new_placeId: '',
      new_location: '',
      mySavedAddress: [],
      addrPlaceName: 'Home',
      saveAddrLoader: true,
      onlineDrivers: {},
    };
    this.intervalId = '';
    this.watchID = '';

    const { navigation } = this.props;
    this.didFocusListener = navigation.addListener(
      'focus',
      this.componentDidFocus,
    );
    this.mapsViews = null;
  }

  componentDidFocus = () => {
    this.getNearDriver();
    let text =
      this.props.route.params && this.props.route.params.driverId
        ? this.props.route.params.driverId
        : 'none';

    this.setState({
      prefDriverRide: text,
    });

    this.initPaymentList();
  };

  async getNearDriver() {
    await this.props.getNearBydriver(this.props.navigation);
  }

  initPaymentList = () => {
    this.setState({ PaymentListData: this.props.PaymentListData }, () => {
      var pl = this.props.PaymentListData;
      if (
        pl != null &&
        pl != '' &&
        typeof pl != undefined &&
        pl != 'undefined'
      ) {
        this.getData();
      } else {
        this.props.PaymentMethodListRequest(this.props.navigation);
      }
    });
  };

  focus = () => {
    this.ref.focus();
  };

  uiUpdate() {
    if (this.state.FindDriver == true) {
      setTimeout(() => this.uiUpdateCancel(), 50000);
    }
    setTimeout(() => this.getCurrentLocationInstant(false), 2000);
  }

  uiUpdateCancel() {
    //  setConfiguration('findingDriver', false);
    // this.setState({FindDriver: false, NoDriverFoundView: true});
    if (this.state.FindDriver == true) {
      this.setState({
        FindDriver: false,
        NoDriverFoundView: true,
        promoCode: '',
        points: '',
        shareView: false,
        showcoupon: true,
        isShared: false,
        isSingle: 1,
      });
      setTimeout(() => this.getCurrentLocationInstant(false), 2000);
      Keyboard.dismiss();
    }
  }

  toggleAudio() {
    let mute = this.state.audMute;
    this._engine.muteLocalAudioStream(!mute);
    this.setState({
      audMute: !mute,
    });
  }

  toggleVideo() {
    let mute = this.state.vidMute;

    this.setState({
      vidMute: !mute,
    });
    RtcEngine.muteLocalVideoStream(!this.state.vidMute);
  }

  endCall() {
    this._engine.leaveChannel();
    this.setState({ ChildVideo: false, peerIds: [], joinSucceed: false });
  }

  peerClick(data) {
    let peerIdToSwap = this.state.peerIds.indexOf(data);
    this.setState((prevState) => {
      let currentPeers = [...prevState.peerIds];
      let temp = currentPeers[peerIdToSwap];
      currentPeers[peerIdToSwap] = currentPeers[0];
      currentPeers[0] = temp;
      return { peerIds: currentPeers };
    });
  }

  uploadVideo() {
    launchCamera({ mediaType: 'video', cameraType: 'back' }, (response) => {
      console.log(response);

      if (response.didCancel) {
        // console.log('User cancelled image picker');
      } else if (response.errorCode) {
        // console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        // console.log('User tapped custom button: ', response.customButton);
      } else {
        // this.resize();
        Alert.alert(
          strings.alert,
          strings.sharevideo,
          [
            {
              text: strings.Yes,
              onPress: () => {
                const formdata = new FormData();
                formdata.append('video', {
                  uri:
                    Platform.OS === 'android'
                      ? response.uri
                      : response.uri.replace('file://', ''),
                  type: 'video/mp4',
                  name: 'name.mp4',
                });
                formdata.append('tripId', this.state.tripId);
                this.props.uploadvideoRequest(formdata, this.props.navigation);
              },
            },
            {
              text: strings.No,
              onPress: () => console.log('OK Pressed'),
            },
          ],
          { cancelable: false },
        );
      }
    });
  }

  //================================================================================//
  videoView = () => {
    console.log('tripId', this.state.tripId);
    // console.log('peerIds', this.state.peerIds);

    return (
      <View style={{ flex: 1, backgroundColor: Colors.PrimaryColor }}>
        {this.state.peerIds.length > 1 ? (
          <View style={{ flex: 1 }}>
            <View style={{ height: (dimensions.height * 3) / 4 - 50 }}>
              <RtcLocalView.SurfaceView
                style={{ flex: 1 }}
                channelId={this.state.tripId}
                renderMode={VideoRenderMode.Hidden}
              />
            </View>
            <View style={{ height: dimensions.height / 4 }}>
              <ScrollView
                horizontal={true}
                decelerationRate={0}
                snapToInterval={dimensions.width / 2}
                snapToAlignment={'center'}
                style={{
                  width: dimensions.width,
                  height: dimensions.height / 4,
                }}>
                {this.state.peerIds.slice(1).map((data) => (
                  <TouchableOpacity
                    style={{
                      width: dimensions.width / 2,
                      height: dimensions.height / 4,
                    }}
                    onPress={() => this.peerClick(data)}
                    key={data}>
                    <RtcRemoteView.SurfaceView
                      style={{
                        width: dimensions.width / 2,
                        height: dimensions.height / 4,
                      }}
                      uid={data}
                      key={data}
                      mode={1}
                    // channelId={this.state.channelName}
                    // renderMode={VideoRenderMode.Hidden}
                    // zOrderMediaOverlay={true}
                    />
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          </View>
        ) : this.state.peerIds.length > 0 ? (
          <View style={{ height: dimensions.height - 50 }}>
            <RtcRemoteView.SurfaceView
              style={{ flex: 1 }}
              uid={this.state.peerIds[0]}
              channelId={this.state.tripId}
              zOrderMediaOverlay={true}
            />
          </View>
        ) : null}
        {this.state.vidMute ? ( //view for local video
          <RtcLocalView.SurfaceView
            style={styles.localVideoStyle}
            mode={1}
            showLocalVideo={true}
            renderMode={VideoRenderMode.Hidden}
            zOrderMediaOverlay={true}
          />
        ) : (
          <AgoraView
            style={styles.localVideoStyle}
            zOrderMediaOverlay={true}
            showLocalVideo={true}
            mode={1}
          />
        )}
        <View style={styles.buttonBar}>
          <Icon.Button
            style={styles.iconStyle}
            backgroundColor="#0093E9"
            name={this.state.audMute ? 'mic-off' : 'mic'}
            onPress={() => this.toggleAudio()}
          />
          <Icon.Button
            style={styles.iconStyle}
            backgroundColor="#0093E9"
            name="clear"
            onPress={() => this.endCall()}
          />
        </View>
      </View>
    );
  };

  //================================================================================//

  handleBackButtonClick = () => {
    if (this.props.navigation.isFocused()) {
      if (this.state.NoDriverFoundView) {
        this.goToDashBoard();
        return true;
      } else if (this.state.addPlacesVIew) {
        this.setState({ addPlacesVIew: false });
        return true;
      } else if (this.state.savedPlacesView) {
        this.setState({ savedPlacesView: false });
        return true;
      } else if (this.state.paymentTap) {
        this.cardCancelHide();
        return true;
      } else if (this.state.tripStatus == 'booking') {
        this.BackAction();
        return true;
      } else {
        Alert.alert(
          strings.exit,
          strings.exitApp,
          [
            { text: strings.Cancel, onPress: () => { }, style: 'cancel' },
            { text: strings.exit, onPress: () => BackHandler.exitApp() },
          ],
          { cancelable: false },
        );
        return true;
      }
    } else {
      return false;
    }
  };

  async requestLocationPermission() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: '',
          message: 'Allow to access current location',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        // console.log('You can use the camera');
      } else {
        //  console.log('Camera permission denied');
      }
    } catch (err) {
      console.log(err);
    }
  }

  async checkPermissionForLocatin() {
    const granted = await PermissionsAndroid.check(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
    );

    if (granted) {
      console.log('You can use the ACCESS_FINE_LOCATION');
    } else {
      console.log('ACCESS_FINE_LOCATION permission denied');
    }
  }

  onShare = async () => {
    try {
      const result = await Share.share({
        message: this.state.shareMessage,
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };

  async componentDidMount() {
    if (Platform.OS == 'android') {
      this.cameraAndMicrophonePermissions();
    }
    let currency = this.props.contactsData.App_Settings.Admin_Currency_Code;
    this.setState({ currency: currency });
    if (Platform.OS === 'android') {
      this.requestLocationPermission();
    }
    this.getCurrentLocation();

    //========================================================================//

    var url = getConfiguration('API_ROOT');
    this.socket = SocketIOClient(url);
    this.socket.on('connect', () => {
      setTimeout(() => {
        console.log(this.state.curLatitude, this.state.curLongitude);
        this.socket.emit(
          'customersocket',
          {
            customerId: getConfiguration('user_id'),
            customerLocation: {
              lat: this.state.curLatitude,
              lng: this.state.curLongitude,
            },
            firebase_token: 'none',
            fromConnect: true,
          },
          (data) => {
            console.log('------customersocket-------', data); // data will be 'tobi says woot'
            if (data.customerStatus === Config.TRIP_ON_TRIP) {
              this.setState({
                tripId: data.tripId,
              });

              this.getTripDataRequest(data.tripId);
            } else if (data.customerStatus === Config.TRIP_WAITING_DRIVER) {
              this.getTripDataRequest(data.tripId);
            } else if (data.customerStatus === Config.TRIP_FINDING) {
              var currentTripId = this.props.ProfileData.currentTripId;
              if (
                currentTripId != null &&
                currentTripId != '' &&
                typeof currentTripId != undefined
              ) {
                this.getTripDataRequest(currentTripId);
              }
              // console.log('dadadsadasd');
            }
          },
        );
      }, 2000);
    });

    setConfiguration('Socket', this.socket);

    this.socket.on('trip_customer_socket', (data) => {
      console.log('Data recieved from server', data);
      // if (this.state.tripStatus != data.tripStatus) {
      console.log(this.state.tripStatus + ' ' + data.tripStatus);
      this.getTripDataRequest(data.tripId);

      if (data.tripStatus == 'PickupArrived') {
        Alert.alert('Driver arrived', 'Driver arrived at your location', [
          { text: 'OK', onPress: () => console.log('OK Pressed') },
        ]);
      }
      if (
        data.tripStatus == Config.TRIP_COMPLETED ||
        data.tripStatus == Config.TRIP_CANCELLED
      ) {
        this.setState({
          tripStatus: data.tripStatus,
          sourceLocation: '',
          destinationLocation: '',
          ChildVideo: false,
          panicStatus: false,
        });
      } else {
        // if (data.tripStatus === Config.TRIP_DESTINATION_INROUTE) {
        //   if (!data.prefDriver) {
        //   }
        // }

        var driverLat = data.driverLocation.coordinates[1];
        var driverLng = data.driverLocation.coordinates[0];
        this.setState({
          driverLocation: { latitude: driverLat, longitude: driverLng },
          driverAngle: data.angle,
          driverLatitude: driverLat,
          driverLongitude: driverLng,
          tripId: data.tripId,
        });
      }
      // if (data.customerStatus === Config.TRIP_ON_TRIP) {
      //   //call function with tripId : data.tripId
      //   this.getTripDataRequest(data.tripId);
      // } else if (data.customerStatus === Config.TRIP_WAITING_DRIVER) {
      //   //call function with tripId : data.tripId
      //   this.getTripDataRequest(data.tripId);
      // }
    });

    this.socket.on('trip_customer_socket_paypal', (data) => {
      console.log('trip_customer_socket_paypal');
      console.log(data);
      let details = { tripId: data.tripId, cost: data.cost };
      this.props.PaypalRequest(details, this.props.navigation);
    });

    this.setState({ PaymentListData: this.props.PaymentListData }, () => {
      var pl = this.props.PaymentListData;
      if (
        pl != null &&
        pl != '' &&
        typeof pl != undefined &&
        pl != 'undefined'
      ) {
        this.getData();
      } else {
        this.props.PaymentMethodListRequest(this.props.navigation);
      }
    });
    this.backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
    AppState.addEventListener('change', this.getUserState);

    // this.setState(
    //   {
    //     estimateCost:carsDato
    //   },
    //   () => this.afterEstimateCost(),
    // );
    this.keylistener();
    this.initAgoraVideoCall();
    this.initNotification();
  }

  async initAgoraVideoCall() {
    this._engine = await RtcEngine.create(this.state.appid);
    this._engine.addListener('UserJoined', (uid, elapsed) => {
      console.log('UserID', uid);
      // Get current peer IDs
      const { peerIds } = this.state;
      // If new user
      if (peerIds.indexOf(uid) === -1) {
        this.setState({
          // Add peer ID to state array
          peerIds: [...peerIds, uid],
        });
      }
    });

    this._engine.addListener('UserOffline', (uid, reason) => {
      console.log('UserOffline', uid, reason);
      const { peerIds } = this.state;
      this.setState({
        // Remove peer ID from state array
        peerIds: peerIds.filter((id) => id !== uid),
      });
    });

    // If Local user joins RTC channel
    this._engine.addListener('JoinChannelSuccess', (channel, uid, elapsed) => {
      console.log('JoinChannelSuccess', channel, uid, elapsed);
      this._engine.startPreview();
      this.setState({
        joinSucceed: true,
      });
    });
  }

  initNotification() {
    if (Platform.OS == 'android') {
      PushNotification.createChannel(
        {
          channelId: 'channel-id', // (required)
          channelName: 'My channel', // (required)
          channelDescription: 'A channel to categorise your notifications', // (optional) default: undefined.
          playSound: false, // (optional) default: true
          soundName: 'default', // (optional) See `soundName` parameter of `localNotification` function
          importance: 4, // (optional) default: Importance.HIGH. Int value of the Android notification importance
          vibrate: true, // (optional) default: true. Creates the default vibration patten if true.
        },
        (created) => console.log(`createChannel returned '${created}'`), // (optional) callback returns whether the channel was created, false means it already existed.
      );
    }

    fcmService.registerAppWithFCM();
    fcmService.notificationListeners(
      onRegister,
      onNotification,
      onOpenNotification,
    );
    localNotificationService.configure(onOpenNotification);

    function onRegister(token) {
      console.log('[App] MapSearch: ', token);
    }

    function onNotification(notify) {
      console.log('[App] onNotification: ', notify);
      const options = {
        soundName: 'default',
        playSound: true,
      };
      localNotificationService.showNotification(
        0,
        notify.title,
        notify.body,
        notify,
        options,
      );
    }

    function onOpenNotification(notify) {
      console.log('[App] onOpenNotification: ', notify);
      //  alert('Open Notification: ' + notify.body);
    }
  }

  keylistener() {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow,
    );
    // this.keyboardDidHideListener = Keyboard.addListener(
    //   'keyboardDidHide',
    //   this._keyboardDidHide,
    // );
  }
  _keyboardDidShow = (e) => {
    this.setState({ keyBoardHeight: e.endCoordinates.height });
  };

  async cameraAndMicrophonePermissions() {
    try {
      const granted = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.CAMERA,
        PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
      ]);
      if (
        granted['android.permission.RECORD_AUDIO'] ===
        PermissionsAndroid.RESULTS.GRANTED &&
        granted['android.permission.CAMERA'] ===
        PermissionsAndroid.RESULTS.GRANTED
      ) {
        console.log('You can use the cameras & mic');
      } else {
        console.log('Permission denied');
      }
    } catch (err) {
      console.log(err);
    }
  }

  getTripDataRequest = (tripId) => {
    this.props.getTripRequest(tripId, this.props.navigation);
  };
  openDrawerClick() {
    Keyboard.dismiss();
    this.props.navigation.dispatch(DrawerActions.openDrawer());
  }
  BackAction() {
    this.setState({
      tripStatus: 'fresh',
      selectedRide: 'standard',
      showitem: false,
      promoCode: '',
      points: '',
      showcoupon: true,
      shareView: false,
      isShared: false,
      shareView: false,
      Schedule: false,
      ScheduleSetup: false,
      StopsCount: 0,
      stoplatlong: [],
      StopsArray: [],
      savedPlacesView: false,
    });
    setTimeout(() => this.getCurrentLocationInstant(false), 2000);
  }

  googleAutocomplete = async (Location, curLat, curLong) => {
    const apiUrl =
      'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=' +
      Location +
      '&key=' +
      Config.GOOGLE_MAPS_APIKEY +
      //   '&components=country:in|country:us' +
      '&location=' +
      curLat +
      ',' +
      curLong +
      '&radius=' +
      1000;
    const result = await fetch(apiUrl);
    const json = await result.json();
    return json;
  };

  componentWillUnmount = () => {
    Geolocation.clearWatch(this.watchID);
    Geolocation.stopObserving();
    this.didFocusListener();
    AppState.removeEventListener('change', this.getUserState);
    Keyboard.removeListener('keyboardDidShow', this._keyboardDidShow);
  };

  getUserState = async (nextAppState) => {
    if (
      this.state.appState.match(/inactive|background/) &&
      nextAppState === 'active'
    ) {
      //var currentTripId = this.props.ProfileData.currentTripId;
      var TripId = this.state.tripId;
      //console.log('adasdadadsadsas');
      if (TripId != null && TripId != '' && typeof TripId != undefined) {
        this.getTripDataRequest(TripId);
      }
    }
    this.setState({ appState: nextAppState });
  };

  getCurrentLocation = async () => {
    if (Platform.OS == 'ios') {
      Geolocation.requestAuthorization('whenInUse');
    }
    this.watchID = await Geolocation.watchPosition(
      (position) => {
        let angle = position.coords.heading;
        console.log("goto d", position);
        this.setState({
          curLatitude: position.coords.latitude,
          curLongitude: position.coords.longitude,
          angle: angle,
          error: null,
        });

        setConfiguration('lat', position.coords.latitude);
        setConfiguration('long', position.coords.longitude);
        setTimeout(() => this.getCurrentLocationInstant(false), 2000);
      },
      (error) => {
        this.setState({ error: error.message });
        console.log(error);
      },
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 10000,
        distanceFilter: 1,
      },
    );
  };

  async getData() {
    var pl = this.state.PaymentListData;
    console.log('pl');
    console.log(pl);
    if (pl != null && pl != '') {
      if (pl.length == 0) {
      } else {
        if (pl[0].type === 'Cash') {
          this.setState({
            cardList: pl,
            selectedCardNum: 'cash',
            selectedCardImage: pl[0].logo,
            selectedCardID: pl[0]._id,
            PaymentVia: 'cash',
          });
        } else if (pl[0].type === 'Paypal') {
          this.setState({
            cardList: pl,
            selectedCardNum: 'Paypal',
            selectedCardID: pl[0]._id,
            selectedCardImage: pl[0].logo,
            PaymentVia: 'Paypal',
          });
        } else if (pl[0].type === 'Wallet') {
          this.setState({
            cardList: pl,
            selectedCardNum: 'wallet',
            selectedCardID: pl[0]._id,
            selectedCardImage: pl[0].logo,
            PaymentVia: 'wallet',
          });
        }
      }
    }
  }

  getEstimateCost = (oneWayitem, stopsArray, dropOnewayitem, surgeData) => {
    console.log("first time: ", oneWayitem, stopsArray, dropOnewayitem)
    this.props.estimateRequest(
      timezone,
      oneWayitem,
      stopsArray,
      dropOnewayitem,
      surgeData,
      this.props.navigation,
    );
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.changeAddressData != this.props.changeAddressData) {
      this.GetUpdatedTripData(this.props.changeAddressData.data);
      // setTimeout(() => {
      this.setState({
        // getTripData: this.props.changeAddressData,
        showOK: false,
        newText: '',
        IsChangeAddress: false,
      });
      // }, 4000);
    }
    if (prevProps.paypalData != this.props.paypalData) {
      this.setState({ PaypalUrl: this.props.paypalData, showModal: true });
    }

    if (prevProps.nearByDriverData != this.props.nearByDriverData) {

      this.manageOnlineDriver(this.props.nearByDriverData);
    }

    if (prevProps.addTripData != this.props.addTripData) {
      this.setState({ addTripData: this.props.addTripData }, () => {
        if (
          this.state.addTripData != '' &&
          this.state.addTripData != 'null' &&
          this.state.addTripData != null
        ) {
          var data = this.state.addTripData;
          //console.log(data);
          this.afterAddtripAp(data);
        }
      });
    }
    if (prevProps.PaymentListData != this.props.PaymentListData) {
      // console.log('PaymentListData');
      // console.log(this.props.PaymentListData);
      this.setState({ PaymentListData: this.props.PaymentListData }, () => {
        //  this.getData();
      });
    }

    if (prevProps.GetAddressList != this.props.GetAddressList) {
      this.setState({
        mySavedAddress: this.props.GetAddressList,
        saveAddrLoader: false
      });
    }

    if (prevProps.EstimateCostData != this.props.EstimateCostData) {
      this.setState({ estimateCost: this.props.EstimateCostData }, () =>
        this.afterEstimateCost(),
      );
    }
    if (prevProps.getTripData != this.props.getTripData) {
      console.log('this.props.getTripData' + '   ' + hit);
      hit++;
      // console.log('this.props.getTripData');
      // console.log(JSON.stringify(this.props.getTripData));
      this.setState({ getTripData: this.props.getTripData }, () => {
        var getTripData = this.state.getTripData;
        // console.log(getTripData);
        if (getTripData != null && getTripData != '') {
          this.GetUpdatedTripData(this.state.getTripData);
        }
      });
    }

    if (prevProps.ratingData != this.props.ratingData) {
      this.setState({ ratingData: this.props.ratingData }, () => {
        var ratingData = this.state.ratingData;
        if (this.state.ratingData.status === 'success') {
          this.afterRating();
        }
      });
    }
    if (prevProps.panicData != this.props.panicData) {
      this.setState({ panicData: this.props.panicData }, () => {
        if (this.state.panicData.status === 'success') {
        }
      });
    }
    if (prevProps.preferDriverData != this.props.preferDriverData) {
      this.setState({ preferDriverData: this.props.preferDriverData }, () => {
        if (this.state.preferDriverData.status === 'success') {
          this.afterAddPreferDriver();
        }
      });
    }
    if (prevProps.cancelTripData != this.props.cancelTripData) {
      this.setState({ cancelTripData: this.props.cancelTripData }, () => {
        if (this.state.cancelTripData.status === 'success') {
          this.afterCancelTrip();
        }
      });
    }
    if (prevProps.couponData != this.props.couponData) {
      this.setState({ couponData: this.props.couponData }, () => {

        if (this.props.couponData.status === 'success') {
          this.afterValidateCoupon();
        } else if (this.props.couponData.status === 'failure') {
          this.invalidCoupon(this.props.couponData);
        }
      });
    }
    if (prevProps.addDisputeData != this.props.addDisputeData) {
      this.afterRating();
    }
  }

  manageOnlineDriver = data => {
    var temp = [];
    for (var i = 0; i < data.length; i++) {
      var od = data[i];
      temp.push({
        coordinates: {
          latitude: od.driverLocation.coordinates[1],
          longitude: od.driverLocation.coordinates[0]
        },
        _id: od._id
      });
    }
    console.log("online drrrr", temp)
    this.setState({
      onlineDrivers: temp
    });

  }

  GetUpdatedTripData = (data) => {
    if (data.tripStatus == Config.TRIP_COMPLETED) {
      if (data.review.driverRating === 0 && !data.isDispute) {
        this.setState({
          tripData: data,
          tripStatus: data.tripStatus,
          ratingValue: 0,
          tripId: data._id,
          estimatedCost: data.cost,
          sourceLocation: '',
          destinationLocation: '',
          ChildVideo: false,
          joinSucceed: false,
          panicStatus: false,
          peerIds: [],
          ScheduleSetup: false,
          isShared: false,
          shareView: false,
          descriptionRideString: '',
          prefDriverRide: 'none',
        });
      }
    }

    if (
      data.tripStatus == Config.TRIP_DESTINATION_INROUTE.toString() ||
      data.tripStatus == Config.TRIP_PICKUP_INROUTE ||
      data.tripStatus == Config.TRIP_ARRIVED
    ) {
      console.log('data');
      console.log(data);
      var tripId = data._id;
      var sourceLat = data.startLocation.coordinates[1];
      var sourceLng = data.startLocation.coordinates[0];
      var destinationLat = data.endLocation.coordinates[1];
      var destinationLng = data.endLocation.coordinates[0];
      var driverImage = data.driverImage;
      var driverName = data.driverName;
      var driverAvgRtaing = data.driverAvgRtaing;
      var tripOTP = data.tripOTP;
      var driveId = data.driverId;
      var prefferedDriver = data.prefDriver;
      var isPreff = false;
      var est = data.estimatedTime;
      var ETA = est.toString().split('.')[0];
      if (
        prefferedDriver == 'no' ||
        typeof prefferedDriver == undefined ||
        prefferedDriver == null ||
        prefferedDriver == false
      ) {
      } else {
        isPreff = true;
      }
      this.setState({
        sourceLocationCord: { latitude: sourceLat, longitude: sourceLng },
        destinationLocationCord: {
          latitude: destinationLat,
          longitude: destinationLng,
        },
        endLocationAddr: data.endLocationAddr,
        driverImage: driverImage,
        driverName: driverName,
        driverAvgRtaing: driverAvgRtaing,
        carNumber: '',
        tripOTP: tripOTP,
        driverMobileCode: data.countryCode,
        tripId: tripId,
        estimatedCost: data.estimatedCost,
        driverMobileNumber: data.driverNumber,
        tripStatus: data.tripStatus,
        FindDriver: false,
        NoDriverFoundView: false,
        prefDriverRide: 'none',
        estimatedTime: ETA,
        shareMessage:
          'I am riding with ' +
          driverName +
          ' with car number : ' +
          data.driverRefId.selectedCar.plateNumber,
        driverId: driveId,
        preferredDone: isPreff,
        showitem: false,
        plateNumber: data.driverRefId.selectedCar.plateNumber,
        carName: data.driverRefId.selectedCar.carName,

        driverLocation: {
          latitude: data.driverLocation.coordinates[1],
          longitude: data.driverLocation.coordinates[0],
        },

        driverLatitude: data.driverLocation.coordinates[1],
        driverLongitude: data.driverLocation.coordinates[0],
        AllData: data,
      });
      if (data.tripStatus == Config.TRIP_DESTINATION_INROUTE) {
        this.setState({
          rideTyp: data.rideType,
        });
      }
    }
    if (data.tripStatus == Config.TRIP_CANCELLED) {
      //  var aa = this.state.tripStatus;
      if (this.state.tripStatus != 'fresh') {
        setTimeout(() => {
          Alert.alert(
            strings.CancelTrip,
            strings.canceledByDriver,
            [{ text: strings.Ok, onPress: () => { } }],
            { cancelable: false },
          );
        }, 600);
      }
      this.setState(
        {
          ChildVideo: false,
          joinSucceed: false,
          peerIds: [],
          tripData: '',
          tripStatus: 'fresh',
          selectedRide: 'standard',
          prefDriverRide: 'none',
          promoCode: '',
          points: '',
          showcoupon: true,
          ratingValue: 0,
          NoDriverFoundView: false,
          FindDriver: false,
          sourceLocation: '',
          ScheduleSetup: false,
          isShared: false,
          shareView: false,
          descriptionRideString: '',
        },
        () => {
          setTimeout(() => this.getCurrentLocation(), 2000);
        },
      );
    }
  };

  afterEstimateCost() {
    var date = new Date().getDate(); //Current Date
    var month = new Date().getMonth() + 1; //Current Month
    var year = new Date().getFullYear(); //Current Year
    var dateNew = date + '-' + month + '-' + year;

    var ar = this.state.estimateCost;

    this.setState(
      {
        estimationCostArr: ar,
        bikeSelected: ar[0]._id,
        estimatedCost: ar[0].estimatedCost,

        minDateSel: dateNew,
        curLat: this.state.curLatitude,
        curLong: this.state.curLongitude,
        curAddress: this.state.sourceLocation,
        destLat: this.state.destlatt,
        destLong: this.state.destlongi,
        destAddress: this.state.destinationLocation,
        distance: this.state.distance,
        estimatedTime: this.state.estimatedTime,
        driverId: this.state.driverIdPref,
        //   prefDriverRide: this.state.prefDriverRide,
        showitem: true,
        tripStatus: 'booking',
        AddTripArray: ar,
        showCurLat: ar[0].startLocation.lat,
        showCurLng: ar[0].startLocation.lng,
        showdestLat: ar[0].endLocation.lat,
        ShowdestLng: ar[0].endLocation.lng,

        sourceLocation: '',
        FirstStopLocation: '',
        SecondStopLocation: '',
        destinationLocation: '',
        StopsCount: 0,
        FirstLocationPick: {
          address_components: '',
          formatted_address: '',
          place_id: '',
          location: {
            lat: '',
            long: '',
          },
        },
        SecondLocationPick: {
          address_components: '',
          formatted_address: '',
          place_id: '',
          location: {
            lat: '',
            long: '',
          },
        },
        showSuggestion: false,
        panicStatus: false,
      },
      () => this.fitMarkers('bottom'),
    );
  }

  fitMarkers = (type) => {
    setTimeout(() => {
      this.mapsViews.fitToSuppliedMarkers(['m1', 'm2'], {
        edgePadding: {
          top: this.paddingReturn(false),
          right: this.paddingReturn(false),
          bottom: this.paddingReturn(false),
          left: this.paddingReturn(false),
        },
      });
    }, 100);
  };

  paddingReturn(type) {
    console.log(heightCal);
    if (type) {
      return Platform.OS == 'ios'
        ? heightCal / 1.7
        : PixelRatio.getPixelSizeForLayoutSize(heightCal / 1.7);
    } else {
      return Platform.OS == 'ios'
        ? 100
        : PixelRatio.getPixelSizeForLayoutSize(100);
    }
  }

  makeDriverCall(driverMobileNumber) {
    console.log(driverMobileNumber);
    let phoneNumber = driverMobileNumber;
    if (Platform.OS !== 'android') {
      phoneNumber = `telprompt:${driverMobileNumber}`;
    } else {
      phoneNumber = `tel:${driverMobileNumber}`;
    }
    Linking.canOpenURL(phoneNumber)
      .then((supported) => {
        if (!supported) {
          Alert.alert(strings.phoneNotAvail);
        } else {
          return Linking.openURL(phoneNumber);
        }
      })
      .catch((err) => console.log(err));
    // Linking.openURL(`tel:${driverMobileNumber}`)
  }

  // messageDriver() {}

  messageDriver = () => {
    let numberWithCode =
      this.state.driverMobileCode + this.state.driverMobileNumber;
    let driverMessage = 'Hello ' + this.state.driverName + ', ';
    // console.log(numberWithCode);
    SendSMS.send(
      {
        body: driverMessage,
        recipients: [numberWithCode],
        successTypes: ['sent', 'queued'],
      },

      (completed, cancelled, error) => {
        if (completed) {
          Alert.alert(strings.SMSOK);
        } else if (cancelled) {
          //console.log('SMS Sent Cancelled.');
        } else if (error) {
          // console.log('Some error occured.');
        }
      },
    );
  };

  cancelRide() {
    let data = {
      tripId: this.state.tripId,
    };
    this.props.cancelTripRequest(data, this.props.navigation);
  }

  afterCancelTrip() {
    this.setState({
      tripData: '',
      tripStatus: 'fresh',
      promoCode: '',
      points: '',
      showcoupon: true,
      selectedRide: 'standard',
      descriptionRideString: '',
      StopsArray: [],
      stoplatlong: [],
      CancelView: false,
    });
    this.getCurrentLocationInstant(false);
    this.initPaymentList();
  }

  shareDetail() {
    // console.log('share detail');
    this.onShare();
  }

  submitReview() {
    this.submitRating();
  }

  rating(value) {
    this.setState({ ratingValue: value });
  }

  submitRating() {
    var rating = this.state.ratingValue;
    if (!isEmpty(rating) || rating == 0) {
      this.showAlert(strings.ratingRequired, 300);
      return false;
    }

    let data = {
      tripId: this.state.tripId,
      driverRating: rating,
      driverComment: this.state.feedbackTxt,
      tipAmount:
        this.state.CustomTip != ''
          ? this.state.CustomTip
          : this.state.tipAmount,
    };
    if (
      data.tripId != null &&
      data.tripId != undefined &&
      data.tripId != 'undefined' &&
      data.tripId != ''
    ) {
      console.log(data);
      this.props.ratingRequest(data, this.props.navigation);
    } else {
      // this.afterRating();
      // this.props.cancelRatingRequest();
    }
  }

  async afterRating() {
    await this._engine?.leaveChannel();

    //RtcEngine.destroy();
    // RtcEngine.leaveChannel();

    this.setState(
      {
        ChildVideo: false,
        joinSucceed: false,
        panicStatus: false,
        peerIds: [],
        tripData: '',
        tripStatus: 'fresh',
        promoCode: '',
        points: '',
        showcoupon: true,
        selectedRide: 'standard',
        ratingValue: 0,
        tipAmount: '0',
        feedbackTxt: '',
        NoDriverFoundView: false,
        FindDriver: false,
        sourceLocation: '',
        descriptionRideString: '',
        StopsArray: [],
        stoplatlong: [],
      },
      () => {
        // setTimeout(() => this.getCurrentLocation(), 2000);
        this.getCurrentLocationInstant(false);
        this.initPaymentList();
      },
    );
  }

  goToDashBoard() {
    this.setState({
      NoDriverFoundView: false,
      tripStatus: 'fresh',
      FindDriver: false,
      showitem: false,
      promoCode: '',
      points: '',
      showcoupon: true,
      location: '',
      destinationLocation: '',
      destinationPlaceID: '',
      descriptionRideString: '',
      prefDriverRide: 'none',
      stoplatlong: [],
      StopsArray: [],
    });
    setTimeout(() => this.getCurrentLocationInstant(), 2000);
    this.initPaymentList();
  }

  panicButtonAction() {
    // if (this.state.panicStatus == false) {
    this.submitPanic();
    // }
  }
  refreshUser = () => {
    var TripId = this.state.tripId;
    if (TripId != null && TripId != '' && typeof TripId != undefined) {
      this.getTripDataRequest(TripId);
    }
  };

  submitPanic() {
    let data = {
      tripId: this.state.tripId,
    };
    this.props.panicRequest(data, this.props.navigation);
  }

  noAction() {
    this.setState({ preferredClick: false });
  }

  yesAction = () => {
    let data = {
      driverId: this.state.driverId,
    };
    this.props.preferDriverRequest(data, this.props.navigation);
  };

  afterAddPreferDriver() {
    this.setState({
      preferredClick: false,
      preferredDone: true,
    });
  }

  preferredAction() {
    this.setState({ preferredClick: true });
  }

  getCurrentLocationInstant = (status) => {
    let sourceLoc = this.state.sourceLocation;
    let destLoc = this.state.destinationLocation;
    Geocoder.from(this.state.curLatitude, this.state.curLongitude)
      .then((json) => {
        if (
          sourceLoc == '' ||
          sourceLoc == null ||
          sourceLoc == 'null' ||
          typeof sourceLoc == undefined ||
          !status
        ) {
          this.setState({
            SourcePick: {
              address_components: json.results[0].address_components,
              formatted_address: json.results[0].formatted_address,
              place_id: json.results[0].place_id,
              location: {
                lat: json.results[0].geometry.location.lat,
                lng: json.results[0].geometry.location.lng,
              },
            },
            sourceLocation: json.results[0].formatted_address,
            selSourcePlaceId: json.results[0].place_id,
          });
        } else if (
          destLoc == '' ||
          destLoc == null ||
          destLoc == 'null' ||
          typeof destLoc == undefined
        ) {
          if (status) {
            var location = json.results[0].geometry.location;
            this.setState(
              {
                dropOneway: {
                  address_components: json.results[0].address_components,
                  formatted_address: json.results[0].formatted_address,
                  place_id: json.results[0].place_id,
                  location: {
                    lat: json.results[0].geometry.location.lat,
                    lng: json.results[0].geometry.location.lng,
                  },
                },
                destinationLocation: json.results[0].formatted_address,
                destinationPlaceID: json.results[0].place_id,
                destlatt: location.lat,
                destlongi: location.lng,
              },
              () => {
                if (
                  this.state.selSourcePlaceId.length > 0 &&
                  json.results[0].place_id.length > 0
                ) {
                  this.updateDropState();
                }
              },
            );
          }
        }
      })
      .catch((error) => error);
  };

  ApplyCoupon = () => {
    if (this.state.promoCode == '') {
      this.showAlert(strings.EnterPromocode, 300);
    } else {
      this.validateCoupon();
    }
  };

  ApplyRedeem = () => {
    if (this.state.points.trim() == '') {
      this.showAlert(strings.EnterPoints, 300);
    } else {
      this.validateCoupon();
    }
  };

  ApplyConfirm = () => {
    if (this.state.selectedCardNum == 'wallet') {
      var walletBalance = this.props.ProfileData.userWallet.walletAmount;
      if (
        walletBalance == null ||
        walletBalance == '' ||
        typeof walletBalance == undefined
      ) {
        walletBalance = 0;
      }
      var addTripBalance = this.state.AddTripArray[0].estimatedCost;
      if (addTripBalance > walletBalance) {
        setTimeout(() => {
          Alert.alert(
            strings.Alert,
            strings.insufficientBalance,
            [{ text: strings.Ok, onPress: () => { } }],
            { cancelable: false },
          );
        }, 600);
        return false;
      }
    }
    if (this.state.ScheduleSetup == true) {
      var sdate = this.state.date;
      var stime = this.state.Time;
      this.AddtripAp(sdate, stime, 'schedule');
    } else {
      this.AddtripAp('03-04-2020', '04:45', 'instant');
    }
  };

  applyShare = () => {
    if (this.state.selectedCardNum == 'wallet') {
      var walletBalance = this.props.ProfileData.userWallet.walletAmount;
      if (
        walletBalance == null ||
        walletBalance == '' ||
        typeof walletBalance == undefined
      ) {
        walletBalance = 0;
      }
      var addTripBalance = this.state.AddTripArray[0].estimatedCost;
      if (addTripBalance > walletBalance) {
        setTimeout(() => {
          Alert.alert(
            strings.Alert,
            strings.insufficientBalance,
            [{ text: strings.Ok, onPress: () => { } }],
            { cancelable: false },
          );
        }, 600);
        return false;
      }
    }
    this.AddtripAp('03-04-2020', '04:45', 'pool');
  };

  // alert('Boraque Rides not avaible in your country yet');
  //  setTimeout(() => {

  AddtripAp(dat, tim, trptyp) {
    var addTrip = this.state.AddTripArray[0];
    const {
      selectedRide,
      prefDriverRide,
      bikeSelected,
      PaymentVia,
      selectedCardID,
      SourcePick,
      dropOneway,
      TimeZoneSelected,
      StopsArray,
    } = this.state;
    let promoCode = '';
    if (!this.state.showcoupon) {
      promoCode = this.state.promoCode;
    }

    console.log(StopsArray);

    let source = {
      startLocationAddr: SourcePick.startLocationAddr,
      startLocation: SourcePick.startLocation,
    };

    console.log('dropOneway');

    console.log(dropOneway);

    let desti = {
      endLocationAddr: dropOneway.endLocationAddr,
      endLocation: dropOneway.endLocation,
    };

    let noOfSeats = 0;
    if (this.state.isShared && trptyp === 'pool') {
      noOfSeats = this.state.isSingle;
    }

    let details = {
      rideType: selectedRide, //standard or child
      trip_type: trptyp,
      prefDriver: prefDriverRide,
      country: addTrip.country,
      countryCode: addTrip.countryCode,
      // state: addTrip.state,
      // stateCode: addTrip.stateCode,
      pricingType: addTrip.pricingType,
      isSurgeTime: addTrip.isSurgeTime,
      surgeMultiplier: addTrip.surgeMultiplier,
      unit: addTrip.unit,
      distance: addTrip.distance,
      estimatedTime: addTrip.estimatedTime,
      estimatedCost: this.state.estimatedCost,
      carTypeRequired: bikeSelected,
      paymentMethod: PaymentVia,
      paymentSourceRefNo: selectedCardID,
      source: source,
      destination: desti,
      scheduleTimezone: TimeZoneSelected,
      scheduleDate: trptyp == 'instant' || trptyp == 'pool' ? '' : dat,
      scheduleTime: trptyp == 'instant' || trptyp == 'pool' ? '' : tim,
      promoCode: promoCode,
      noOfSeats: noOfSeats,
      description: this.state.descriptionRideString,
      stopsArray: StopsArray,
    };

    console.log('detailsOnes ========== ');
    console.log(details);
    this.props.addTripRequest(details, this.props.navigation);
  }

  scheduleDone() {
    this.setState({
      showitem: false,
      tripStatus: 'fresh',
      promoCode: '',
      points: '',
      showcoupon: true,
    });
    this.getCurrentLocationInstant(false);
  }

  startRequestTimer = () => {
    var count = '0';
    this.intervalId = BackgroundTimer.runBackgroundTimer(() => {
      count = (Number(count) + 1).toString();
      if (count === '30') {
        this.stopRequestTimer();
      }
    }, 1000);
  };

  stopRequestTimer = async () => {
    await BackgroundTimer.stopBackgroundTimer(this.intervalId);
    this.uiUpdateCancel();
  };

  afterAddtripAp = (data) => {
    //  console.log(data);
    if (data.trip_type === 'instant' || data.trip_type === 'pool') {
      if (data.isDriverFound === 'yes') {
        this.startRequestTimer();
        this.setState({
          showitem: false,
          shareView: false,
          FindDriver: true,
          tripStatus: 'fresh',
          promoCode: '',
          points: '',
          showcoupon: true,
          isShared: false,
          isSingle: 1,
        });
        //setTimeout(() => this.uiUpdateCancel(), 20000);
      } else {
        // this.uiUpdateCancel();
        this.setState({
          FindDriver: false,
          NoDriverFoundView: true,
          promoCode: '',
          points: '',
          showcoupon: true,
          shareView: false,
          isShared: false,
          isSingle: 1,
        });
      }
    } else {
      if (this.state.ScheduleSetup == true) {
        setTimeout(() => {
          Alert.alert(
            strings.Success,
            strings.yourRideSuccess,
            [{ text: strings.Ok, onPress: () => this.scheduleDone() }],
            { cancelable: false },
          );
        }, 600);
        this.ApplyScheduleDone();
      }
    }
  };

  ApplySchedule = () => {
    // this.setState({
    //   showitem: true,
    //   Schedule: true,
    //   showitem: false,
    //   ScheduleSetup: false,
    // });
    alert("To schedule a ride please call 01684 891414. The option to schedule a ride through the app will be available in future, Thank you");
  };

  ApplyScheduleDone = () => {
    //  console.log('asda');
    this.setState({
      Schedule: false,
      ScheduleSetup: false,
      date: '',
      Time: '',
      tripStatus: 'fresh',
      showitem: false,
    });
  };

  CallDriver = () => {
    this.setState({
      driverdetails: true,
    });
  };

  bikeSel(item, isShared) {
    this.setState({
      bikeSelected: item._id,
      estimatedCost: item.estimatedCost,
      isShared: isShared,
    });
  }

  tapCard() {
    this.setState({ paymentTap: !this.state.paymentTap });
  }

  payAction = (item) => {
    console.log('---item---', item);
    let types = item.type.toLowerCase();
    this.setState({
      selectedCardNum:
        types == 'cash' || types == 'wallet' || types == 'paypal'
          ? types
          : item.lastd,
      selectedCardID: item._id,
      selectedCardImage: item.logo,
      paymentTap: false,
      PaymentVia:
        types == 'cash' || types == 'wallet' || types == 'paypal'
          ? types
          : 'stripe',
    });
    // selectedCardNum: strings.Selectcard,
    // selectedCardID: '',
    // selectedCardImage: '',
    // PaymentVia: '',
  };

  cardCancelHide() {
    this.setState({ paymentTap: false });
  }

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  validateCoupon() {
    let data = {
      promocode: this.state.promoCode,
    };
    if (this.state.showcoupon) {
      this.props.couponRequest(data, this.props.navigation);
    }
  }

  invalidCoupon = (data) => {
    this.setState({ promoCode: '' });
    this.showAlert(data.message, 600);
  };

  afterValidateCoupon() {
    this.setState({
      showcoupon: false,
    });
  }

  closeRide = () => {
    this.setState({
      showitem: true,
      Schedule: false,
      ScheduleSetup: false,
      date: '',
      Time: '',
    });
  };

  closeShare = () => {
    this.setState({
      showitem: true,
      shareView: false,
      ScheduleSetup: false,
    });
  };

  setPickUp() {
    var today = new Date();

    if (this.state.date == '') {
      Alert.alert(strings.SelectDate);
    } else if (this.state.Time == '') {
      Alert.alert('Select Time');
    } else {
      if (today.getTime() > this.state.Datos.getTime()) {
        console.log('chota');
      } else {
        console.log('wda');
      }
      this.setState({
        showitem: true,
        Schedule: false,
        ScheduleSetup: true,
      });

      const surgeData = {
        tripType: 'schedule',
        date: this.state.date,
        time: this.state.Time
      }
      const stopsArray = [];
      console.log("confirm sc:", this.state.SourcePick, this.state.dropOneway);
      this.getEstimateCost(this.state.SourcePick, stopsArray, this.state.dropOneway, surgeData)
    }
  }

  standardRideAction() {
    this.setState({ selectedRide: 'standard', isShared: false });
  }

  childRideAction() {
    var item = this.state.estimationCostArr[0];
    this.setState({
      selectedRide: 'child',
      bikeSelected: item._id,
      isShared: false,
    });
  }

  rideDescriptionAction() {
    if (this.state.RideDes == true) {
      this.setState({ RideDes: false });
    } else this.setState({ RideDes: true });
  }
  submitDescription() {
    if (this.state.descriptionRideString == '') {
      Alert.alert(strings.Alert, strings.EnterDescription, [
        { text: strings.Ok },
      ]);
    } else {
      this.setState({ RideDes: false });
    }
  }

  typeNullCheckAlert(types, text) {
    let type = this.typeReturn(types);
    if (
      this.state[type] == '' ||
      this.state[type] == null ||
      this.state[type] == 'null' ||
      typeof this.state[type] == undefined
    ) {
      alert(text);
      return false;
    } else {
      return true;
    }
  }

  updateDropState = () => {
    let turn = this.typeNullCheckAlert('source', strings.Enterpickupaddress);
    if (!turn) return turn;

    let turn1 = this.typeNullCheckAlert('destination', strings.EnterDesaddress);
    if (!turn1) return turn1;
    let oneWayitem = {
      startLocationAddr: this.state.SourcePick.formatted_address,
      startLocation: this.state.SourcePick.location,
      addressComponents: this.state.SourcePick.address_components,
    };
    let stopsArray = [];
    var stopsLatLong = [];

    if (this.state.StopsCount == 1) {
      let turn2 = this.typeNullCheckAlert('stop1', strings.EnterStop1address);
      if (!turn2) return turn2;

      stopsArray = [
        {
          endLocationAddr: this.state.FirstLocationPick.formatted_address,
          location: this.state.FirstLocationPick.location,
          isDrop: false,
          stop: 0,
        },
      ];

      stopsLatLong = [
        {
          latitude: this.state.FirstLocationPick.location.lat,
          longitude: this.state.FirstLocationPick.location.lng,
          title: this.state.FirstLocationPick.formatted_address,
        },
      ];
      this.setState({
        stoplatlong: stopsLatLong,
        StopsArray: stopsArray,
      });
    } else if (this.state.StopsCount == 2) {
      let turn3 = this.typeNullCheckAlert('stop1', strings.EnterStop1address);
      if (!turn3) return turn3;

      let turn4 = this.typeNullCheckAlert('stop1', strings.EnterStop2address);
      if (!turn4) return turn4;

      stopsArray = [
        {
          endLocationAddr: this.state.FirstLocationPick.formatted_address,
          location: this.state.FirstLocationPick.location,
          isDrop: false,
          stop: 0,
        },
        {
          endLocationAddr: this.state.SecondLocationPick.formatted_address,
          location: this.state.SecondLocationPick.location,
          isDrop: false,
          stop: 1,
        },
      ];

      stopsLatLong = [
        {
          latitude: this.state.FirstLocationPick.location.lat,
          longitude: this.state.FirstLocationPick.location.lng,
          title: this.state.FirstLocationPick.formatted_address,
        },
        {
          latitude: this.state.SecondLocationPick.location.lat,
          longitude: this.state.SecondLocationPick.location.lng,
          title: this.state.SecondLocationPick.formatted_address,
        },
      ];
      this.setState({
        stoplatlong: stopsLatLong,
        StopsArray: stopsArray,
      });
    }

    let dropOnewayitem = {
      endLocationAddr: this.state.dropOneway.formatted_address,
      endLocation: this.state.dropOneway.location,
      addressComponents: this.state.dropOneway.address_components,
    };

    if (
      oneWayitem.addressComponents != null &&
      oneWayitem.addressComponents != '' &&
      typeof oneWayitem.addressComponents != undefined &&
      dropOnewayitem.endLocationAddr != '' &&
      dropOnewayitem.endLocationAddr != null &&
      typeof dropOnewayitem.endLocationAddr != undefined
    ) {
      if (
        oneWayitem.startLocation.lat == dropOnewayitem.endLocation.lat &&
        oneWayitem.startLocation.lng == dropOnewayitem.endLocation.lng
      ) {
        alert(strings.pickDest);
        return false;
      }
      console.log(oneWayitem, dropOnewayitem, stopsArray);
      const surgeData = {
        tripType: 'instant',
        date: '',
        time: ''
      }
      this.setState({ SourcePick: oneWayitem, dropOneway: dropOnewayitem }, () =>
        this.getEstimateCost(oneWayitem, stopsArray, dropOnewayitem, surgeData),
      );
    }
  };

  setAddress(item) {
    if (this.state.sourceLocation == '') {
      this.setSourceLocation(
        item.address.place_id,
        item.address.formatted_address,
      );
      this.setState({ savedPlacesView: false });
      return;
    } else if (this.state.destinationLocation == '') {

      this.setDestinationLocation(item.address.place_id, item.address.formatted_address);
      this.setState({ savedPlacesView: false });
      return;
    }
  }

  openSavedPlacesView = () => {

    this.setState({ savedPlacesView: true });

    this.props.mySaveAddrRequest(this.props.navigation);
  };

  openAddPlacesView = () => {
    this.setState({ addPlacesVIew: true });
  };

  editSavePlacesView = (item) => {
    this.setState({
      addPlacesVIew: true,
      addrPlaceName: item.name,
      addPlaceAddress: item.address.formatted_address,
      addAddress: item.address,
      addressId: item._id,
      addressType: 'update'
    });
  }

  closeAddPlacesView() {
    this.setState({
      addPlacesVIew: false,
      addrPlaceName: 'Home',
      addPlaceAddress: ''
    });
  }

  showSavedPlacesView() {
    return (
      this.state.saveAddrLoader ? <ActivityIndicator size="large" color={Colors.PrimaryColor} style={styles.loaderStyle} /> :
        <View
          style={{
            flex: 1,
            height: '100%',
            //width: '100%',
            top: '5%',
            position: 'absolute'
          }}>

          <View style={{ backgroundColor: '#F9F9F9', top: '7%', }}>
            <Text style={{ paddingVertical: 10, marginHorizontal: 15 }}>ADDRESSES</Text>
          </View>
          {/* <View style={{ height: 1, backgroundColor: 'grey', marginTop: 10 }} /> */}
          {!!this.state.mySavedAddress && this.state.mySavedAddress.length > 0 ?
            <FlatList
              style={{ marginTop: 60, marginBottom: wp(25) }}
              data={this.state.mySavedAddress}
              scrollEnabled={true}
              renderItem={({ item }) => (
                <View
                  style={{
                    // height: 'auto',
                    padding: 10,
                    flexDirection: 'row'
                  }}>
                  <TouchableOpacity
                    onPress={() => this.setAddress(item)}
                    style={{ width: '80%' }}
                  >
                    <View style={{ flexDirection: 'row' }}>
                      <Image
                        resizeMode="contain"
                        style={{ width: 24, height: 24, top: 5 }}
                        source={Images.WhiteAddress}
                      />
                      <View>
                        <Text style={{
                          fontFamily: Fonts.Semibold,
                          fontSize: RFPercentage(2),
                          marginHorizontal: 10,
                        }}>{item.name}</Text>
                        <Text style={{
                          fontFamily: Fonts.Thin,
                          fontSize: RFPercentage(1.5),
                          marginHorizontal: 10,
                          width: '100%',
                        }}>
                          {!!item.address && item.address.formatted_address.length > 45 ? item.address.formatted_address.substring(0, 45) + '...' : item.address.formatted_address}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>

                  <View style={{ flexDirection: 'row' }}>
                    <TouchableOpacity
                      style={{ justifyContent: 'center' }}
                      onPress={() => this.editSavePlacesView(item)}
                    >
                      <Image
                        resizeMode="contain"
                        style={[styles.addrDeleteIcon, { marginTop: 2 }]}
                        source={Images.editAddr}
                      />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={{ justifyContent: 'center' }}
                      onPress={() => this.deleteSavedAddress(item._id)}
                    >
                      <Image
                        resizeMode="contain"
                        style={[styles.addrDeleteIcon, { marginTop: 2 }]}
                        source={Images.deleteAddr}
                      />
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            />
            : <Text
              style={{
                width: wp('100%'),
                marginTop: wp(20),
                textAlign: 'center',
                fontFamily: Fonts.Semibold,
                fontSize: 20
              }}>
              {' '}
              {strings.NoAddrvailable}{' '}
            </Text>}
          <TouchableOpacity
            style={{
              alignSelf: 'flex-end',
              position: 'absolute',
              bottom: 40,
              right: 35
            }}
            onPress={() => this.openAddPlacesView()}>
            <Image
              resizeMode='contain'
              style={{ width: 60, height: 60 }}
              source={Images.addIcon}
            />
          </TouchableOpacity>
        </View>
    );
  }

  setAddressLocation(placeId, description) {
    this.setState({
      addPlaceAddress: description,
      showAddressSuggestion: false,
      addPlaceAddressPlaceId: placeId,
    });
    fetch(
      'https://maps.googleapis.com/maps/api/geocode/json?address=' +
      description +
      '&key=' +
      Config.GOOGLE_MAPS_APIKEY,
    )
      .then(response => response.json())
      .then(responseJson => {
        var location = responseJson.results[0].geometry.location;
        this.setState({
          addPlaceAddress: responseJson.results[0].formatted_address,
        });
        this.setState({
          addAddress: {
            address_components: responseJson.results[0].address_components,
            formatted_address: responseJson.results[0].formatted_address,
            place_id: responseJson.results[0].place_id,
            startLocation: {
              lat: responseJson.results[0].geometry.location.lat,
              lng: responseJson.results[0].geometry.location.lng,
            },
          },
        });
      });
  }

  async onChangeAddAddress(addPlaceAddress) {
    try {
      this.setState({
        tentativePrice: '',
        showAddressSuggestion: false,
        addPlaceAddress,
      });
      var result = await this.googleAutocomplete(
        addPlaceAddress,
        this.state.curLatitude,
        this.state.curLongitude,
      );
      this.setState({
        predictions: result.predictions,
        showAddressSuggestion: true,
      });
      // var adress_data = result.predictions;
      // this.setState({
      //   myaddress_list: adress_data,
      // });
      if (result.predictions.length == 0) {
        this.setState({
          showAddressSuggestion: false,
        });
      }
    } catch (err) {
      // console.error(err);
    }
  }

  setTypeChecked = (type) => {
    this.setState({ addrPlaceName: type });
  }

  ShowAddPlacesView() {
    const predictions = this.state.predictions.map((prediction, index) => (
      <TouchableOpacity
        style={styles.prediction}
        key={index}
        onPress={() =>
          this.setAddressLocation(prediction.place_id, prediction.description)
        }>
        <Text style={{ margin: 10 }} key={prediction.id}>
          {prediction.description}
        </Text>
      </TouchableOpacity>
    ));
    return (
      <View
        style={{
          flex: 1,
          height: '100%',
          width: '100%',
          backgroundColor: 'white',
          position: 'absolute'
        }}>
        {/* <View
          style={{
            flexDirection: 'row',
            marginTop: '25%',
            padding: '2%',
            backgroundColor: '#f5f5f5',
          }}>
          <Image
            resizeMode="contain"
            style={{
              height: 20,
              width: 20,
              tintColor: 'black',
              backgroundColor: 'transparent',
              top: 10,
            }}
            source={Images.addressIcon}
          />
          <TextInput
            placeholder={strings.Name}
            placeholderTextColor="black"
            onChangeText={addrName => this.setState({ addrName })}
            value={this.state.addrName}
            style={[styles.pickuplocation, { marginLeft: 10 }]}
          />
        </View> */}

        <View
          style={{
            flexDirection: 'row',
            marginTop: '25%',
            padding: '2%',
            marginHorizontal: wp(5),
            borderRadius: 25,
            backgroundColor: Colors.White,
            shadowColor: "#000",
            shadowOffset: {
              width: 0,
              height: 3,
            },
            shadowOpacity: 0.29,
            shadowRadius: 4.65,

            elevation: 7,
          }}>

          <TextInput
            placeholder={strings.Address}
            placeholderTextColor="black"
            maxLength={40}
            onChangeText={addPlaceAddress =>
              this.onChangeAddAddress(addPlaceAddress)
            }
            value={this.state.addPlaceAddress}
            style={styles.savelocation}
          />
        </View>

        {this.state.showAddressSuggestion ? (
          <View style={styles.suggestionAddAdress}>{predictions}</View>
        ) : null}

        <View style={styles.addrsName}>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Home' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Home')}>
              <Text style={styles.addrPlaceTypeText}>Home</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Work' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Work')}>
              <Text style={styles.addrPlaceTypeText}>Work</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Office' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Office')}>
              <Text style={styles.addrPlaceTypeText}>Office</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Mum' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Mum')}>
              <Text style={styles.addrPlaceTypeText}>Mum</Text>
            </TouchableOpacity>
          </View>
        </View>


        <View style={styles.addrsName}>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Dad' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Dad')}>
              <Text style={styles.addrPlaceTypeText}>Dad</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Doctor' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Doctor')}>
              <Text style={styles.addrPlaceTypeText}>Doctor</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Supermarket' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Supermarket')}>
              <Text style={styles.addrPlaceTypeText}>Supermarket</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'BestFriend' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('BestFriend')}>
              <Text style={styles.addrPlaceTypeText}>Best Friend</Text>
            </TouchableOpacity>
          </View>
        </View>


        <View style={styles.addrsName}>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Restaurant' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Restaurant')}>
              <Text style={styles.addrPlaceTypeText}>Restaurant</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Pub' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Pub')}>
              <Text style={styles.addrPlaceTypeText}>Pub</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'School' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('School')}>
              <Text style={styles.addrPlaceTypeText}>School</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.selectedView, {
            backgroundColor: this.state.addrPlaceName == 'Other' ? Colors.PrimaryColor : Colors.White
          }]}>
            <TouchableOpacity onPress={() => this.setTypeChecked('Other')}>
              <Text style={styles.addrPlaceTypeText}>Other</Text>
            </TouchableOpacity>
          </View>
        </View>



        <TouchableOpacity
          onPress={() => this.SaveAddress()}
          style={{
            width: '90%',
            height: 45,
            borderRadius: 27,
            backgroundColor: Colors.PrimaryColor,
            alignSelf: 'center',
            justifyContent: 'center',
            bottom: '10%',
            position: 'absolute',
          }}>
          <Text style={{ alignSelf: 'center', color: 'white', fontFamily: Fonts.Semibold }}>{strings.save}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  async SaveAddress() {
    const { addrName, addrPlaceName, addAddress, addPlaceAddress, addressId, addressType } = this.state;
    let address = addAddress;
    console.log("parammm", addrPlaceName, address)
    if (this.verifyCredentials()) {
      if (this.state.addressType == 'update') {
        const data = {
          addressId: addressId,
          name: addrPlaceName,
          address: addAddress
        }
        this.props.editAddrRequest(data, this.props.navigation);
      } else {
        this.props.addAddressRequest(addrPlaceName, address, this.props.navigation);
      }

      this.setState({ addPlacesVIew: false, addrPlaceName: 'Home', addPlaceAddress: '', addressType: 'add' });
    }
  }

  verifyCredentials() {
    const { addPlaceAddress } = this.state;
    if (isEmpty(addPlaceAddress.trim())) {
      alert(strings.addressAlert);
      return false;
    }
    return true;
  }

  deleteSavedAddress(addressId) {
    Alert.alert(
      strings.alert,
      'Are you sure to want to remove this address!',
      [
        {
          text: strings.Yes,
          onPress: () => {
            this.props.removeAddressRequest(addressId, this.props.navigation);
          },
        },
        {
          text: strings.No,
          onPress: () => console.log('OK Pressed'),
        },
      ],
      { cancelable: false },
    );
  }



  liveFeedAction() {
    this.makeConnection(this.state.tripId, this.state.uid);
  }

  makeConnection = async (channel, id) => {
    await this._engine?.joinChannel(null, channel, null, id);
    await this._engine.enableVideo();
    this._engine.enableAudio();
    this.setState({ ChildVideo: true });
  };

  hitApi(channel, id) {
    var data = JSON.stringify({
      cname: '6135c3a32f3377768d9171eb',
      uid: '30',
      clientRequest: {},
    });

    var config = {
      method: 'post',
      url:
        'https://api.agora.io/v1/apps/f704b47d663440238ac95ad939ab1fb2/cloud_recording/acquire',
      headers: {
        'Content-Type': 'application/json',
        Authorization:
          'Basic YWE3MWEyMWFlYmYyNDIwZWJkZGE5YmFmOWU5YzZkYTk6N2YwYzE3ZDBmNjBiNGUzMDgwMGI0NWNlYTFjYjY1MjE=',
      },
      data: data,
    };

    axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  noOfSeats = (text) => {
    this.setState({ isSingle: text });
  };

  addStop() {
    var count = this.state.StopsCount;
    if (count < 2) {
      if (count == 0) {
        count++;
        this.setState({ StopsCount: count });
      } else if (this.state.FirstStopLocation != '') {
        count++;
        this.setState({ StopsCount: count });
      } else {
        this.showAlert(strings.addfirststop, 300);
      }
    } else {
      this.showAlert(strings.maximumstopadded, 300);
    }
  }

  clearAddress(Loctype) {
    let type = this.typeReturn(Loctype);
    this.setState({ [type]: '', showSuggestion: false });
  }

  setDestinationLocation(placeId, description) {
    console.log("click run", placeId, description)
    Keyboard.dismiss();
    this.setState({
      destinationLocation: description,
      showSuggestionDest: false,
      destinationPlaceID: placeId,
    });

    fetch(
      'https://maps.googleapis.com/maps/api/geocode/json?address=' +
      description +
      '&key=' +
      Config.GOOGLE_MAPS_APIKEY,
    )
      .then(response => response.json())
      .then(responseJson => {
        console.log("resss", responseJson, responseJson.results[0].geometry.location.lat)
        this.setState(
          {
            dropOneway: {
              address_components: responseJson.results[0].address_components,
              formatted_address: responseJson.results[0].formatted_address,
              place_id: responseJson.results[0].place_id,
              location: {
                lat: responseJson.results[0].geometry.location.lat,
                lng: responseJson.results[0].geometry.location.lng,
              },
            },
          },
          () => {
            if (this.state.selSourcePlaceId.length > 0 && placeId.length > 0) {
              this.updateDropState();
            }
          },
        );
        this.setState({
          destlatt: location.lat,
          destlongi: location.lng,
        });
      })
      .catch((error) => console.log(error));

  }

  setSourceLocation = (placeId, description, types) => {
    Keyboard.dismiss();
    let type = this.typeReturn(types);
    let typePlace = this.typeReturnPlaceId(types);
    let typeLocPick = this.typeReturnLocationPick(types);
    this.setState({
      [type]: description,
      [typePlace]: placeId,
      showSuggestion: false,
    });
    Geocoder.from(description)
      .then((json) => {
        console.log('json');
        console.log(json);
        this.setState(
          {
            [typeLocPick]: {
              address_components: json.results[0].address_components,
              formatted_address: json.results[0].formatted_address,
              place_id: json.results[0].place_id,
              location: {
                lat: json.results[0].geometry.location.lat,
                lng: json.results[0].geometry.location.lng,
              },
            },
          },
          () => {
            if (
              this.state.selSourcePlaceId.length > 0 &&
              this.state.destinationPlaceID.length > 0
            ) {
              this.updateDropState();
            }
          },
        );
      })
      .catch((error) => console.log(error));
  };

  typeReturn(type) {
    if (type == 'source') return 'sourceLocation';
    else if (type == 'stop1') return 'FirstStopLocation';
    else if (type == 'stop2') return 'SecondStopLocation';
    else return 'destinationLocation';
  }

  typeReturnPlaceId(type) {
    if (type == 'source') return 'selSourcePlaceId';
    else if (type == 'stop1') return 'FirstStopLocationPlaceID';
    else if (type == 'stop2') return 'SecondStopLocationPlaceID';
    else return 'destinationPlaceID';
  }

  typeReturnLocationPick(type) {
    if (type == 'source') return 'SourcePick';
    else if (type == 'stop1') return 'FirstLocationPick';
    else if (type == 'stop2') return 'SecondLocationPick';
    else return 'dropOneway';
  }

  async onChangeSource(sourceLocation, Loctype) {
    try {
      let type = this.typeReturn(Loctype);
      console.log(type);
      this.setState({
        Loctype,
        tentativePrice: '',
        showSuggestion: false,
        [type]: sourceLocation,
      });
      var result = await this.googleAutocomplete(
        sourceLocation,
        this.state.curLatitude,
        this.state.curLongitude,
      );
      this.setState({
        predictions: result.predictions,
        showSuggestion: true,
      });
      if (result.predictions.length == 0) {
        this.setState({
          showSuggestion: false,
        });
      }
    } catch (err) {
      console.log(err);
      this.showAlert(err.message, 300);
    }
  }

  onRegionChangeComplete = (region) => {
    console.log(region);
    Geocoder.from(region.latitude, region.longitude).then((json) => {
      console.log(json.results[0].formatted_address);
      //       formatted_address: json.results[0].formatted_address,
      this.setState({
        mapAddress: json.results[0].formatted_address,
        mapaddress_components: json.results[0].address_components,
        mapplace_id: json.results[0].place_id,
        maplocation: {
          lat: json.results[0].geometry.location.lat,
          lng: json.results[0].geometry.location.lng,
        },
      });
    });
  };


  freshRenderView = () => {
    const predictions = this.state.predictions.map((prediction, index) => (
      <TouchableHighlight
        style={styles.prediction}
        key={index}
        onPress={() =>
          this.setSourceLocation(
            prediction.place_id,
            prediction.description,
            this.state.Loctype,
          )
        }>
        <Text style={{ margin: 8 }} key={prediction.id}>
          {prediction.description}
        </Text>
      </TouchableHighlight>
    ));
    if (this.state.savedPlacesView == true) {
      return (
        <View
          style={{
            flex: 3,
            height: '100%',
            position: 'absolute',
            width: '100%',
            backgroundColor: 'white',
          }}>
          {this.showSavedPlacesView()}
          {this.state.addPlacesVIew == true ? this.ShowAddPlacesView() : null}
        </View>
      );
    } else {
      return (
        <React.Fragment>
          <MapView
            zoomControlEnabled
            zoomEnabled={true}
            style={styles.mapView}
            ref={(ref) => (this.mapsView = ref)}
            region={{
              latitude: this.state.curLatitude,
              longitude: this.state.curLongitude,
              latitudeDelta: LATITUDE_DELTA,
              longitudeDelta: LONGITUDE_DELTA,
            }}>
            <MapView.Marker
              style={{ backgroundColor: 'transparent' }}
              ref={(marker) => {
                this.markerdriver = marker;
              }}
              rotation={0}
              coordinate={{
                latitude: this.state.curLatitude,
                longitude: this.state.curLongitude,
              }}>
              <Animated.Image
                source={Images.locationPin2}
                style={{
                  height: 35,
                  width: 35,
                  tintColor: Colors.colorDark,
                  resizeMode: 'contain',
                }}
              />
            </MapView.Marker>

            {this.state.onlineDrivers.length > 0 ? (
              this.state.onlineDrivers.map(marker => {
                if (marker.coordinates.latitude && marker.coordinates.longitude) {
                  return (<MapView.Marker
                    coordinate={marker.coordinates}
                    key={marker._id}
                  >
                    <Animated.Image
                      resizeMode="contain"
                      source={Images.carTop}
                      style={{ height: 35, width: 35 }}
                    />
                  </MapView.Marker>)
                }
              })
            ) : null}
          </MapView>

          <Callout style={styles.sourceDestMain}>
            <View style={[styles.sourceDestView, { opacity: this.state.NoDriverFoundView ? 0 : 1 }]}>
              <View style={styles.sourceDestImg}>
                <Image
                  style={styles.pickupLocationImg}
                  source={Images.pickupLocation}
                />
                <View
                  style={{
                    backgroundColor: 'black',
                    width: 1,
                    height:
                      this.state.StopsCount == 0
                        ? 40
                        : this.state.StopsCount == 1
                          ? 90
                          : 145,
                  }}
                  source={Images.locationVertical}
                />
                <Image
                  style={styles.dropLocationImg}
                  source={Images.dropLocation}
                />
              </View>
              <View style={styles.searchMain}>
                {/* <TouchableOpacity
                onPress={() =>
                  this.setState({addressfill: 'source', addressPicker: true})
                }> */}
                <EnterLocView
                  heading={strings.From}
                  refs={(ref) => (this.refSource = ref)}
                  placeholder={strings.Enterpickupaddress}
                  loc={this.state.sourceLocation}
                  onChangeLocation={(text) => this.onChangeSource(text, 'source')}
                  onClearLoc={() => this.clearAddress('source')}
                  focus={(focus) => this.setState({ sourcefocus: focus })}
                />
                {/* </TouchableOpacity> */}
                {this.state.sourcefocus && this.state.sourceLocation == '' ? (
                  <TouchableOpacity
                    style={styles.mapbutton}
                    onPress={() => {
                      Keyboard.dismiss();
                      this.setState({
                        addressfill: true,
                        adrresType: 'source',
                      });
                    }}>
                    <Image source={Images.GPRS3} style={styles.mapbuttonIcon} />
                    <Text style={styles.mapbuttontext}>Set location on map</Text>
                  </TouchableOpacity>
                ) : null}

                <View style={styles.sectionDivider} />

                {this.state.StopsCount != 0 ? (
                  <View>
                    <View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
                      <EnterLocView
                        heading={strings.stopH}
                        refs={this.ref}
                        placeholder={strings.stopP}
                        loc={this.state.FirstStopLocation}
                        onChangeLocation={(text) =>
                          this.onChangeSource(text, 'stop1')
                        }
                        onClearLoc={() => this.clearAddress('stop1')}
                        focus={(focus) => this.setState({ stop1focus: focus })}
                      />

                      {this.state.StopsCount == 1 ? (
                        <TouchableOpacity
                          onPress={() => {
                            this.clearAddress('stop1');
                            this.setState({ StopsCount: 0 });
                          }}
                          style={{ height: 20, width: 20, marginBottom: 6 }}>
                          <Image
                            resizeMode="contain"
                            style={{ width: '100%', height: '100%' }}
                            source={Images.deleteIcon}
                          />
                        </TouchableOpacity>
                      ) : null}
                    </View>

                    {this.state.stop1focus &&
                      this.state.FirstStopLocation == '' ? (
                      <TouchableOpacity
                        style={styles.mapbutton}
                        onPress={() => {
                          Keyboard.dismiss();
                          this.setState({
                            addressfill: true,
                            adrresType: 'stop1',
                          });
                        }}>
                        <Image
                          source={Images.GPRS3}
                          style={styles.mapbuttonIcon}
                        />
                        <Text style={styles.mapbuttontext}>
                          Set location on map
                        </Text>
                      </TouchableOpacity>
                    ) : null}
                    <View style={styles.sectionDivider} />

                    {this.state.StopsCount == 2 ? (
                      <View>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'flex-end',
                          }}>
                          <TouchableOpacity
                            onPress={() =>
                              this.setState({
                                addressfill: 'stop2',
                                addressPicker: true,
                              })
                            }>
                            <EnterLocView
                              heading={strings.stopHH}
                              refs={this.ref}
                              placeholder={strings.stopPP}
                              loc={this.state.SecondStopLocation}
                              onChangeLocation={(text) =>
                                this.onChangeSource(text, 'stop2')
                              }
                              onClearLoc={() => this.clearAddress('stop2')}
                              focus={(focus) =>
                                this.setState({ stop2focus: focus })
                              }
                            />
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() => {
                              this.clearAddress('stop2');
                              this.setState({ StopsCount: 1 });
                            }}
                            style={{ height: 20, width: 20, marginBottom: 6 }}>
                            <Image
                              resizeMode="contain"
                              style={{ width: '100%', height: '100%' }}
                              source={Images.deleteIcon}
                            />
                          </TouchableOpacity>
                        </View>

                        {this.state.stop2focus &&
                          this.state.SecondStopLocation == '' ? (
                          <TouchableOpacity
                            style={styles.mapbutton}
                            onPress={() => {
                              Keyboard.dismiss();
                              this.setState({
                                addressfill: true,
                                adrresType: 'stop2',
                              });
                            }}>
                            <Image
                              source={Images.GPRS3}
                              style={styles.mapbuttonIcon}
                            />
                            <Text style={styles.mapbuttontext}>
                              Set location on map
                            </Text>
                          </TouchableOpacity>
                        ) : null}
                        <View style={styles.sectionDivider} />
                      </View>
                    ) : null}
                  </View>
                ) : null}

                <EnterLocView
                  heading={strings.To}
                  refs={this.ref}
                  placeholder={strings.Enterdestination}
                  loc={this.state.destinationLocation}
                  onChangeLocation={(text) =>
                    this.onChangeSource(text, 'destination')
                  }
                  onClearLoc={() => this.clearAddress('destination')}
                  focus={(focus) => this.setState({ destinationfocus: focus })}
                />

                {this.state.destinationfocus &&
                  this.state.destinationLocation == '' ? (
                  <TouchableOpacity
                    style={styles.mapbutton}
                    onPress={() => {
                      Keyboard.dismiss();
                      this.setState({
                        addressfill: true,
                        adrresType: 'destination',
                      });
                    }}>
                    <Image source={Images.GPRS3} style={styles.mapbuttonIcon} />
                    <Text style={styles.mapbuttontext}>Set location on map</Text>
                  </TouchableOpacity>
                ) : null}
              </View>
            </View>

            {/* {this.state.StopsCount == 2 ? null : (
            <View
              style={[
                styles.sourceDestMain2,
                {
                  marginTop: 15,
                },
              ]}>
              <TouchableOpacity
                style={styles.addStopTouch}
                onPress={() => this.addStop()}>
                <VectorIcon
                  name={'plus'}
                  groupName={'AntDesign'}
                  size={20}
                  color={Colors.Black}
                />
                <Text style={styles.addStopText}>{strings.addstop}</Text>
              </TouchableOpacity>
            </View>
          )} */}

            <View
              style={[
                styles.sourceDestMain2,
                {
                  marginTop: 15,
                  opacity: this.state.NoDriverFoundView ? 0 : 1
                },
              ]}>
              <TouchableOpacity
                style={styles.addStopTouch}
                onPress={() => this.openSavedPlacesView()}>
                <VectorIcon
                  name={'star'}
                  groupName={'Entypo'}
                  size={20}
                  color={'gray'}
                />
                <Text style={styles.addStopText}>{strings.addstop}</Text>
              </TouchableOpacity>
            </View>
          </Callout>

          {this.state.showSuggestion ? (
            <Callout
              style={[
                styles.suggestionDest,
                {
                  marginTop:
                    this.state.Loctype == 'source'
                      ? 160
                      : this.state.Loctype == 'stop1' ||
                        this.state.StopsCount === 0
                        ? 215
                        : this.state.Loctype == 'stop2' ||
                          this.state.StopsCount === 1
                          ? 270
                          : 325,
                },
              ]}>
              {predictions}
            </Callout>
          ) : null}

          <Callout style={[styles.locationGPRSMain, { opacity: this.state.NoDriverFoundView ? 0 : 1 }]}>
            <TouchableOpacity
              style={styles.locationGPRS}
              onPress={() => this.getCurrentLocationInstant(true)}>
              <Image
                resizeMode="stretch"
                style={styles.gprsImg}
                source={Images.gprs2}
              />
            </TouchableOpacity>
          </Callout>
        </React.Fragment>
      );
    }
  };

  showItemMapRenderView = () => {
    return (
      // <React.Fragment>
      <MapView
        style={styles.mapView}
        ref={(ref) => (this.mapsViews = ref)}
        // zoomEnabled={true}
        initialRegion={{
          latitude: this.state.showCurLat,
          longitude: this.state.showCurLng,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      // region={{
      //   latitude: this.state.showCurLat,
      //   longitude: this.state.showCurLng,
      //   latitudeDelta: 0.0922,
      //   longitudeDelta: 0.0421,
      // }}
      >
        <MapMarker
          identifier={'m1'}
          flat={false}
          title={this.state.curAddress}
          // rotation={this.state.angle}
          coordinate={{
            latitude: this.state.showCurLat,
            longitude: this.state.showCurLng,
          }}>
          <Animated.Image
            source={Images.locationPin2}
            style={{ height: 30, width: 30, resizeMode: 'contain' }}
          />
        </MapMarker>

        <MapMarker
          identifier={'m2'}
          flat={false}
          title={this.state.destAddress}
          coordinate={{
            latitude: this.state.showdestLat,
            longitude: this.state.ShowdestLng,
          }}>
          <Animated.Image
            source={Images.pickShow}
            style={{ height: 30, width: 30, resizeMode: 'contain' }}
          />
        </MapMarker>

        {this.state.stoplatlong.length != 0 &&
          this.state.stoplatlong.map((coordinate, index) => (
            <MapView.Marker
              key={`coordinate_${index}`}
              title={coordinate.title}
              coordinate={coordinate}></MapView.Marker>
          ))}

        <MapViewDirections
          origin={{
            latitude: this.state.showCurLat,
            longitude: this.state.showCurLng,
          }}
          destination={{
            latitude: this.state.showdestLat,
            longitude: this.state.ShowdestLng,
          }}
          waypoints={
            this.state.stoplatlong.length > 0 ? this.state.stoplatlong : []
          }
          apikey={Config.GOOGLE_MAPS_APIKEY}
          strokeColor="black"
          strokeWidth={2.5}
          resetOnChange={true}
        />
      </MapView>
      // </React.Fragment>
    );
  };

  showItemCarListView = () => {
    const {
      selectedRide,
      ScheduleSetup,
      bikeSelected,
      estimationCostArr,
      selectedCardImage,
    } = this.state;
    return (
      <KeyboardAvoidingView
        behavior="padding"
        keyboardVerticalOffset={keyboardVerticalOffset}
        style={styles.carListcontainer}>
        {selectedRide == 'child' ? (
          <View>
            <TouchableOpacity
              style={styles.rideDesView}
              onPress={() => this.rideDescriptionAction()}>
              <Image
                source={Images.ic_ride_description}
                style={{ height: 20, width: 20, marginLeft: 5 }}
              />
              <Text style={styles.rideDesText}>{strings.RideDescription}</Text>
            </TouchableOpacity>
            <View style={styles.sepratorLine} />
          </View>
        ) : null}

        <View style={styles.carListOptionView}>
          <RideNameType
            type={selectedRide == 'standard'}
            text={strings.StandaradRide}
            onclick={() => this.standardRideAction()}
          />
          {/* <RideNameType
            type={selectedRide == 'child'}
            text={strings.ChildRide}
            onclick={() => this.childRideAction()}
          /> */}
        </View>

        <View style={styles.viewCarFlatList}>
          <FlatList
            style={{ width: '100%', height: widthCal / 3 }}
            data={estimationCostArr}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            scrollEnabled={true}
            keyExtractor={(item) => item._id.toString()}
            renderItem={({ item, index }) => (
              <TouchableOpacity
                onPress={() => this.bikeSel(item, item.carType == 'Share Ride')}
                disabled={
                  (item.carType == 'Share Ride' && selectedRide === 'child') ||
                    (item.carType == 'Share Ride' && ScheduleSetup) ||
                    (item.carType == 'Share Ride' &&
                      this.state.StopsArray.length != 0)
                    ? true
                    : false
                }
                style={[
                  styles.CarItemFullView,
                  {
                    marginLeft: index == 0 ? 20 : 8,
                    opacity:
                      (item.carType == 'Share Ride' &&
                        selectedRide === 'child') ||
                        (item.carType == 'Share Ride' && ScheduleSetup) ||
                        (item.carType == 'Share Ride' &&
                          this.state.StopsArray.length != 0)
                        ? 0.3
                        : 0.9,
                  },
                ]}>
                {bikeSelected == item._id ? (
                  <Image
                    resizeMode="contain"
                    style={[
                      styles.rideSelectPoint,
                      { tintColor: Colors.buttonsColor },
                    ]}
                    source={Images.rightImg}
                  />
                ) : (
                  <Image style={styles.rideSelectPoint} />
                )}
                <Image source={{ uri: item.carImage }} style={styles.carImg} />
                <Text style={styles.carType}>{item.carType}</Text>
                <Text style={styles.RideCostText}>
                  {this.state.currency} {item.estimatedCost}
                </Text>
                <View style={{ flexDirection: 'row' }}>
                  <Image
                    resizeMode='contain'
                    style={{ width: 12, height: 12, top: 5 }}
                    source={Images.personIcon}
                  />
                  <Text style={{ fontSize: RFPercentage(2) }}>{item.maxPersons}</Text>
                </View>
              </TouchableOpacity>
            )}
          />
        </View>

        {/* <View
          style={[
            styles.paymentRowView,
            {
              justifyContent: 'flex-start',
              marginLeft: '6%',
              marginTop: 10,
              marginBottom: 5,
            },
          ]}>
          <Text style={{fontFamily: Fonts.Regular, fontSize: 16}}>
            {strings.redeemPoints}
          </Text>
          <View>
            <TextInput
              style={styles.redeeminput}
              placeholder={strings.Points}
              placeholderTextColor={'black'}
              keyboardType="number-pad"
              returnKeyType="done"
              onChangeText={(points) => this.setState({points: points})}
              value={this.state.points}
              autoCorrect={false}
            />
            <Text style={{marginLeft: 16, marginTop: 2, fontSize: 12}}>
              {'100 '} {strings.Points + ' = 1$'}
            </Text>
          </View> */}

        {/* <TouchableOpacity onPress={this.ApplyRedeem} style={{marginLeft: 12}}>
            <Text style={styles.redeemTxt}>{strings.redeem}</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.sepratorLine} /> */}

        <View style={styles.paymentRowView}>
          <TouchableOpacity
            onPress={() => this.tapCard()}
            style={{
              flexDirection: 'row',
              backgroundColor: 'transparent',
            }}>
            <Image
              resizeMode="contain"
              style={styles.selectedCardImg}
              source={{ uri: selectedCardImage }}
            />
            <Text style={{ top: 8, right: 8 }}>{this.state.selectedCardNum}</Text>
            <Image
              resizeMode="contain"
              style={{ top: 10, width: 12, height: 10 }}
              source={Images.downArrow}
            />
          </TouchableOpacity>

          {this.state.showcoupon ? (
            <View style={{ backgroundColor: 'white', width: 100 }}>
              <TextInput
                placeholder={strings.PromoCode}
                onChangeText={(promoCode) => {
                  if (promoCode.length == 1 && promoCode == ' ') {
                  } else {
                    this.setState({ promoCode });
                  }
                }}
                style={{ padding: 0 }}
                returnKeyType="done"
                value={this.state.promoCode}
                autoCorrect={false}
              />
              <View style={styles.sepratorLine} />
            </View>
          ) : (
            <View>
              <Text style={{ color: '#CACDD4', fontWeight: 'bold' }}>
                {strings.PromoCodeApplied}
              </Text>
            </View>
          )}

          {this.state.showcoupon ? (
            <View>
              <TouchableOpacity onPress={this.ApplyCoupon}>
                <Text style={{ color: Colors.buttonsColor }}>
                  {strings.Apply}
                </Text>
              </TouchableOpacity>
            </View>
          ) : (
            <Image source={Images.shieldIc} style={styles.shieldIc} />
          )}
        </View>

        <View style={styles.sepratorLine} />

        <View style={styles.ConfirmAndPickBtView}>
          <TouchableOpacity
            onPress={() => {
              if (this.state.isShared) {
                this.setState({ shareView: true, showitem: false });
              } else {
                this.ApplyConfirm();
              }
            }}
            style={styles.confirmButtonView}>
            <Text style={styles.confirmText}>
              {this.state.isShared
                ? strings.next
                : ScheduleSetup == true
                  ? strings.Schedule
                  : strings.confirm}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              flexDirection: 'row',
              opacity: this.state.isShared ? 0.3 : 0.9,
            }}
            disabled={this.state.isShared ? true : false}
            onPress={this.ApplySchedule}>
            <Image
              resizeMode="contain"
              style={styles.calenderIc}
              source={Images.calender}
            />
            <Text style={styles.schduleTxt}>
              {this.state.ScheduleSetup
                ? this.state.date + ' ' + this.state.Time
                : strings.Schedule}
            </Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    );
  };

  onChat() {
    this.props.navigation.navigate(Config.Chat, {
      driverId: this.state.driverId,
    });
  }

  otpScreenRenderView = () => {
    return (
      <View
        style={{
          backgroundColor: 'white',
          width: '100%',
          padding: 7,
          bottom: 10,
        }}>
        <View
          style={{
            // width: 100,
            marginHorizontal: wp(5),
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginBottom: wp(2)
          }}>
          <Text
            style={{
              textAlign: 'center',
              color: Colors.FontDarkColor,
              fontFamily: Fonts.Semibold,
            }}>
            Price: {this.state.currency}{this.state.estimatedCost}
          </Text>
          <Text
            style={{
              textAlign: 'center',
              color: Colors.FontDarkColor,
              fontFamily: Fonts.Semibold,
            }}>
            {strings.OTP}: {this.state.tripOTP}
          </Text>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <View style={{ flex: 0.6 }}>
            <Image
              style={{
                width: 50,
                height: 50,
                borderRadius: 25,
                alignSelf: 'center',
              }}
              source={
                this.state.driverImage == '' ||
                  this.state.driverImage == null ||
                  this.state.driverImage == 'null' ||
                  this.state.driverImage == 'none'
                  ? Images.dummyUser
                  : { uri: this.state.driverImage }
              }
              resizeMode={'cover'}
            />
            <Text
              style={{
                fontFamily: Fonts.Regular,
                fontSize: wp(3.5),
                alignSelf: 'center',
              }}>
              {this.state.driverName}
            </Text>
          </View>
          <View style={{ flex: 1.6, marginHorizontal: 5 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text
                style={{
                  color: 'black',
                  justifyContent: 'center',
                  marginRight: 4,
                }}>
                {strings.carNumber}
              </Text>
              <View
                style={{
                  borderRadius: 10,
                  paddingTop: 1,
                  paddingBottom: 1,
                  paddingLeft: 7,
                  paddingRight: 7,
                  backgroundColor: Colors.graylighted,
                }}>
                <Text
                  style={{
                    color: '#000',
                    fontFamily: Fonts.Semibold,
                  }}>
                  {this.state.plateNumber}
                </Text>
              </View>

              <View style={{ flexDirection: 'row', marginLeft: wp(10), alignItems: 'center' }}>
                <Text>{this.state.driverAvgRtaing}</Text>
                <Image
                  style={{
                    height: hp(4),
                    width: wp(4),
                    left: 3,
                    resizeMode: 'contain',
                  }}
                  source={Images.star_blackIcon}
                />
              </View>
            </View>

            <Text
              style={{
                color: 'black',
                justifyContent: 'center',
                marginRight: 4,
                marginTop: 2,
              }}>
              {this.state.carName}
            </Text>

            <Text
              style={{
                color: Colors.FontDarkColor,
                fontFamily: Fonts.Regular,
                marginTop: 2,
              }}>
              {
                'Driver on the way to you now he will get to your pick up location within '
              }{' '}
              {this.state.estimatedTime} Min.
            </Text>
          </View>
        </View>
        <View
          style={{
            marginTop: 15,
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: 'white',
            justifyContent: 'center',
          }}>
          <TouchableOpacity
            style={{
              flexDirection: 'row',
              backgroundColor: Colors.PrimaryColor,
              paddingHorizontal: 10,
              borderRadius: 25,
              width: '40%',
              height: 50,
              alignItems: 'center',
              justifyContent: 'center',
              borderColor: Colors.PrimaryColor,
              borderWidth: 1,
            }}
            onPress={() =>
              this.makeDriverCall(
                this.state.driverMobileCode + this.state.driverMobileNumber,
              )
            }>
            <Text style={{
              textAlign: 'center',
              color: 'white',
              fontFamily: Fonts.Semibold,
              fontSize: 16,
            }}>Call</Text>
          </TouchableOpacity>
          {/* <TouchableOpacity
            style={{
              width: '25%',
              flexDirection: 'row',
              marginHorizontal: 10,
              backgroundColor: Colors.PrimaryColor,
              paddingHorizontal: 10,
              borderRadius: 25,
              height: 50,
              alignItems: 'center',
              justifyContent: 'center',
              shadowColor: Colors.graylight,
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.8,
              elevation: 5,
            }}
            onPress={() => this.onChat()}>
            <Image
              source={Images.emailIcon}
              style={{
                width: 25,
                height: 25,
                tintColor: 'white',
                resizeMode: 'contain',
              }}
            />
          </TouchableOpacity> */}

          <TouchableOpacity
            style={{
              width: '40%',
              flexDirection: 'row',
              marginHorizontal: 10,
              backgroundColor: Colors.White,
              paddingHorizontal: 10,
              borderRadius: 25,
              height: 50,
              alignItems: 'center',
              justifyContent: 'center',
              shadowColor: Colors.graylight,
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.8,
              elevation: 5,
            }}
            onPress={() => this.setState({ CancelView: true })}>
            <Text
              style={{
                marginLeft: 2,
                textAlign: 'center',
                color: 'black',
                fontFamily: Fonts.Semibold,
                fontSize: 16,
              }}>
              {strings.cancelRide}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      // </View>
    );
  };

  cancelRenderView = () => {
    return (
      <View
        style={{
          // flex: 0.32,
          position: 'absolute',
          bottom: 0,
          height: heightCal * 0.28,
          width: '100%',
          justifyContent: 'flex-end',
        }}>
        <View
          style={{
            backgroundColor: 'white',
            height: heightCal * 0.28,
            padding: 10,
            borderRadius: 15,
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: 20,
              width: '80%',
              alignSelf: 'center',
            }}>
            <Text
              style={{
                fontFamily: Fonts.Semibold,
                fontSize: 18,
                marginTop: 5,
              }}>
              {strings.cancelSure}
            </Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: 'white',
              justifyContent: 'center',
              marginTop: 20,
              marginBottom: 15,
            }}>
            <TouchableOpacity
              style={{
                flexDirection: 'row',
                backgroundColor: Colors.PrimaryColor,
                borderRadius: wp('13%'),
                width: '40%',
                height: wp('13%'),
                alignItems: 'center',
                justifyContent: 'center',
                borderColor: Colors.PrimaryColor,
                borderWidth: 1,
              }}
              onPress={() => this.setState({ CancelView: false })}>
              <Text
                style={{
                  marginLeft: 2,
                  textAlign: 'center',
                  color: Colors.White,
                  fontFamily: Fonts.Semibold,
                  fontSize: 16,
                }}>
                {strings.No}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                marginLeft: 15,
                width: '40%',
                flexDirection: 'row',
                backgroundColor: Colors.White,
                borderRadius: wp('13%'),
                height: wp('13%'),
                alignItems: 'center',
                justifyContent: 'center',
                shadowColor: 'gray',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.8,
                elevation: 5,
              }}
              onPress={() => this.cancelRide()}>
              <Text
                style={{
                  marginLeft: 2,
                  textAlign: 'center',
                  color: Colors.PrimaryColor,
                  fontFamily: Fonts.Semibold,
                  fontSize: 16,
                }}>
                {strings.Yes}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  tripCompleteRenderView = () => {
    const { currency } = this.state;
    return (
      <RatingFeedBack
        currency={currency}
        orderTotal={this.state.estimatedCost}
        tip={this.state.tipAmount}
        ontip={(tipAmount) => this.setState({ tipAmount, CustomTip: '' })}
        CustomTip={this.state.CustomTip}
        onCustomTip={(CustomTip) =>
          this.setState({ CustomTip: CustomTip, tipAmount: '' })
        }
        ratingValue={this.state.ratingValue}
        onPress={(ratingValue) => this.setState({ ratingValue })}
        value={this.state.feedbackTxt}
        onChangeText={(feedbackTxt) => this.setState({ feedbackTxt })}
        onSubmit={() => this.submitRating()}
        onDispute={() => {
          let daten = new Date();

          this.props.navigation.navigate(Config.AddDispute, {
            tripData: this.state.tripData,
            day: JSON.stringify(daten),
          });
        }}
      />
    );
  };

  returnStarImg(noEmpty) {
    if (noEmpty) return Images.starBlack;
    else return Images.starBlank;
  }

  findingDriverRenderView = () => {
    return (
      <View
        needsOffscreenAlphaCompositing={true}
        style={styles.searchingContainer}>
        <View style={styles.findingDriverView}>
          <Text style={styles.findingtxt}>{strings.findingDriver}</Text>
          <DotIndicator color="black" size={10} />
        </View>
      </View>
    );
  };

  descriptionRenderView = () => {
    return (
      <RideDescription
        value={this.state.descriptionRideString}
        onClose={() => this.rideDescriptionAction()}
        onChangeText={(descriptionRideString) =>
          this.setState({ descriptionRideString })
        }
        onSubmit={() => this.submitDescription()}
      />
    );
  };

  handleTimePicked = (date) => {
    var newTime = moment(date, ['h:mm A']).format('HH:mm');
    this.setState({ isTimePickerVisible: false, Time: newTime, Datos: date });
  };

  handleDatePicked = (date) => {
    var datePicked = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();
    var dd = datePicked + '-' + month + '-' + year;
    this.setState({ date: dd, isDatePickerVisible: false });
  };

  hideTimePicker = () => {
    this.setState({ isTimePickerVisible: false });
  };

  hideDatePicker = () => {
    this.setState({ isDatePickerVisible: false });
  };

  scheduleRenderView = () => {
    const curDate = new Date();
    return (
      <View style={styles.schduleContainer}>
        <View style={styles.schduleViewHeader}>
          <Text style={styles.schduleheadTxt}>{strings.scheduleARide}</Text>
        </View>

        <View style={styles.scheduleTimeView}>
          <Text style={styles.schdulepicktxt}>{strings.PickupTime}</Text>
          <TextInput
            style={{ marginLeft: 5, height: 30, color: 'black', padding: 0 }}
            placeholder={strings.selectTime}
            placeholderTextColor={'black'}
            autoCorrect={false}
            value={this.state.Time}
          />
          <TouchableOpacity
            onPress={() => this.openTimePicker()}
            style={styles.scheduletimeTouch}
          />
          <DateTimePicker
            date={curDate}
            isVisible={this.state.isTimePickerVisible}
            onConfirm={this.handleTimePicked}
            onCancel={this.hideTimePicker}
            mode="time"
          />
        </View>
        <View style={styles.scheduleTimeView}>
          <Text style={styles.schdulepicktxt}>{strings.PickupDate}</Text>
          <TextInput
            style={{ marginLeft: 5, height: 30, color: 'black', padding: 0 }}
            placeholder={strings.selectDate}
            placeholderTextColor={'black'}
            autoCorrect={false}
            value={this.state.date}
          />
          <TouchableOpacity
            onPress={() => this.openDatePicker()}
            style={styles.scheduletimeTouch}
          />
          <DateTimePicker
            date={curDate}
            isVisible={this.state.isDatePickerVisible}
            onConfirm={this.handleDatePicked}
            onCancel={this.hideDatePicker}
            mode="date"
            minimumDate={curDate}
          />
        </View>
        <View style={styles.schedulebuttons}>
          <TouchableOpacity
            onPress={() => this.setPickUp()}
            style={styles.schduleSetTouch}>
            <Text style={styles.scheduleSetTxt}> {strings.SetPickupTime} </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={this.closeRide}
            style={styles.schdulecancelTouch}>
            <Text style={styles.schduleCancelText}>
              {strings.cancelSchedule}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  shareRenderView = () => {
    return (
      <ShareSelectSeats
        currency={this.state.currency}
        estimatedCost={this.state.estimatedCost}
        seats={this.state.isSingle}
        onSeatChange={(text) => this.noOfSeats(text)}
        onConfirm={() => this.applyShare()}
        onClose={() => this.closeShare()}
      />
    );
  };

  paymentMethodRenderView = () => {
    return (
      <PaymentList
        PaymentListData={this.state.PaymentListData}
        payAction={(item) => this.payAction(item)}
        navigation={this.props.navigation}
        onCancel={() => this.cardCancelHide()}
      />
    );
  };

  preferredRenderView = () => {
    return (
      <View
        style={{
          backgroundColor: 'white',
          width: '100%',
          height: '100%',
          position: 'absolute',
          bottom: 0,
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <View style={styles.container2} />

        <View
          style={{
            width: '90%',
            alignItems: 'center',
            backgroundColor: 'white',
            borderRadius: 15,
          }}>
          <Image
            source={Images.car_top}
            style={{
              width: 90,
              height: 90,
              marginBottom: 10,
              marginTop: 20,
              resizeMode: 'contain',
            }}
          />
          <Text
            style={{
              fontSize: 20,
              width: '85%',
              fontFamily: Fonts.Semibold,
              marginTop: 15,
              marginBottom: 15,
              textAlign: 'center',
            }}>
            {strings.Preferredlist}
          </Text>
          <View
            style={{
              width: '100%',
              height: 50,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: 15,
              marginBottom: 15,
            }}>
            <TouchableOpacity
              style={{
                flexDirection: 'row',
                backgroundColor: Colors.PrimaryColor,
                borderRadius: 25,
                width: '45%',
                height: 50,
                alignItems: 'center',
                justifyContent: 'center',
                borderColor: Colors.PrimaryColor,
                borderWidth: 1,
              }}
              onPress={() => this.yesAction()}>
              <Text
                style={{
                  marginLeft: 2,
                  textAlign: 'center',
                  color: Colors.White,
                  fontFamily: Fonts.Semibold,
                  fontSize: 16,
                }}>
                {strings.Yes}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                marginLeft: 10,
                width: '45%',
                flexDirection: 'row',
                borderRadius: 25,
                height: 50,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: 'white',
                shadowColor: 'gray',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.8,
                elevation: 5,
              }}
              onPress={() => this.noAction()}>
              <Text
                style={{
                  marginLeft: 2,
                  textAlign: 'center',
                  fontFamily: Fonts.Semibold,
                  fontSize: 16,
                }}>
                {strings.No}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  beforeTripStartRender = () => {
    return (
      <React.Fragment>
        <MapView.Marker
          style={{ backgroundColor: 'transparent' }}
          ref={(marker) => {
            this.marker = marker;
          }}
          flat={false}
          coordinate={{
            latitude: this.state.sourceLocationCord.latitude,
            longitude: this.state.sourceLocationCord.longitude,
          }}>
          <Image
            source={Images.pickupIcon}
            style={{ height: 20, width: 20, resizeMode: 'contain' }}
          />
        </MapView.Marker>
        <MapViewDirections
          origin={{
            latitude: this.state.driverLatitude,
            longitude: this.state.driverLongitude,
          }}
          destination={{
            latitude: this.state.sourceLocationCord.latitude,
            longitude: this.state.sourceLocationCord.longitude,
          }}
          apikey={Config.GOOGLE_MAPS_APIKEY}
          strokeColor="black"
          strokeWidth={2.5}
          resetOnChange={false}
        />
      </React.Fragment>
    );
  };

  afterTripStartRender = () => {
    return (
      <React.Fragment>
        <MapView.Marker
          title={this.state.endLocationAddr}
          identifier={'Destination'}
          style={{ backgroundColor: 'transparent' }}
          ref={(marker) => {
            this.marker = marker;
          }}
          flat={false}
          coordinate={{
            latitude: this.state.destinationLocationCord.latitude,
            longitude: this.state.destinationLocationCord.longitude,
          }}>
          <Image
            source={Images.locationPin2}
            style={{ height: 20, width: 20, resizeMode: 'contain' }}
          />
        </MapView.Marker>
        <MapViewDirections
          origin={{
            latitude: this.state.driverLatitude,
            longitude: this.state.driverLongitude,
          }}
          destination={{
            latitude: this.state.destinationLocationCord.latitude,
            longitude: this.state.destinationLocationCord.longitude,
          }}
          apikey={Config.GOOGLE_MAPS_APIKEY}
          strokeColor="black"
          strokeWidth={2.5}
          resetOnChange={false}
        />
      </React.Fragment>
    );
  };

  destinationInRouteRender = () => {
    return (
      <DestinationInRoute
        driverImage={this.state.driverImage}
        driverName={this.state.driverName}
        plateNumber={this.state.plateNumber}
        driverAvgRtaing={this.state.driverAvgRtaing}
        estimatedCost={this.state.estimatedCost}
        preferredDone={this.state.preferredDone}
        rideTyp={this.state.rideTyp}
        currency={this.state.currency}
        panicStatus={this.state.panicStatus}
        panicButtonAction={() => this.panicButtonAction()}
        preferredAction={() => this.preferredAction()}
        liveFeedAction={() => {
          this.liveFeedAction();
        }}
        record={() => this.uploadVideo()}
        carName={this.state.carName}
        AllData={this.state.AllData}
        onChangeAddress={(is) =>
          this.setState({ IsChangeAddress: is, showOK: false })
        }
        IsChangeAddress={this.state.IsChangeAddress}
        changeFocus={(focus) => this.setState({ IsFocus: focus })}
        IsFocus={this.state.IsFocus}
        keyBoardHeight={this.state.keyBoardHeight}
        onChangeText={(text) => this.onChangeNewAddress(text)}
        newText={this.state.newText}
        predictions1={this.state.predictions1}
        showSuggestion1={this.state.showSuggestion1}
        changeSuggestion={() =>
          this.setState({ showSuggestion1: false, newText: '' })
        }
        onSelectAddress={(prediction) => this.afterSelectNewAddress(prediction)}
        showOK={this.state.showOK}
        onOkPress={this.onChangeAddressFinal}
        endloaction={this.state.AllData.endLocationAddr}
      />
    );
  };

  onChangeAddressFinal = () => {
    let index = '';
    let isEndAddress = false;
    if (this.state.AllData.stopsArray.length == 0) {
      this.endAddressChange([]);
    } else {
      let new1 = this.state.AllData.stopsArray;
      let stopsArray = new1.sort((a, b) => a.stop - b.stop);
      for (let i = 0; i < stopsArray.length; i++) {
        // console.log(this.state.AllData.stopsArray[i]);
        if (stopsArray[i].status != 'completed') {
          index = i;
          break;
        } else {
          // console.log();
          if (stopsArray.length - 1 == i) {
            isEndAddress = true;
          }
        }
      }

      if (isEndAddress) {
        this.endAddressChange(stopsArray);
      } else {
        let data = stopsArray;
        data[index].address = this.state.newText;
        data[index].location.coordinates[0] = this.state.new_location.lat;
        data[index].location.coordinates[1] = this.state.new_location.lng;
        console.log(JSON.stringify(data));

        console.log(data[index]);
        let details = {
          tripId: this.state.AllData._id,
          stopsArray: data,
          destination: {
            endLocationAddr: this.state.AllData.endLocationAddr,
            endLocation: {
              lat: this.state.AllData.endLocation.coordinates[1],
              lng: this.state.AllData.endLocation.coordinates[0],
            },
          },
        };

        console.log(JSON.stringify(details));

        this.props.changeAddressRequest(details, this.props.navigation);
      }
    }
  };

  endAddressChange(stopsArray) {
    let details = {
      tripId: this.state.AllData._id,
      stopsArray: stopsArray,
      destination: {
        endLocationAddr: this.state.newText,
        endLocation: {
          lat: this.state.new_location.lat,
          lng: this.state.new_location.lng,
        },
      },
    };
    this.props.changeAddressRequest(details, this.props.navigation);
  }

  afterSelectNewAddress = (prediction) => {
    Keyboard.dismiss();
    console.log(prediction);
    this.setState({
      newText: prediction.description,
      newplaceId: prediction.placeId,
      showSuggestion1: false,
      IsFocus: false,
      showOK: true,
    });
    Geocoder.from(prediction.description)
      .then((json) => {
        console.log('json');
        console.log(JSON.stringify(json));
        this.setState({
          new_address_components: json.results[0].address_components,
          new_formatted_address: json.results[0].formatted_address,
          new_placeId: json.results[0].place_id,
          new_location: {
            lat: json.results[0].geometry.location.lat,
            lng: json.results[0].geometry.location.lng,
          },
        });
      })
      .catch((error) => console.log(error));
  };

  async onChangeNewAddress(text) {
    try {
      this.setState({
        showSuggestion1: false,
        newText: text,
      });
      var result = await this.googleAutocomplete(
        text,
        this.state.curLatitude,
        this.state.curLongitude,
      );
      this.setState({
        predictions1: result.predictions,
        showSuggestion1: true,
      });
      if (result.predictions.length == 0) {
        this.setState({
          showSuggestion1: false,
        });
      }
    } catch (err) {
      console.log(err);
      this.showAlert(err.message, 300);
    }
  }

  openTimePicker() {
    console.log('Time');
    this.setState({ isTimePickerVisible: true });
  }

  openDatePicker() {
    console.log('Date');
    this.setState({ isDatePickerVisible: true });
  }

  onMessage = (data) => {
    //Prints out data that was passed.
    console.log(data.nativeEvent);
    if (data.nativeEvent.canGoBack) {
      this.setState({ showModal: false });
    }
    // if(data.nativeEvent.canGoBack){
    //   this.setState({showModal:false})
    // }
  };

  render() {
    if (this.state.ChildVideo == true) {
      return this.videoView();
    }

    return (
      <View
        style={{
          flex: 1,
        }}>
        <View style={{ flex: 1 }}>
          <View style={styles.container}>
            {this.state.tripStatus == Config.TRIP_PICKUP_INROUTE ||
              this.state.tripStatus == Config.TRIP_ARRIVED ||
              this.state.tripStatus == Config.TRIP_DESTINATION_INROUTE ||
              this.state.tripStatus == Config.TRIP_COMPLETED ? (
              <MapView
                style={styles.mapView}
                showsMyLocationButton={true}
                ref={(ref) => (this.mapsView = ref)}
                zoomEnabled={true}
                region={{
                  latitude: this.state.driverLatitude,
                  longitude: this.state.driverLongitude,
                  latitudeDelta: 0.009,
                  longitudeDelta: 0.001,
                }}>
                <MapView.Marker
                  style={{
                    transform: [
                      {
                        rotate:
                          this.state.driverAngle === undefined
                            ? '0deg'
                            : `${this.state.driverAngle}deg`,
                      },
                    ],
                  }}
                  ref={(marker) => {
                    this.marker = marker;
                  }}
                  flat={false}
                  coordinate={{
                    latitude: this.state.driverLatitude,
                    longitude: this.state.driverLongitude,
                  }}>
                  <Image
                    resizeMode="contain"
                    source={Images.carTop}
                    style={{ height: 30, width: 30 }}
                  />
                </MapView.Marker>

                {this.state.tripStatus == Config.TRIP_PICKUP_INROUTE ||
                  this.state.tripStatus == Config.TRIP_ARRIVED
                  ? this.beforeTripStartRender()
                  : null}

                {this.state.tripStatus == Config.TRIP_DESTINATION_INROUTE
                  ? this.afterTripStartRender()
                  : null}
              </MapView>
            ) : null}

            {this.state.tripStatus == 'fresh' ? this.freshRenderView() : null}

            {this.state.showitem || this.state.Schedule || this.state.shareView
              ? this.showItemMapRenderView()
              : null}

            {this.state.savedPlacesView ? (
              <View
                style={[styles.backFromSaveAddr, { flexDirection: 'row' }]}
              >
                <TouchableOpacity onPress={() =>
                  this.state.addPlacesVIew == true
                    ? this.closeAddPlacesView()
                    : this.BackAction()
                } style={styles.saveAddrBack}>
                  <Image
                    resizeMode="contain"
                    style={styles.backIconSaveAddr}
                    source={Images.backIc}
                  />
                </TouchableOpacity>
                <View style={styles.chooseSavePlaceView}>
                  {this.state.addPlacesVIew == true ? (
                    <Text style={styles.choosePlace}>{strings.savePlace}</Text>
                  ) : (
                    <Text style={styles.choosePlace}>
                      {strings.choosePlace}
                    </Text>
                  )}
                </View>
              </View>
            ) : this.state.tripStatus == 'fresh' ||
              this.state.tripStatus != 'booking' ? (
              <View style={[styles.backTouchable, { opacity: this.state.NoDriverFoundView ? 0 : 1 }]}>
                <TouchableOpacity
                  style={styles.backTouchable2}
                  onPress={() => this.openDrawerClick()}>
                  <Image
                    resizeMode="contain"
                    style={styles.backIcon}
                    source={Images.menuBlack}
                  />
                </TouchableOpacity>
              </View>
            ) : null}


            {this.state.tripStatus == 'booking' ? (
              <View style={styles.backTouchable}>
                <TouchableOpacity
                  style={styles.backTouchable2}
                  onPress={() => this.BackAction()}>
                  <Image
                    resizeMode="contain"
                    style={styles.backIcSty}
                    source={Images.backIc}
                  />
                </TouchableOpacity>
              </View>
            ) : null}
          </View>

          {this.state.tripStatus == 'booking' ? (
            <Text
              style={[
                styles.rideHeaderOption,
                {
                  top: Platform.OS === 'ios' ? getStatusBarHeight() + 15 : 25,
                },
              ]}>
              {strings.rideOption}
            </Text>
          ) : null}

          {this.state.tripStatus == Config.TRIP_PICKUP_INROUTE ||
            this.state.tripStatus == Config.TRIP_ARRIVED
            ? this.otpScreenRenderView()
            : null}

          {this.state.tripStatus == Config.TRIP_COMPLETED
            ? this.tripCompleteRenderView()
            : null}

          {this.state.tripStatus == Config.TRIP_DESTINATION_INROUTE
            ? this.destinationInRouteRender()
            : null}

          {this.state.CancelView ? this.cancelRenderView() : null}

          {/* {this.state.FindDriver ? this.findingDriverRenderView() : null} */}
          {this.state.FindDriver ? <SearchingView /> : null}

          {this.state.showitem ? this.showItemCarListView() : null}
          {this.state.preferredClick ? this.preferredRenderView() : null}
          {this.state.RideDes ? this.descriptionRenderView() : null}
          {this.state.Schedule ? this.scheduleRenderView() : null}
          {this.state.shareView ? this.shareRenderView() : null}
          {this.state.paymentTap ? this.paymentMethodRenderView() : null}

          {this.state.NoDriverFoundView ? (
            <NoDriverRenderView onClick={() => this.goToDashBoard()} />
          ) : null}
          {this.state.showModal ? (
            <View
              style={{
                flex: 1,
                height: '100%',
                width: '100%',
                position: 'absolute',
                paddingTop: 40,
                backgroundColor: 'white',
              }}>
              <WebView
                source={{
                  uri: this.state.PaypalUrl,
                }}
                style={{ height: '100%', width: '100%' }}
                onMessage={this.onMessage.bind(this)}
              />
              <TouchableOpacity
                onPress={() => {
                  this.setState({ showModal: !this.state.showModal });
                }}
                style={{ position: 'absolute', top: 40, right: 20 }}>
                <Image source={Images.cancel} style={{ height: 20, width: 20 }} />
              </TouchableOpacity>
            </View>
          ) : null}
        </View>
        {this.state.addressfill ? this.ShowAddPlacesView() : null}
        {/* {this.state.IsChangeAddress ? this.changeAddressView() : null} */}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  mapView: {
    width: '100%',
    height: '100%',
  },
  prediction: {
    paddingVertical: 5,
    borderBottomWidth: 1.0,
    borderColor: 'gray',
  },
  sourceDestMain: {
    marginLeft: wp('5%'),
    marginRight: wp('5%'),
    marginTop: 96,
    borderRadius: wp('2%'),
    width: wp('90%'),
    shadowColor: Colors.graylight,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    elevation: 5,
    paddingBottom: wp('1%'),
    overflow: 'hidden',
  },
  sourceDestView: {
    borderRadius: 6,
    backgroundColor: 'white',
    width: wp('90%'),
    flexDirection: 'row',
  },
  sourceDestMain2: {
    height: 45,
    width: wp('90%'),
    alignSelf: 'center',
    shadowColor: Colors.graylight,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    elevation: 5,
    alignItems: 'center',
    overflow: 'hidden',
  },
  sourceDestImg: {
    width: wp('5%'),
    marginLeft: wp('2%'),
    marginTop: 37,
    alignItems: 'center',
  },
  buttonBar: {
    height: 70,
    backgroundColor: '#0093E9',
    display: 'flex',
    width: '100%',
    position: 'absolute',
    bottom: 0,
    left: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    alignContent: 'center',
    paddingBottom: 20,
  },
  localVideoStyle: {
    width: 140,
    height: 160,
    position: 'absolute',
    top: 5,
    right: 5,
    zIndex: 100,
  },
  iconStyle: {
    fontSize: 34,
    paddingTop: 15,
    paddingLeft: 40,
    paddingRight: 40,
    paddingBottom: 15,
    borderRadius: 0,
  },
  searchMain: {
    width: wp('75%'),
    marginLeft: wp('2%'),
    marginTop: wp('3%'),
  },
  pickupLocationImg: {
    width: wp('2.5%'),
    height: wp('2.5%'),
    tintColor: 'green',
    resizeMode: 'contain',
  },
  addrDeleteIcon: {
    padding: 10,
    width: 10,
    height: 10,
    marginRight: 15
  },
  dropLocationImg: {
    width: wp('3%'),
    height: wp('3%'),
    resizeMode: 'contain',
  },
  savelocation: {
    fontSize: wp('3.5%'),
    width: '95%',
    height: wp('10%'),
    backgroundColor: 'white',
    marginLeft: 10
  },
  dropLocation: {
    fontSize: wp('3.5%'),
    height: wp('10%'),
    width: '89%',
  },
  sectionDivider: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 45 : 52,
    height: 1,
    width: '100%',
    backgroundColor: 'gray',
  },
  locationGPRSMain: {
    width: 80,
    height: 80,
    backgroundColor: 'transparent',
    position: 'absolute',
    bottom: hp('3%'),
    right: 20,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.graylight,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 1,
    elevation: 5,
  },
  gprsImg: {
    width: 50,
    height: 50,
  },
  standardRide: {
    width: '32%',
    marginLeft: 10,
    height: 40,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    flexDirection: 'row',
    alignItems: 'center',
  },
  childRide: {
    width: '30%',
    marginLeft: 10,
    height: 40,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    flexDirection: 'row',
    alignItems: 'center',
  },
  rideDescription: {
    width: '32%',
    marginLeft: 5,
    height: 40,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    flexDirection: 'row',
    alignItems: 'center',
  },
  carType: {
    fontFamily: Fonts.Regular,
  },
  suggestionDest: {
    marginLeft: wp('10%'),
    borderRadius: wp('2%'),
    backgroundColor: 'white',
    height: 'auto',
    width: wp('85%'),
    shadowColor: Colors.graylight,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    elevation: 5,
    paddingLeft: wp('2%'),
  },
  locationGPRS: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 60,
    height: 60,
    backgroundColor: 'transparent',
  },
  backTouchable: {
    position: 'absolute',
    width: 50,
    height: 50,
    top: Platform.OS === 'ios' ? getStatusBarHeight() + 10 : 20,
    left: wp('4.5%'),
  },
  backTouchable2: {
    shadowColor: Colors.graylight,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    elevation: 5,
    width: 35,
    height: 35,
    backgroundColor: 'white',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    width: 26,
    height: 26,
  },
  addStopText: {
    fontSize: wp('3.5%'),
    marginLeft: '2%',
    fontFamily: Fonts.Regular,
  },
  addStopTouch: {
    flexDirection: 'row',
    height: '100%',
    width: '100%',
    paddingLeft: 10,
    backgroundColor: 'white',
    alignItems: 'center',
    borderRadius: 6,
  },
  carListcontainer: {
    width: '100%',
    backgroundColor: 'white',

    bottom: 0,
  },
  carListOptionView: {
    width: '100%',
    height: 40,
    flexDirection: 'row',
    marginTop: 10,
  },
  rideDesView: {
    marginLeft: '5%',
    height: 35,
    backgroundColor: 'transparent',
    flexDirection: 'row',
    alignItems: 'center',
  },
  rideDesText: {
    color: 'gray',
    fontFamily: Fonts.Semibold,
    fontWeight: 'bold',
    fontSize: 14,
    backgroundColor: 'transparent',
    marginLeft: 10,
  },
  CarItemFullView: {
    width: widthCal / 3 - 10,
    height: widthCal / 3 - 10,
    flexDirection: 'column',
    backgroundColor: 'white',
    shadowColor: Colors.graylight,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    elevation: 5,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 8,
    borderRadius: 10,
  },
  viewCarFlatList: {
    width: '100%',
    height: widthCal / 3,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    marginLeft: '0%',
  },
  rideSelectPoint: {
    width: 50,
    height: 15,
    position: 'absolute',
    right: 8,
    top: 20,
    zIndex: 2,
  },
  RideCostText: {
    color: 'black',
    fontSize: 13,
    backgroundColor: 'transparent',
    fontWeight: 'bold',
  },
  carImg: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
  },
  sepratorLine: {
    borderBottomWidth: 2,
    marginTop: 5,
    borderBottomColor: '#CACDD4',
    opacity: 0.6,
  },
  paymentRowView: {
    height: 40,
    marginTop: 5,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'space-around',
    flexDirection: 'row',
  },
  selectedCardImg: {
    height: 35,
    width: 35,
    marginRight: 20,
    marginLeft: '6%',
  },
  confirmButtonView: {
    width: '50%',
    height: wp('12%'),
    marginTop: 0,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 10,
    borderRadius: 27,
    backgroundColor: Colors.buttonsColor,
  },
  confirmText: {
    color: 'white',
    fontFamily: Fonts.Semibold,
    fontSize: 18,
  },
  ConfirmAndPickBtView: {
    flexDirection: 'row',
    marginLeft: 25,
    marginRight: 25,
    marginTop: 15,
    marginBottom: 15,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  schduleTxt: {
    fontFamily: Fonts.Semibold,
    fontSize: 18,
  },
  calenderIc: {
    width: 30,
    height: 20,
    alignSelf: 'center',
  },
  backIcSty: {
    width: 30,
    height: 30,
    marginLeft: 4,
  },
  shieldIc: {
    height: 18,
    width: 18,
    resizeMode: 'contain',
  },
  schduleContainer: {
    height: 320,
    backgroundColor: 'white',
    bottom: 0,
  },
  schduleViewHeader: {
    flexDirection: 'row',
    backgroundColor: 'white',
    width: '100%',
    height: 50,
  },
  schduleheadTxt: {
    fontFamily: Fonts.Semibold,
    color: 'black',
    fontSize: 16,
    position: 'absolute',
    left: 10,
    top: 15,
  },
  chooseSavePlaceView: {
    position: 'absolute',
    width: '100%',
    height: wp(20),
    paddingTop: 26,
    alignSelf: 'center',
    // left: 15,
    //backgroundColor: 'red',
    justifyContent: 'center',
  },
  choosePlace: {
    alignSelf: 'center',
    fontSize: wp('5%'),
    color: 'black',
    //  flex: 6,
    fontFamily: Fonts.Semibold,
    // textAlign: 'center',
  },
  backFromSaveAddr: {
    position: 'absolute',
    width: wp('100%'),
    height: Platform.select({
      ios: 50 + getStatusBarHeight(),
      android: 70,
    }),
    // backgroundColor: Colors.Orange
  },
  backIconSaveAddr: {
    width: 26,
    height: 26,
  },
  saveAddrBack: {
    top: Platform.OS === 'ios' ? wp(12) : wp(9),
    left: wp(5),
    height: 30,
    zIndex: 9999
  },
  scheduleTimeView: {
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 15,
    paddingLeft: 10,
    marginLeft: 10,
    width: widthCal - 20,
    marginTop: 15,
  },
  schdulepicktxt: {
    marginLeft: 5,
    marginTop: 5,
  },
  scheduletimeTouch: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
  },
  loaderStyle: {
    backgroundColor: 'white',
    width: '100%',
    height: '100%'
  },
  schedulebuttons: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginHorizontal: 30,
    marginTop: 20,
  },
  schduleSetTouch: {
    width: '50%',
    height: wp('12%'),
    marginTop: 15,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 27,
    backgroundColor: Colors.PrimaryColor,
  },
  scheduleSetTxt: {
    color: 'white',
    fontFamily: Fonts.Semibold,
    fontSize: 20,
  },
  schduleCancelText: {
    color: Colors.buttonRed,
    fontFamily: Fonts.Semibold,
    fontSize: 20,
  },
  addrsName: {
    marginTop: wp(6),
    flexDirection: 'row',
    marginHorizontal: wp(6),
    justifyContent: 'space-around'
  },
  selectedView: {
    padding: 5,
    borderRadius: 25,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 4.65,
    elevation: 7,
  },
  addrPlaceTypeText: {
    paddingHorizontal: 5,
    fontFamily: Fonts.Semibold,
    fontSize: RFPercentage(2),
  },
  schdulecancelTouch: {
    width: '50%',
    height: 45,
    marginTop: 15,
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  redeeminput: {
    backgroundColor: Colors.graylight,
    marginLeft: 10,
    padding: Platform.OS == 'ios' ? 4 : 0,
    paddingLeft: 8,
    width: 100,
    borderRadius: 12,
  },
  redeemTxt: {
    fontSize: 16,
    color: Colors.buttonsColor,
    fontFamily: Fonts.Semibold,
  },
  rideHeaderOption: {
    position: 'absolute',
    alignSelf: 'center',
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
    fontFamily: Fonts.Semibold,
  },
  searchingContainer: {
    flex: 1,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'black',
    opacity: 0.7,
    position: 'absolute',
  },
  findingDriverView: {
    width: '90%',
    height: 75,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 1,
  },
  findingtxt: {
    fontSize: 15,
    fontWeight: 'bold',
    color: 'black',
    top: 10,
  },
  starImgIC: {
    width: wp('9%'),
    height: wp('9%'),
    resizeMode: 'contain',
  },
  container2: {
    position: 'absolute',
    height: '100%',
    width: '100%',
    backgroundColor: 'black',
    opacity: 0.4,
  },
  mapbutton: {
    width: '100%',
    height: 45,
    backgroundColor: Colors.PrimaryColor,
    alignItems: 'center',
    flexDirection: 'row',
  },
  mapbuttonIcon: {
    width: 22,
    height: 22,
    resizeMode: 'contain',
    tintColor: 'white',
    marginLeft: 10,
  },
  mapbuttontext: {
    color: 'white',
    marginLeft: 7,
    fontFamily: Fonts.Semibold,
  },
});
