import React, {Component} from 'react';
import {StyleSheet, View, Image, Text, TextInput, Keyboard} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {strings} from '../../constants/languagesString';
import {HeaderWhiteTitle} from './../../components/CustomComponent/renderHeader';
import Images from '../../constants/Images';
import {LoginButtons} from '../../components/Buttons/Button';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';

export default class SupportMessage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      message: '',
      supportData: '',
      mainViewTop: 0,
    };
  }

  componentDidMount() {
    this.keyboardListener();
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  keyboardListener() {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow.bind(this),
    );
    this.keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      this._keyboardDidHide.bind(this),
    );
  }

  _keyboardDidShow() {
    this.setState({
      mainViewTop: -200,
    });
  }

  _keyboardDidHide() {
    this.setState({
      mainViewTop: 0,
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.supportData !== this.props.supportData) {
      this.setState({supportData: this.props.supportData}, () => {
        var data = this.props.supportData;
        this.afterGetSupportData(data);
      });
    }
  }
  afterGetSupportData = (data) => {
    this.setState({name: '', message: ''});
  };

  sendMessage() {
    let data = {
      name: this.state.name,
      msg: this.state.message,
    };
    this.props.supportRequest(data, this.props.navigation);
  }

  showAlert(message, duration) {
    setTimeout(() => {
      alert(message);
    }, 300);
  }

  goToNextScreen() {
    if (this.state.name.trim() != '' && this.state.message.trim() != '') {
      this.sendMessage();
    } else {
      this.showAlert(strings.Pleasefillallrequiredfields, 300);
    }
  }

  render() {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: 'white',
          marginTop: this.state.mainViewTop,
        }}>
        <Image source={Images.supportMsgBg} style={styles.coverImg} />
        <HeaderWhiteTitle
          back={true}
          title={strings.HelpSupport}
          navigation={this.props.navigation}
        />

        <View style={{flex: 1}}>
          <View
            style={{
              flex: 0.35,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Text style={styles.needsomehelptxt}>
              {strings.NeedSomeHelp.toUpperCase()}
            </Text>

            <Text style={styles.feelfreetotouch}>
              {strings.Feelfreetogetintouchwithus}
            </Text>
          </View>

          <View style={{flex: 0.65, marginTop: wp(15)}}>
            <View style={styles.tile}>
              <TextInput
                style={styles.searchTextInput}
                placeholder={strings.enterName}
                placeholderTextColor={'#818e97'}
                autoCorrect={false}
                value={this.state.name}
                onChangeText={(name) => {
                  if (name.length == 1 && name == ' ') {
                  } else {
                    this.setState({name});
                  }
                }}
                onSubmitEditing={() => this.message.focus()}
              />
            </View>

            <View style={styles.tileFeedback}>
              <TextInput
                style={[styles.searchTextInput, {height: 110}]}
                placeholder={strings.Message}
                placeholderTextColor={'#818e97'}
                multiline={true}
                numberOfLines={5}
                autoCorrect={false}
                returnKeyType={'done'}
                blurOnSubmit={true}
                textAlignVertical={'top'}
                onSubmitEditing={() => {
                  Keyboard.dismiss();
                }}
                onChangeText={(message) => {
                  if (message.length == 1 && message == ' ') {
                  } else {
                    this.setState({message});
                  }
                }}
                value={this.state.message}
                ref={(message) => (this.message = message)}
              />
            </View>

            <LoginButtons
              text={strings.Submit}
              onClick={() => this.goToNextScreen()}
            />
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  coverImg: {
    flex: 0.4,
    height: hp('40%'),
    width: '100%',
    position: 'absolute',
    resizeMode: 'cover',
  },
  needsomehelptxt: {
    marginTop: -wp('5%'),
    fontSize: wp('6%'),
    color: 'white',
    fontFamily: Fonts.Semibold,
  },
  title: {
    fontSize: wp('4.8%'),
    color: 'white',
    marginTop: -10,
  },
  tile: {
    backgroundColor: 'white',
    width: 'auto',
    height: wp('13.33%'),
    marginTop: wp('5%'),
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 0.4,
    borderColor: '#818e97',
    borderRadius: 10,
    backgroundColor: Colors.graylights,
  },
  searchTextInput: {
    height: 'auto',
    width: '100%',
    marginLeft: 10,
    backgroundColor: 'transparent',
    borderColor: 'gray',
    borderRadius: 0,
    fontSize: wp('4.8%'),
    color: Colors.FontDarkColor,
    fontFamily: Fonts.Semibold,
  },
  arrowTile: {
    width: '100%',
    height: 70,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    alignContent: 'center',
  },
  bottomView: {
    position: 'absolute',
    bottom: 40,
    width: '100%',
  },
  tileFeedback: {
    backgroundColor: 'white',
    width: 'auto',
    height: 140,
    marginTop: wp('5%'),
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 0.4,
    borderColor: '#818e97',
    borderRadius: 10,
    backgroundColor: Colors.graylights,
  },
  feelfreetotouch: {
    fontSize: wp('4%'),
    marginTop: wp('1%'),
    color: 'white',
    fontFamily: Fonts.Regular,
  },
});
