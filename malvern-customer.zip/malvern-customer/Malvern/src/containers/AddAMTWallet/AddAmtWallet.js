import React, {Component} from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {strings} from '../../constants/languagesString';
import styles from './style';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import Images from '../../constants/Images';
import Fonts from '../../constants/Fonts';
import moment from 'moment';
import Colors from '../../constants/Colors';
import {SignUpInputText} from '../../components/InputTexts/Inputext';
import {LoginButtons} from '../../components/Buttons/Button';
import {RenderHeaderBack} from './../../components/CustomComponent/renderHeader';
import {Keyboard} from 'react-native';

export default class AddAmtWallet extends Component {
  constructor(props) {
    super(props);
    this.state = {
      addmount: '',
      PaymentList: false,
      dataSource: [],
      selected: '',
    };
    // this.didFocusListener = this.props.navigation.addListener(
    //   'focus',
    //   this.componentDidFocus,
    // );
  }
  // componentDidFocus = () => {};

  componentDidMount() {
    let currency = this.props.contactsData.App_Settings.Admin_Currency_Code;
    this.setState({currency: currency});
    this.getPaymentMethodList();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.PaymentListData !== this.props.PaymentListData) {
      console.log('this.props.PaymentListData');
      this.setState({dataSource: this.props.PaymentListData}, () => {
        this.afterGetPaymentMethodList();
      });
    }
    if (prevProps.AddedAmountData !== this.props.AddedAmountData) {
      console.log('this.props.PaymentListData');
      this.props.navigation.goBack();
      // this.setState({dataSource: this.props.PaymentListData}, () => {
      //   this.afterGetPaymentMethodList();
      // });
    }
  }

  getPaymentMethodList = () => {
    this.props.PaymentMethodListRequest(this.props.navigation);
  };

  afterGetPaymentMethodList() {
    // item.type != 'Cash' ||
    // item.type != 'Wallet' ||
    // item.type != 'Paypal' ?
    let arra = this.props.PaymentListData;
    let arra2 = arra.filter(
      (item) =>
        item.type !== 'Cash' &&
        item.type !== 'Wallet' &&
        item.type !== 'Paypal',
    );
    this.setState({
      dataSource: arra2,
    });
  }

  onPress = () => {
    const {addmount} = this.state;
    if (addmount == '') {
      this.showAlert('Enter a valid amount.');
    } else {
      Keyboard.dismiss();
      this.setState({PaymentList: true});
    }
  };

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }
  addCardAction() {
    this.props.navigation.navigate('AddCard');
  }

  onAddBalance() {
    this.setState({PaymentList: false});
    let details = {
      walletCredit: parseFloat(this.state.addmount),
      paymentSourceRefNo: this.state.selected,
    };
    console.log(details);
    this.props.addWalletBalanceRequest(details, this.props.navigation);
  }

  render() {
    const {PaymentList, selected} = this.state;
    return (
      <View style={styles.container}>
        <RenderHeader
          back={true}
          title={strings.addbalance}
          navigation={this.props.navigation}
        />
        {/* <View style={styles.balanceHeaderView}> */}
        <View style={{marginTop: 20}}>
          <SignUpInputText
            // header={strings.Name}
            // icon={Images.profileIcon}
            placeholder={strings.Amount}
            keyboardType={'number-pad'}
            onChangeText={(addmount) =>
              this.setState({addmount: addmount.replace(/[^0-9]/g, '')})
            }
            text={this.state.addmount}
          />
        </View>

        <LoginButtons text={strings.next} onClick={() => this.onPress()} />
        {/* </View> */}

        {PaymentList ? (
          <View
            style={{
              width: '100%',
              height: '100%',
              backgroundColor: 'white',
              position: 'absolute',
            }}>
            <RenderHeaderBack
              onBack={() => this.setState({PaymentList: false, selected: ''})}
              title={strings.choosepayment}
            />
            <FlatList
              data={this.state.dataSource}
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={
                <Text
                  style={{
                    fontSize: 16,
                    fontFamily: Fonts.Semibold,
                    marginTop: 40,
                    alignSelf: 'center',
                  }}>
                  No payment method
                </Text>
              }
              renderItem={({item}) => (
                <TouchableOpacity
                  style={styles.loadDetail}
                  onPress={() => this.setState({selected: item._id})}>
                  <View style={styles.listItem}>
                    <View style={{width: '20%'}}>
                      <Image
                        resizeMode="contain"
                        style={{height: 40, width: 40}}
                        source={{uri: item.logo}}
                      />
                    </View>
                    {item.type === 'Cash' ? (
                      <Text style={{alignSelf: 'center'}}>
                        {strings.cashPayment}
                      </Text>
                    ) : item.type === 'Wallet' ? (
                      <View>
                        <Text style={{alignSelf: 'center'}}>{item.type}</Text>
                      </View>
                    ) : item.type === 'Paypal' ? (
                      <View>
                        <Text style={{alignSelf: 'center'}}>{item.type}</Text>
                      </View>
                    ) : (
                      <View style={styles.cardView}>
                        <View style={{alignSelf: 'center'}}>
                          <Text style={{marginRight: 20}}>
                            ***********{item.lastd}
                          </Text>
                        </View>
                        {/* <TouchableOpacity
                          onPress={() => this.deleteCard(item._id)}
                          style={styles.itemDelete}> */}
                        <View style={styles.itemDelete}>
                          <Image
                            resizeMode="contain"
                            style={{width: '100%', height: '100%'}}
                            source={
                              selected == item._id
                                ? Images.selected
                                : Images.unselected
                            }
                          />
                        </View>
                        {/* </TouchableOpacity> */}
                      </View>
                    )}
                  </View>
                </TouchableOpacity>
              )}
              keyExtractor={(item) => item._id}
            />
            <TouchableOpacity
              onPress={() => {
                if (selected !== '') {
                  this.onAddBalance();
                } else {
                  this.addCardAction();
                }
              }}
              style={styles.addCard}>
              <Image
                resizeMode="contain"
                style={{height: '100%', width: '100%'}}
                source={selected !== '' ? Images.nextIcon : Images.addIcon}
              />
            </TouchableOpacity>
          </View>
        ) : null}
      </View>
    );
  }
}
