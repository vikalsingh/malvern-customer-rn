import AddAmtWallet from './AddAmtWallet';
import {
  addWalletBalanceRequest,
  getWalletListRequest,
} from './../../modules/AddWallet/actions';

import {PaymentMethodListRequest} from './../../modules/GetPaymentMethodList/actions';
import {posDeleteRequest} from './../../modules/DeletePOS/actions';
import {connect} from 'react-redux';

const mapStateToProps = (state) => ({
  PaymentListData: state.paymentListReducer.paymentMethodData,
  ProfileData: state.GetProfileReducer.profileData,
  WalletList: state.addWalletBalanceReducer.walletList,
  AddedAmountData: state.addWalletBalanceReducer.addWalletBalanceData,
  contactsData: state.getContactsReducer.contactsData,
});

const mapDispatchToProps = (dispatch) => ({
  addWalletBalanceRequest: (details, navigation) =>
    dispatch(addWalletBalanceRequest(details, navigation)),
  getWalletListRequest: (navigation) =>
    dispatch(getWalletListRequest(navigation)),
  PaymentMethodListRequest: (navigation) =>
    dispatch(PaymentMethodListRequest(navigation)),
  posDeleteRequest: (posID, navigation) =>
    dispatch(posDeleteRequest(posID, navigation)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AddAmtWallet);
