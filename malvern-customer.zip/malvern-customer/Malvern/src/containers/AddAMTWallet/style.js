import {StyleSheet, Platform} from 'react-native';
import Fonts from '../../constants/Fonts';
import Colors from '../../constants/Colors';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  balanceHeaderView: {
    height: 80,
    width: '90%',
    backgroundColor: 'transparent',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  balanceTxt: {
    fontSize: wp('6.5%'),
    fontFamily: Fonts.Semibold,
  },
  balaceValueTxt: {
    fontSize: wp('6.5%'),
    fontFamily: Fonts.Semibold,
    color: Colors.PrimaryColor,
  },
  balaceValueTxt1: {
    fontSize: 18,
    fontFamily: Fonts.Semibold,
    color: Colors.White,
    backgroundColor: Colors.PrimaryColor,
    padding: 4,
  },
  NocoupanAvaibleText: {
    width: wp('100%'),
    marginTop: 20,
    textAlign: 'center',
  },
  sepratorLine: {
    borderBottomWidth: 1,
    borderColor: Colors.graylight,
  },
  loadDetail: {
    backgroundColor: 'white',
    borderColor: 'gray',
    marginBottom: 6,
    marginLeft: '3%',
    width: '94.5%',
    marginTop: 8,
    borderRadius: 14,
    padding: 6,
    shadowRadius: 5,
    borderBottomWidth: 0.0,
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
  },
  listItem: {
    flexDirection: 'row',
    margin: 5,
    alignItems: 'center',
  },
  itemDelete: {
    width: 30,
    height: 30,
    alignItems: 'center',
  },
  cardView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
  },
  itemDelete: {
    width: 30,
    height: 30,
    alignItems: 'center',
  },
  addCard: {
    backgroundColor: 'transparent',
    position: 'absolute',
    bottom: wp('20%'),
    right: wp('10%'),
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
});
export default styles;
