import Login from './Login';
import Password from './Password';
import VerifyOTP from './VerifyOTP';
import Register from './Register';

import Profile from './Profile';
import EditProfile from './EditProfile';

import NewsLetter from './NewsLetter';
import ChangePassword from './ChangePassword';
import MyTrip from './MyTrip';
import Emergency from './Emergency';
import Support from './Support';
import SupportMessage from './SupportMessage';
import Disputes from './Dispute';
import AddDispute from './AddDispute';
import About from './About';
import Invite from './Invite';
import AddCard from './AddCard';
import MapSearch from './Map';
import AccountDetail from './AccountDetail';
import Track from './Track';
import Thankyou from './Thankyou';
import AddContacts from './AddContacts';
import ChangePasswordProfile from './ChangePasswordProfile';
import CouponScreen from './Coupon';
import Wallet from './Wallet';
import PreferredDriver from './PreferredDriver';
import Chat from './Chat';

import AddAmtWallet from './AddAMTWallet';

import PrivacyPolicy from './Settings/PrivacyPolicy';
import TermsConditions from './Settings/TermsConditions';

export {
  Login,
  Password,
  VerifyOTP,
  Register,
  ChangePassword,
  MapSearch,
  MyTrip,
  NewsLetter,
  Wallet,
  Invite,
  PreferredDriver,
  Profile,
  EditProfile,
  Emergency,
  Support,
  SupportMessage,
  Disputes,
  AddDispute,
  About,
  AddCard,
  AccountDetail,
  Track,
  Thankyou,
  AddContacts,
  ChangePasswordProfile,
  CouponScreen,
  Chat,
  AddAmtWallet,
  PrivacyPolicy,
  TermsConditions,
};
