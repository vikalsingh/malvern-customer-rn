import React, {Component} from 'react';
import {StyleSheet, View, Image, Dimensions, Text} from 'react-native';
import {strings} from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeaderMain';
import {LoginButtons} from '../../components/Buttons/Button';
import Fonts from '../../constants/Fonts';
import Images from '../../constants/Images';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {SignUpInputText} from '../../components/InputTexts/Inputext';
const {width, height} = Dimensions.get('window');
import {getConfiguration} from '../../utils/configuration';
const regEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

export default class NewsLetter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      email: '',
    };
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.subscribeData !== this.props.subscribeData) {
      this.setState({email: ''});
      setTimeout(() => {
        alert('Subscribed successfully.');
      }, 600);
    }
  }

  sendMessage() {
    const {email} = this.state;
    if (email == undefined || email.length <= 0) {
      alert(strings.emailAlert);
      return false;
    } else if (!regEmail.test(email)) {
      alert(strings.validEmail);
      return false;
    } else {
      const customerid = getConfiguration('user_id');
      let data = {userId: customerid, email: email};
      this.props.subscribeRequest(data, this.props.navigation);
    }
  }

  render() {
    return (
      <View style={{flex: 1, backgroundColor: '#ffffff'}}>
        <RenderHeader
          title={strings.NewsLetter}
          navigation={this.props.navigation}
        />
        <KeyboardAwareScrollView>
          <View style={styles.gridViewBackground}>
            <View style={styles.viewFWebView}>
              <Image source={Images.subscribeImg} style={styles.subsImage} />
              <SignUpInputText
                header={strings.Email}
                icon={Images.WhiteEmail}
                onChangeText={(email) => this.setState({email})}
                keyboardType={'email-address'}
                text={this.state.email}
              />
            </View>
          </View>
        </KeyboardAwareScrollView>
        <View style={styles.arrowTile}>
          <LoginButtons
            text={strings.subscribe}
            onClick={() => this.sendMessage()}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  gridViewBackground: {
    marginTop: 0,
    marginBottom: 0,
    borderColor: 'white',
    borderWidth: 0.0,
    backgroundColor: 'white',
  },
  subsImage: {
    width: width * 0.65,
    height: width * 0.65,
    alignSelf: 'center',
    resizeMode: 'contain',
  },
  arrowTile: {
    width: '100%',
    alignSelf: 'center',
    alignContent: 'center',
    position: 'absolute',
    bottom: 40,
  },
  viewFWebView: {
    width: '100%',
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  newsletterTxt: {
    alignSelf: 'center',
    marginTop: -120,
    fontSize: wp('6%'),
    fontFamily: Fonts.Semibold,
  },
});
