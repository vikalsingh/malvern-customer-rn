import NewsLetter from './NewsLetter';
import {connect} from 'react-redux';
import {subscribeRequest} from './../../modules/Subscribe/actions';

const mapStateToProps = (state) => ({
  subscribeData: state.SubscribeReducer.subscribeData,
  isBusy: state.SubscribeReducer.isBusy,
});
const mapDispatchToProps = (dispatch) => ({
  subscribeRequest: (data, navigation) =>
    dispatch(subscribeRequest(data, navigation)),
});
export default connect(mapStateToProps, mapDispatchToProps)(NewsLetter);
