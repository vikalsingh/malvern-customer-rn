import Thankyou from './Thankyou';
export default Thankyou;
