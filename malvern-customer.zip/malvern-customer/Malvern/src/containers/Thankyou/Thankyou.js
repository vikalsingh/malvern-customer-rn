import React from 'react';
import {View, Text} from 'react-native';
import strings from '../../constants/languagesString';

export default class Thankyou extends React.Component {
  that = this;
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <View>
        <Text>{strings.thankyou}</Text>
      </View>
    );
  }
}
