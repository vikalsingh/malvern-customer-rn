import React from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  Keyboard,
  StyleSheet,
} from 'react-native';
import { showAlert } from '../../utils/CommonFunctions';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import { connect } from 'react-redux';
import { resetRequest } from '././../../modules/VerifyOTP/actions';
import Images from '../../constants/Images';
import Config from '../../constants/Config';
import ValidationMessage from '../../constants/ValidationMessage';
import SmoothPinCodeInput from 'react-native-smooth-pincode-input';
import strings from '../../constants/languagesString';
import Colors from '../../constants/Colors';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

class VerifyOTP extends React.Component {
  constructor(props) {
    super(props);
    console.log(this.props.route);
    this.state = {
      mainViewTop: 0,
      code: '',
      serverOTP: this.props.route.params.otp,
      mobileNumber: this.props.route.params.mobileNumber,
    };
    this.pinInput = React.createRef();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.resetData !== this.props.resetData) {
      this.setState({ serverOTP: this.props.resetData.data.OTP });
    }
  }

  componentDidMount() {
    const { route } = this.props;
    if (route.params.forgot) {
      this.requestResetotp('send');
    }
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow.bind(this),
    );
    this.keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      this._keyboardDidHide.bind(this),
    );
  }
  _keyboardDidShow() {
    this.setState({
      mainViewTop: -200,
    });
  }

  _keyboardDidHide() {
    this.setState({
      mainViewTop: 0,
    });
  }
  goBack() {
    this.props.navigation.goBack();
  }
  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  _checkCode = (code) => {
    console.log('code', code);
    this.goToNextScreen(code);
  };

  goToNextScreen = (code) => {
    const { serverOTP, mobileNumber } = this.state;
    console.log(code);
    const { navigation, route, resetData } = this.props;
    var otp = code;
    if (otp == serverOTP) {
      if (route.params.forgot) {
        this.props.navigation.navigate(Config.ChangePassword, {
          mobileNumber: mobileNumber,
          countryCode: route.params.countryCode,
          otp: otp,
          forgot: true,
        });
      } else {
        this.props.navigation.navigate(Config.Register, {
          mobileNumber: mobileNumber,
          countryCode: route.params.countryCode,
          countryName: route.params.countryName,
          otp: otp,
          verified: true,
        });
      }
    } else {
      this.pinInput.current.shake().then(() => this.setState({ code: '' }));
      showAlert(ValidationMessage.otpValid);
      Keyboard.dismiss();
    }
  };

  requestResetotp = (type) => {
    console.log("type:::", type)
    const { route, resetRequest } = this.props;
    const data = {
      countryCode: route.params.countryCode,
      mobileNumber: route.params.mobileNumber,
      type: type
    }
    resetRequest(data);
  };

  render() {
    const { code } = this.state;
    return (
      <View style={styles.container}>
        <RenderHeader
          back={true}
          title={strings.verifycode}
          navigation={this.props.navigation}
        />

        <View style={styles.gridViewBackground}>
          <View style={styles.otpHeading}>
            <Text style={styles.otpText}>{strings.otpScreenText}</Text>
            <Text style={styles.phoneText}>
              {this.props.route.params.countryCode}{' '}
              {this.props.route.params.mobileNumber} {' ' + strings.via}
            </Text>
          </View>

          <View style={styles.otp}>
            <SmoothPinCodeInput
              ref={this.pinInput}
              cellStyle={{
                borderBottomWidth: 2,
                borderColor: 'gray',
              }}
              cellStyleFocused={{
                borderColor: 'black',
              }}
              textStyle={styles.otpText2}
              textStyleFocused={styles.otpText2}
              codeLength={4}
              keyboardType="numeric"
              value={code}
              onTextChange={(code) => this.setState({ code })}
              onFulfill={this._checkCode}
            />
          </View>
        </View>
        <View />
        <View style={styles.resendView}>
          <TouchableOpacity
            style={styles.resendTile}
            onPress={() => this.requestResetotp('resend')}
          >
            <Text style={styles.txtResend}>{strings.Resendcode}</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.bottomView}>
          <View style={styles.arrowTile}>
            <TouchableOpacity
              style={styles.touchableArrow}
              onPress={this.goToNextScreen}>
              <Image style={styles.arrowIcon} source={Images.nextIcon} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}
const mapStateToProps = (state) => ({
  resetData: state.resetotpReducer.resetData,
});
const mapDispatchToProps = (dispatch) => ({
  resetRequest: (data) =>
    dispatch(resetRequest(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(VerifyOTP);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  otpHeading: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: 'auto',
    marginTop: 20,
    marginHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  otpText: {
    fontFamily: Fonts.Light,
    fontSize: wp('4.8%'),
    color: Colors.colorLight,
  },
  phoneText: {
    color: Colors.colorLight,
    fontFamily: Fonts.Light,
    fontSize: wp('4.8%'),
    marginTop: 5,
  },
  otp: {
    backgroundColor: Colors.background,
    width: 'auto',
    height: 50,
    marginTop: 30,
    marginHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  gridViewBackground: {
    width: '100%',
    marginTop: wp('20%'),
    borderColor: '#f5f6f8',
    backgroundColor: Colors.background,
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  touchableArrow: {
    height: wp('16%'),
    width: wp('16%'),
    marginRight: 20,
  },
  arrowTile: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginVertical: 20,
  },
  resendView: {
    marginTop: wp('15%'),
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginVertical: 20,
  },
  resendTile: {
    width: '100%',
    height: wp('9%'),
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  txtResend: {
    fontFamily: Fonts.Thin,
    color: 'red',
    fontSize: wp('4.8%'),
    textDecorationLine: 'underline',
  },
  bottomView: {
    position: Platform.OS === 'ios' ? 'absolute' : 'absolute',
    bottom: Platform.OS === 'ios' ? 40 : 0,
    width: '100%',
  },
  otpText2: {
    fontSize: 24,
    color: Colors.buttonsColor,
    fontFamily: Fonts.Semibold,
  },
});
