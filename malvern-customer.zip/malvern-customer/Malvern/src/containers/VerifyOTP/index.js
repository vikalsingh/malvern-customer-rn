import VerifyOTP from './VerifyOTP';
export default VerifyOTP;
