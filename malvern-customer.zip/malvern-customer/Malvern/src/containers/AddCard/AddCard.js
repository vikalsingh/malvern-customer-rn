import React, { Component } from 'react';
import { View, Text, TextInput, ActivityIndicator, TouchableOpacity } from 'react-native';
import stripe from 'tipsi-stripe';
import { strings } from '../../constants/languagesString';
import RenderHeader from './../../components/CustomComponent/renderHeader';
import Colors from '../../constants/Colors';
import styles from './style';
import { LoginButtons } from '../../components/Buttons/Button';
import { getConfiguration } from '../../utils/configuration';

// stripe.setOptions({
//   publishableKey: 'pk_test_LLAdXVApiHYl2QUmtHy2HiHT', //'pk_test_INM9aFcqplBpLxivFa68HdMt00LjD5iZ7U'     // test
//   androidPayMode: 'test', // Android only
// });

export default class AddCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cardNumber: '',
      cardName: '',
      expDate: '',
      cvv: '',
      prevScreen: 'Payment',
      loader: false,
    };
  }

  componentDidMount() {
    let paymentMode = this.props.contactsData.App_Settings.Payment_Mode;
    if (paymentMode == 'sandbox') {
      stripe.setOptions({
        publishableKey: 'pk_test_LLAdXVApiHYl2QUmtHy2HiHT', //'pk_test_INM9aFcqplBpLxivFa68HdMt00LjD5iZ7U'     // test
        androidPayMode: 'test', // Android only
      });
    } else {
      stripe.setOptions({
        publishableKey: 'pk_test_LLAdXVApiHYl2QUmtHy2HiHT', //'pk_test_INM9aFcqplBpLxivFa68HdMt00LjD5iZ7U'     // test
        androidPayMode: 'test', // Android only
      });
    }
  }

  stripePay() {
    const { expDate, cardNumber, cvv, CardName } = this.state;
    var str = expDate;
    var month = str.substring(0, 2);
    var year = str.substring(3, 5);
    //var last41 = this.state.cardNumber.slice(-4);
    const params = {
      number: cardNumber,
      expMonth: parseInt(month, 10),
      expYear: parseInt(year, 10),
      cvc: cvv,
      name: CardName,
    };
    stripe
      .createTokenWithCard(params)
      .then((token) => {
        const customerid = getConfiguration('user_id');
        this.props.posRequest(
          customerid,
          token.card.brand ? token.card.brand : 'Visa',
          token.tokenId,
          token.card.last4,
          this.props.navigation,
        );

        this.setState({ loader: false });
      })
      .catch((e) => {
        this.showAlert(e.message, 300);
      });
  }

  showAlert(message, duration) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      alert(message);
    }, duration);
  }

  goToNextScreen() {
    const { cardNumber, expDate, cvv, cardName } = this.state;
    if (
      cardNumber.trim().length > 14 &&
      expDate.trim().length > 4 &&
      cvv.trim().length > 2 &&
      cardName.trim().length > 0
    ) {
      this.setState({ loader: true });
      this.stripePay();
    } else {
      this.showAlert(strings.Pleaseentervaliddetailsofcard, 300);
    }
  }

  addGaps = (string = '', gaps) => {
    string = string.replace(/[^\d]/g, '');
    const offsets = [0].concat(gaps).concat([string.length]);
    return offsets
      .map((end, index) => {
        if (index === 0) return '';
        const start = offsets[index - 1];
        return string.substr(start, end - start);
      })
      .filter((part) => part !== '')
      .join('-');
  };

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.White }}>
        <RenderHeader
          back={true}
          title={strings.AddCard}
          navigation={this.props.navigation}
        />

        <View style={styles.gridViewBackground}>
          <View style={styles.tile}>
            <Text style={styles.cardTitle}>
              {strings.CardNumber.toUpperCase()}
            </Text>
            <TextInput
              style={styles.searchTextInput}
              autoCorrect={false}
              keyboardType="number-pad"
              returnKeyType="done"
              maxLength={19}
              onChangeText={(cardNumber) => {
                let num = this.addGaps(cardNumber, [4, 8, 12]);
                this.setState({
                  cardNumber: num,
                });
              }}
              value={this.state.cardNumber}
            />
          </View>

          <View style={styles.tile}>
            <Text style={styles.cardTitle}>
              {strings.cardHoldername.toUpperCase()}
            </Text>
            <TextInput
              style={styles.searchTextInput}
              autoCorrect={false}
              maxLength={30}
              onChangeText={(cardName) => this.setState({ cardName })}
              value={this.state.cardName}
            />
          </View>

          <View
            style={[
              styles.tile,
              { flexDirection: 'row', justifyContent: 'space-between' },
            ]}>
            <View
              style={{
                backgroundColor: 'transparent',
                width: '48%',
                height: '100%',
                justifyContent: 'center',
              }}>
              <Text style={styles.cardTitle}>
                {strings.ExpDate.toUpperCase()}
              </Text>
              <TextInput
                style={styles.searchTextInput}
                autoCorrect={false}
                keyboardType="number-pad"
                returnKeyType="done"
                maxLength={5}
                onChangeText={(expDate) => {
                  if (expDate.length == 2) {
                    expDate = expDate + '/';
                  } else if (expDate.length == 3) {
                    if (expDate.indexOf('/') !== -1) {
                      expDate = expDate.replace('/', '');
                    } else {
                      expDate = expDate.substr(0, 2) + '/' + expDate.substr(2);
                    }
                  }
                  this.setState({ expDate: expDate });
                }}
                value={this.state.expDate}
              />
            </View>

            <View
              style={{
                backgroundColor: 'transparent',
                width: '48%',
                height: '100%',
                justifyContent: 'center',
              }}>
              <Text style={styles.cardTitle}>{strings.CVV.toUpperCase()}</Text>

              <TextInput
                style={styles.searchTextInput}
                autoCorrect={false}
                keyboardType="number-pad"
                returnKeyType="done"
                maxLength={4}
                onChangeText={(cvv) => {
                  this.setState({ cvv: cvv });
                }}
                value={this.state.cvv}
              />
            </View>
          </View>

          {this.state.loader ? (
            <View style={[styles.buttonView]}>
              <ActivityIndicator
                size="large"
                color="#000000"
                style={{ paddingVertical: 12 }}
              />
            </View>
          ) : (
            <TouchableOpacity onPress={() => this.goToNextScreen()}>
              <View style={[styles.buttonView]}>
                <Text style={styles.logintext}>Add</Text>
              </View>
            </TouchableOpacity>
          )}
          {/* <LoginButtons
            text={strings.Add}
            style1={{ marginTop: '15%' }}
            onClick={() => this.goToNextScreen()}
          /> */}
        </View>
      </View>
    );
  }
}
