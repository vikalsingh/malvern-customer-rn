import AddCard from './AddCard';
import {connect} from 'react-redux';
import {posRequest} from './../../modules/AddPOS/actions';
const mapStateToProps = (state) => ({
  contactsData: state.getContactsReducer.contactsData,
});
const mapDispatchToProps = (dispatch) => ({
  posRequest: (customerId, name, token, lastd, navigation) =>
    dispatch(posRequest(customerId, name, token, lastd, navigation)),
});
export default connect(mapStateToProps, mapDispatchToProps)(AddCard);
