import {StyleSheet} from 'react-native';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';

const styles = StyleSheet.create({
  title: {
    fontSize: 20,
    color: 'white',
  },

  gridViewBackground: {
    flex: 1,
    marginTop: 20,
  },

  tileIcon: {
    width: 20,
    height: 40,
    marginLeft: 20,
    alignSelf: 'center',
  },
  tile: {
    alignSelf: 'center',
    backgroundColor: 'transparent',
    width: '90%',
    height: wp('13.5%'),
    marginTop: 40,
    marginHorizontal: 0,
  },
  searchTextInput: {
    marginTop: 5,
    width: '100%',
    height: '80%',
    paddingHorizontal: 20,
    backgroundColor: Colors.graylighted,
    borderColor: 'gray',
    borderRadius: 15,
    fontSize: wp('4.8%'),
    // alignContent: 'center'
    //  top: 4,
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
  },
  touchableArrow: {
    backgroundColor: 'transparent',
    position: 'absolute',
    right: 0,
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  arrowTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: wp('16%'),
    marginTop: 50,
    right: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0,
    borderColor: '#818e97',
  },
  bottomView: {position: 'absolute', bottom: 40, width: '100%'},
  cardTitle: {
    fontFamily: Fonts.Semibold,
  },
  buttonView: {
    marginTop: hp('3.5%'),
    height: wp('13%'),
    borderRadius: wp('12%'),
    width: '85%',
    backgroundColor: Colors.buttonsColor,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logintext: {
    color: 'white',
    fontSize: wp('4.5%'),
    fontFamily: Fonts.Semibold,
  },
});

export default styles;
