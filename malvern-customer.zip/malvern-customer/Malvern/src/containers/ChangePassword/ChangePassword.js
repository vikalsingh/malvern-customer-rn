import React from 'react';
import {View, Image, StyleSheet, Text, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import {resetPRequest} from './../../modules/ChangePassword/actions';
import {isEmpty} from '../../utils/CommonFunctions';
import {RenderHeaderBack} from './../../components/CustomComponent/renderHeader';
import strings from '../../constants/languagesString';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';
import {SignUpInputTextPassword} from '../../components/InputTexts/Inputext';
import styles from './style';
import Config from '../../constants/Config';

class ChangePassword extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      phone: this.props.route.params.mobileNumber,
      countryCode: this.props.route.params.countryCode,
      otp: this.props.route.params.otp,
      type: this.props.route.params.forgot,
      password: '',
      securePassword: true,
      passwordContainNum: false,
    };
  }

  verifyCredentials = () => {
    const {password, passwordContainNum} = this.state;
    if (isEmpty(password)) {
      alert(strings.passwordAlert);
      return false;
    } else if (password.length < 6) {
      alert(strings.passwordLength);
      return false;
    } else if (!passwordContainNum) {
      alert(strings.passwordNum);
      return false;
    }
    return true;
  };

  requestAPI = () => {
    const {navigation, resetRequest} = this.props;
    const {type, password, phone, otp, countryCode} = this.state;
    if (this.verifyCredentials()) {
      if (type) {
        console.log(type, password, phone, otp, countryCode);
        resetRequest(password, phone, otp, countryCode, navigation);
      } else {
        changeRequest(password, currentPassword, navigation);
      }
    }
  };

  onPasswordChange(password) {
    let passwordContainNum = this.validatePassword(password);
    this.setState({password, passwordContainNum});
  }

  validatePassword(password) {
    var passwordContainNum = true;
    if (!/\d/.test(password)) {
      passwordContainNum = false;
    }
    return passwordContainNum;
  }

  onGoBack = () => {
    const {phone, countryCode} = this.state;
    this.props.navigation.navigate(Config.Password, {
      mobileNumber: phone,
      countryCode: countryCode,
    });
  };

  render() {
    return (
      <View
        style={{
          flex: 1,
          marginTop: this.state.mainViewTop,
          backgroundColor: Colors.White,
        }}>
        <RenderHeaderBack
          title={strings.resetPassword}
          onBack={this.onGoBack}
        />

        <Text style={styles.resetpassText}>{strings.resetyourPassword}</Text>
        <Text style={styles.enternewpassText}>{strings.enternewpass}</Text>

        <View style={styles.lowerView}>
          <SignUpInputTextPassword
            icon={Images.passwordIcon}
            onChangeText={(password) => this.onPasswordChange(password)}
            text={this.state.password}
            showEye={this.state.securePassword}
            onClickEye={() =>
              this.setState({securePassword: !this.state.securePassword})
            }
          />

          <Text style={styles.passwordMustText}>{strings.passwordMust}</Text>

          <View style={styles.optionView}>
            <Image
              resizeMode="contain"
              style={styles.eyeIcon}
              source={
                this.state.password.length > 5
                  ? Images.check_Dark
                  : Images.check_Light
              }
            />
            <Text
              style={[
                styles.OptionMustText,
                {
                  color: this.state.password.length > 5 ? 'black' : 'gray',
                },
              ]}>
              {strings.atLeastchar}
            </Text>
          </View>

          <View style={styles.optionView}>
            <Image
              resizeMode="contain"
              style={styles.eyeIcon}
              source={
                this.state.passwordContainNum
                  ? Images.check_Dark
                  : Images.check_Light
              }
            />
            <Text
              style={[
                styles.OptionMustText,
                {
                  color: this.state.passwordContainNum ? 'black' : 'gray',
                },
              ]}>
              {strings.containNumber}
            </Text>
          </View>

          <View style={styles.bottomView}>
            <View style={styles.arrowTile}>
              <TouchableOpacity
                style={styles.touchableArrow}
                onPress={this.requestAPI}>
                <Image
                  resizeMode="contain"
                  style={styles.arrowIcon}
                  source={Images.rightImg}
                />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    );
  }
}
const mapStateToProps = (state) => ({
  resetData: state.changePReducer.data,
});
const mapDispatchToProps = (dispatch) => ({
  resetRequest: (password, phone, otp, countryCode, navigation) =>
    dispatch(resetPRequest(password, phone, otp, countryCode, navigation)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ChangePassword);
