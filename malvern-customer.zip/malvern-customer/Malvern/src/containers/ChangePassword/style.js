import {StyleSheet} from 'react-native';
import Fonts from '../../constants/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';

const styles = StyleSheet.create({
  lowerView: {
    flex: 1,
    marginTop: 0,
  },
  arrowTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: wp('16%'),
    marginTop: wp('8%'),
    marginBottom: 10,
    right: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0,
    borderColor: '#818e97',
  },
  touchableArrow: {
    backgroundColor: 'transparent',
    position: 'absolute',
    right: 0,
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
  },
  bottomView: {position: 'absolute', bottom: 40, width: '100%'},
  resetpassText: {
    alignSelf: 'center',
    fontFamily: Fonts.Semibold,
    fontSize: wp('5%'),
    marginTop: '20%',
    color: Colors.FontDarkColor,
  },
  enternewpassText: {
    alignSelf: 'center',
    fontFamily: Fonts.Thin,
    fontSize: wp('3.8%'),
    marginTop: wp('2%'),
    marginBottom: wp('2%'),
  },
  passwordMustText: {
    fontFamily: Fonts.Regular,
    fontSize: wp('4.5%'),
    marginTop: wp('4%'),
    marginBottom: wp('2%'),
    marginLeft: '7.5%',
  },
  eyeIcon: {
    width: 28,
    height: 28,
  },
  OptionMustText: {
    fontFamily: Fonts.Regular,
    fontSize: wp('4%'),
    marginLeft: '3%',
  },
  optionView: {
    alignSelf: 'center',
    flexDirection: 'row',
    marginTop: wp('4%'),
    height: 30,
    width: '85%',
    alignItems: 'center',
  },
});

export default styles;
