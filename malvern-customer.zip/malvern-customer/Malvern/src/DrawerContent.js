import React from 'react';
import { CommonActions } from '@react-navigation/native';
import { Text, View, StyleSheet, Alert, Image, ScrollView } from 'react-native';
import { setConfiguration } from './utils/configuration';
import { DrawerActions } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Images from './constants/Images';
import Colors from './constants/Colors';
import Config from './constants/Config';
import { connect } from 'react-redux';
import { logoutRequest } from './redux/reducers';
import { strings } from './constants/languagesString';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Fonts from './constants/Fonts';
import { DrawerContentItem } from './DrawerContentItem';
import messaging from '@react-native-firebase/messaging';

function DrawerContent(props) {
  const navigateToScreen = (route) => async () => {
    props.navigation.closeDrawer();
    props.navigation.dispatch(
      CommonActions.navigate({
        name: route,
      }),
    );
  };

  function navigateToHome() {
    props.navigation.navigate(Config.MapSearchScreen, {
      driverId: '',
      prefDriverRide: 'no',
      countryCode: props.loginData.countryCode,
    });
    props.navigation.dispatch(DrawerActions.closeDrawer());
  }

  function logout() {
    Alert.alert(
      strings.alert,
      strings.areyouSureLogout,
      [
        { text: strings.Ok, onPress: () => LogoutWork() },
        { text: strings.CancelTrip, onPress: () => console.log('OK Pressed') },
      ],
      { cancelable: false },
    );
  }

  const LogoutWork = async () => {
    setConfiguration('user_id', '');
    setConfiguration('fcmToken', '');
    setConfiguration('token', '');
    try {
      await AsyncStorage.setItem('user_id', '');
      await AsyncStorage.setItem('fcmToken', '');
      await AsyncStorage.setItem('token', '');
      await messaging()
        .deleteToken(undefined, '*')
        .catch((error) => {
          console.log('[FCMService] Delete token error ', error);
        });
    } catch (e) { }

    props.navigation.closeDrawer();
    props.navigation.reset({
      routes: [{ name: Config.Login }],
    });
  };

  var {
    name,
    email,
    profileImage,
    customerAvgRating,
    mobileNumber,
    countryCode,
  } = '';
  if (props.loginData != null && props.loginData != '') {
    name = props.loginData.name;
    email = props.loginData.email;
    profileImage = props.loginData.profileImage;
    customerAvgRating = props.loginData.customerAvgRating;
    mobileNumber = props.loginData.mobileNumber;
    countryCode = props.loginData.countryCode;
    if (countryCode != null && countryCode != '') {
      countryCode = props.loginData.countryCode + '-';
    } else {
      countryCode = '';
    }
  }
  return (
    <View style={styles.container}>
      <View style={styles.cardView}>
        <Image
          resizeMode="cover"
          style={styles.cardBgImg}
          source={Images.sideMenuBG}
        />

        <View style={styles.cardDetailscontainer}>
          <View style={{ marginTop: 10 }}>
            <View style={styles.profileImgView}>
              {profileImage == '' ||
                profileImage == 'null' ||
                profileImage == null ||
                profileImage == 'none' ? (
                <Image
                  resizeMode="cover"
                  style={{ width: '100%', height: '100%' }}
                  source={Images.drawerProfileBG}
                />
              ) : (
                <Image
                  resizeMode="cover"
                  style={{ width: '100%', height: '100%' }}
                  source={{
                    uri: profileImage,
                  }}
                />
              )}
            </View>
            <View style={{ marginTop: wp('1%') }}>
              <Text style={styles.nameText}>{name}</Text>
              <Text style={styles.emailText}>{email}</Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.screenContainer}>
        <ScrollView style={{ width: '100%', height: '100%' }}>
          <DrawerContentItem
            onNavigate={() => navigateToHome()}
            Icon={Images.homeIcon}
            title={strings.Rides}
          />

          <DrawerContentItem
            onNavigate={navigateToScreen(Config.MyTripScreen)}
            Icon={Images.yourTripIcon}
            title={strings.YourTrips}
          />

          <DrawerContentItem
            onNavigate={navigateToScreen(Config.CouponScreen)}
            Icon={Images.promotionIcon}
            title={strings.Promotions2}
          />

          <DrawerContentItem
            onNavigate={navigateToScreen(Config.AccountDetail)}
            Icon={Images.paymentMethodIcon}
            title={strings.PaymentMethod}
          />

          <DrawerContentItem
            onNavigate={navigateToScreen(Config.Emergency)}
            Icon={Images.emergencyIcon}
            title={strings.EmergencyContacts}
          />

          <DrawerContentItem
            onNavigate={navigateToScreen(Config.Disputes)}
            Icon={Images.DisputeIc}
            title={strings.Disputes}
          />

          <DrawerContentItem
            onNavigate={navigateToScreen(Config.ProfileScreen)}
            Icon={Images.DprofileIcon}
            title={strings.Profile}
          />
          {/* 
          <DrawerContentItem
            onNavigate={navigateToScreen(Config.Track)}
            Icon={Images.DprofileIcon}
            title={"Track"}
          /> */}

          {/* <DrawerContentItem
            onNavigate={navigateToScreen(Config.NewsLetterScreen)}
            Icon={Images.newsLetterIc}
            title={strings.NewsLetter}
          /> */}

          {/* <DrawerContentItem
            onNavigate={navigateToScreen(Config.WalletScreen)}
            Icon={Images.walletIc}
            title={strings.Wallet}
          /> */}

          <DrawerContentItem
            onNavigate={navigateToScreen(Config.Invite)}
            Icon={Images.shareIcon}
            title={strings.InviteFriend}
          />

          {/* <DrawerContentItem
            onNavigate={navigateToScreen(Config.PreferredScreen)}
            Icon={Images.preferedIcon}
            title={strings.PreferredDrivers}
          /> */}





          <DrawerContentItem
            onNavigate={navigateToScreen(Config.Support)}
            Icon={Images.supportIcon}
            title={strings.HelpSupport}
          />





          {/* <DrawerContentItem
            onNavigate={navigateToScreen(Config.TermsConditions)}
            Icon={Images.terms}
            title={strings.TermsConditions}
          /> */}

          {/* <DrawerContentItem
            onNavigate={navigateToScreen(Config.PrivacyPolicy)}
            Icon={Images.terms}
            title={strings.PrivacyPolcies}
          /> */}

          <DrawerContentItem
            onNavigate={navigateToScreen(Config.About)}
            Icon={Images.about_usIcon}
            title={strings.AboutUs}
          />

          <DrawerContentItem
            onNavigate={() => logout()}
            Icon={Images.logout}
            title={strings.logout}
          />



          <View style={{ height: 30 }} />
        </ScrollView>
      </View>
    </View>
  );
}

const mapStateToProps = (state) => ({
  loginData: state.loginReducer.loginData,
});
const mapDispatchToProps = (dispatch) => ({
  logoutRequest: () => dispatch(logoutRequest()),
});

export default connect(mapStateToProps, mapDispatchToProps)(DrawerContent);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  screenContainer: {
    paddingTop: 0,
    marginBottom: 180,
    backgroundColor: Colors.White,
  },
  cardView: {
    height: 180,
    width: '100%',
    backgroundColor: '#0082cb',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardBgImg: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
  },
  cardDetailscontainer: {
    height: 'auto',
    width: '100%',
    overflow: 'hidden',
    marginTop: 20,
    backgroundColor: 'transparent',
    flexDirection: 'row',
    marginLeft: 40,
  },
  profileImgView: {
    height: 70,
    overflow: 'hidden',
    width: 70,
    borderWidth: 1,
    borderRadius: 35,
    backgroundColor: 'transparent',
  },
  nameText: {
    color: '#ffffff',
    fontFamily: Fonts.Semibold,
  },
  emailText: {
    color: '#ffffff',
    fontFamily: Fonts.Regular,
  },
  starView: {
    width: '37%',
    height: '37%',
    right: 12,
  },
  starImg: {
    width: '50%',
    height: '50%',
    right: 10,
  },
  ratingView: {
    flexDirection: 'row',
    paddingBottom: 20,
  },
  ratingText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    width: 20,
  },
});
