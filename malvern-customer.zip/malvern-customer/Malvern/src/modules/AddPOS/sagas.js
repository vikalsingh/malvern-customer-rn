import {Alert} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {takeEvery, put} from 'redux-saga/effects';
import {ADDPOS_REQUEST} from './types';
import {posFail, posSuccess} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI, get} from '../../utils/api';
import {getConfiguration, setConfiguration} from '../../utils/configuration';
import {PaymentMethodListSuccess} from '../GetPaymentMethodList/actions';

function* onPOSRequested({customerId, name, token, lastd, navigation}) {
  yield* showLoader(false);
  try {
    let details = {
      customerId: customerId,
      type: 'Card',
      name: name,
      token: token,
      lastd: lastd,
      detials: 'Payment Details',
    };
    
    const posData = yield postAPI(Config.userPOS, JSON.stringify(details));
    console.log("posData", posData);
    if (posData.data.status === SUCCESS) {
      const paymentMethodData = yield get(Config.paymentMethodList);
      console.log("after add card list:", paymentMethodData);
      if (paymentMethodData.data.status === SUCCESS) {
        yield put(PaymentMethodListSuccess(paymentMethodData.data.data));
      }

      yield put(posSuccess());
      yield* hideLoader(false, '');

      setTimeout(() => {
        //navigation.navigate(Config.AccountDetailScreen);
        navigation.goBack();
      }, 600);
    } else if (posData.data.message == Config.authMessage) {
      yield put(estimateFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          {cancelable: false},
        );
      }, 600);
    } else {
      yield put(posFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(JSON.stringify(posData.data.message));
    }
  } catch (error) {
    console.log(JSON.stringify('ERRROR', error));
    yield* hideLoader(false, '');
    yield put(posFail());
    // yield showAlertWithDelay(JSON.stringify(error));
  }
}

function* sagaAddPOS() {
  yield takeEvery(ADDPOS_REQUEST, onPOSRequested);
}
export default sagaAddPOS;
