import {
  ADD_WALLET_BALANCE_REQUEST,
  ADD_WALLET_BALANCE_SUCCESS,
  ADD_WALLET_BALANCE_FAILURE,
  GET_WALLET_LIST_REQUEST,
  GET_WALLET_LIST_SUCCESS,
  GET_WALLET_LIST_FAILURE,
} from './types';

const INITIAL_STATE = {
  addWalletBalanceData: null,
  walletList: null,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case ADD_WALLET_BALANCE_REQUEST:
      return {
        ...state,
        isBusy: true,
      };
    case ADD_WALLET_BALANCE_SUCCESS:
      return {
        ...state,
        isBusy: false,
        addWalletBalanceData: action.data,
      };
    case ADD_WALLET_BALANCE_FAILURE:
      return {
        ...state,
        isBusy: false,
        addWalletBalanceData: null,
      };

    case GET_WALLET_LIST_REQUEST:
      return {
        ...state,
        isBusy: true,
      };
    case GET_WALLET_LIST_SUCCESS:
      return {
        ...state,
        isBusy: false,
        walletList: action.data,
      };
    case GET_WALLET_LIST_FAILURE:
      return {
        ...state,
        isBusy: false,
        walletList: null,
      };
    default:
      return state;
  }
};
