import {takeEvery, put, select} from 'redux-saga/effects';
import {ADD_WALLET_BALANCE_REQUEST, GET_WALLET_LIST_REQUEST} from './types';
import {
  addWalletBalanceFail,
  addWalletBalanceSuccess,
  getWalletListFail,
  getWalletListSuccess,
} from './actions';
import {profileSuccess} from '../GetProfile/actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI, get} from '../../utils/api';

function* onAddWalletBalanceRequested({details, navigation}) {
  yield* showLoader(false);
  try {
    const addWalletBalanceData = yield postAPI(
      Config.addMoney,
      JSON.stringify(details),
    );
    console.log(
      'Wallet Balance Data:   ' + JSON.stringify(addWalletBalanceData.data),
    );
    if (addWalletBalanceData.data.status === SUCCESS) {
      const profileData = yield get(Config.profile);
      if (profileData.data.status === SUCCESS) {
        yield put(profileSuccess(profileData.data.data));
      }
      yield put(addWalletBalanceSuccess(addWalletBalanceData.data.data));
      yield* hideLoader(false, '');
      yield showAlertWithDelay(
        JSON.stringify(addWalletBalanceData.data.message),
      );
    } else {
      yield* hideLoader(false, '');
      yield put(addWalletBalanceFail());
      yield showAlertWithDelay(
        JSON.stringify(addWalletBalanceData.data.message),
      );
    }
  } catch (error) {
    console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(addWalletBalanceFail());
    //yield showAlertWithDelay('Unable to get estimated cost');
  }
}

function* onGetWalletList({navigation}) {
  yield* showLoader(false);
  try {
    const selectorData = yield select();
    const {_id, token} = selectorData.loginReducer.loginData;
    let details = {
      userId: _id,
    };
    const response = yield postAPI(
      Config.walletHistoryURL,
      JSON.stringify(details),
    );
    // console.log('Wallet List:   ' + JSON.stringify(response));
    if (response.data.status === SUCCESS) {
      // const profileData = yield get(Config.profile);
      // if (profileData.data.status === SUCCESS) {
      //   yield put(profileSuccess(profileData.data.data));
      // }
      yield put(getWalletListSuccess(response.data.data));
      yield* hideLoader(false, '');
    } else {
      yield* hideLoader(false, '');
      yield put(getWalletListFail());
      //yield showAlertWithDelay(JSON.stringify(stimateData.data.message));
    }
  } catch (error) {
    console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(getWalletListFail());
    //yield showAlertWithDelay('Unable to get estimated cost');
  }
}

function* sagaAddWalletBalance() {
  yield takeEvery(ADD_WALLET_BALANCE_REQUEST, onAddWalletBalanceRequested);
  yield takeEvery(GET_WALLET_LIST_REQUEST, onGetWalletList);
}
export default sagaAddWalletBalance;
