import Axios from 'axios';
import { takeEvery, put } from 'redux-saga/effects';
import { REQUEST_RESET } from './types';
import { resetSuccess, resetFail } from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, { SUCCESS } from '../../constants/Config';

function* onResetRequested({ data }) {
  const url = Config.URL + Config.resendotp;
  yield* showLoader(false);
  try {
    console.log('-------------', data);
    const countryCode = data.countryCode;
    const mobileNumber = data.mobileNumber;
    const type = data.type;
    const config = {
      method: Config.kMethodPostKey,
      headers: Config.kHeaderValues,
      url,
      responseType: 'json',
      data: JSON.stringify({
        countryCode,
        mobileNumber,
      }),
    };
    console.log("param", config)
    const mobileData = yield Axios(config);
    if (mobileData.data.status === SUCCESS) {
      yield put(resetSuccess(mobileData.data));
      yield* hideLoader(false, '');
      if (type == 'resend') {
        yield showAlertWithDelay(mobileData.data.message);
      } else {
        yield showAlertWithDelay('OTP send succesfully!');
      }

    } else {
      yield* hideLoader(false, '');
      yield put(resetFail());
    }
  } catch (error) {
    console.log(JSON.stringify(error));

    yield* hideLoader(false, '');
    yield put(resetFail());
  }
}

function* sagaVerifyOtp() {
  yield takeEvery(REQUEST_RESET, onResetRequested);
}
export default sagaVerifyOtp;
