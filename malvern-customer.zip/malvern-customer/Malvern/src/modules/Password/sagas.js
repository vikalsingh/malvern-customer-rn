import AsyncStorage from '@react-native-async-storage/async-storage';
import {takeEvery, put, call} from 'redux-saga/effects';
import {LOGIN_REQUESTED} from './types';
import {loginFail, loginSuccess} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI, get} from '../../utils/api';
import {getConfiguration, setConfiguration} from '../../utils/configuration';
import {PaymentMethodListSuccess} from '../GetPaymentMethodList/actions';
import {AddressListRequest, AddressListSuccess} from '../AddAddress/actions';
import {profileSuccess} from '../GetProfile/actions';

function* onLoginRequested({
  countryCode,
  mobileNumber,
  password,
  fcmToken,
  navigation,
}) {
  yield* showLoader(false);
  try {
    let details = {
      //countryCode: countryCode,
      mobileNumber: mobileNumber,
      password: password,
      firebaseToken: fcmToken,
    };

    const loginData = yield postAPI(
      Config.loginMobile,
      JSON.stringify(details),
    );

    console.log('data:   ' + JSON.stringify(loginData.data));
    if (loginData.data.status === SUCCESS) {
      var token = loginData.data.data.token;
      yield setConfiguration('token', token);
      var user_id = loginData.data.data._id;
      yield setConfiguration('user_id', user_id);

      yield AsyncStorage.setItem('user_id', user_id);
      yield AsyncStorage.setItem('token', token);
      yield put(profileSuccess(loginData.data.data));
      const paymentMethodData = yield get(Config.paymentMethodList);
      if (paymentMethodData.data.status === SUCCESS) {
        yield put(PaymentMethodListSuccess(paymentMethodData.data.data));
      }
      const AddRessListData = yield get(Config.getAddreesURL);
      if (AddRessListData.data.status === SUCCESS) {
        yield put(AddressListSuccess(AddRessListData.data.data));
      }
      yield put(loginSuccess(loginData.data.data));
      yield* hideLoader(false, '');

      navigation.reset({
        routes: [{name: Config.SideMenu}],
      });
    } else {
      yield put(loginFail());
      yield* hideLoader(false, '');
      // eslint-disable-next-line no-undef
      yield showAlertWithDelay(loginData.data.message);
    }
  } catch (error) {
    // var aa = error;
    console.log(error);
    yield put(loginFail());
    yield* hideLoader(false, '');
    yield showAlertWithDelay('Invalid Mobile Number/Password');
  }
}

function* sagaLogin() {
  yield takeEvery(LOGIN_REQUESTED, onLoginRequested);
}
export default sagaLogin;
