import {
  PAYMENTLIST_SUCCESS,
  PAYMENTLIST_REQUEST,
  PAYMENTLIST_FAILURE,
  PAYPAL_REQUEST,
  PAYPAL_SUCCESS,
  PAYPAL_FAILURE,
} from './types';

const INITIAL_STATE = {
  paymentMethodData: null,
  paypalData: null,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case PAYMENTLIST_REQUEST:
      return {
        ...state,
      };
    case PAYMENTLIST_SUCCESS:
      return {
        ...state,
        paymentMethodData: action.data,
      };
    case PAYMENTLIST_FAILURE:
      return {
        ...state,
      };

    case PAYPAL_REQUEST:
      return {
        ...state,
      };
    case PAYPAL_SUCCESS:
      return {
        ...state,
        paypalData: action.data,
      };
    case PAYPAL_FAILURE:
      return {
        ...state,
      };
    default:
      return state;
  }
};
