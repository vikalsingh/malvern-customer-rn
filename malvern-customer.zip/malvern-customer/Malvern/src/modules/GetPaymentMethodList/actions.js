import {
  PAYMENTLIST_SUCCESS,
  PAYMENTLIST_REQUEST,
  PAYMENTLIST_FAILURE,
  PAYPAL_REQUEST,
  PAYPAL_SUCCESS,
  PAYPAL_FAILURE,
} from './types';

export const PaymentMethodListRequest = (navigation) => ({
  type: PAYMENTLIST_REQUEST,
  navigation,
});
export const PaymentMethodListSuccess = (data) => ({
  type: PAYMENTLIST_SUCCESS,
  data,
});
export const PaymentMethodListFail = () => ({
  type: PAYMENTLIST_FAILURE,
});

export const PaypalRequest = (data, navigation) => ({
  type: PAYPAL_REQUEST,
  data,
  navigation,
});
export const PaypalSuccess = (data) => ({
  type: PAYPAL_SUCCESS,
  data,
});
export const PaypalFail = () => ({
  type: PAYPAL_FAILURE,
});
