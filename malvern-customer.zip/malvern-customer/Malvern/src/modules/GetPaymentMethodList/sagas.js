import {takeEvery, put} from 'redux-saga/effects';
import {PAYMENTLIST_REQUEST, PAYPAL_REQUEST} from './types';

import {
  PaymentMethodListSuccess,
  PaymentMethodListFail,
  PaypalSuccess,
  PaypalFail,
} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {get, postAPI} from '../../utils/api';

function* onPaymentMethodListRequested({navigation}) {
  yield* showLoader(false);
  try {
    const paymentMethodData = yield get(Config.paymentMethodList);

    if (paymentMethodData.data.status === SUCCESS) {
      yield put(PaymentMethodListSuccess(paymentMethodData.data.data));
      yield* hideLoader(false, '');
    } else {
      yield put(PaymentMethodListFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(JSON.stringify(paymentMethodData.data.message));
    }
  } catch (error) {
    //console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(PaymentMethodListFail());
  }
}

function* onPaypalRequested({data, navigation}) {
  yield* showLoader(false);
  try {
    console.log(data);
    const response = yield postAPI(
      Config.paypalPaymentURL,
      JSON.stringify(data),
    );
    console.log('paypal cus');
    console.log(JSON.stringify(response.data));

    if (response.data.status === SUCCESS) {
      yield put(PaypalSuccess(response.data.data));
      yield* hideLoader(false, '');
    } else {
      yield put(PaypalFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(JSON.stringify(response.data.message));
    }
  } catch (error) {
    //console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(PaypalFail());
  }
}

function* sagaPaymentMethodList() {
  yield takeEvery(PAYMENTLIST_REQUEST, onPaymentMethodListRequested);
  yield takeEvery(PAYPAL_REQUEST, onPaypalRequested);
}
export default sagaPaymentMethodList;
