import {takeEvery, put} from 'redux-saga/effects';
import {MOBILE_REQUESTED, LOGIN_WITH_SOCIAL_REQUEST} from './types';
import {mobileFail, mobileSuccess, loginWithSocialSuccess} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI} from '../../utils/api';

function* onMobileRequest({
  countryCode,
  mobileNumber,
  countryName,
  navigation,
}) {
  yield* showLoader(false);
  try {
    let details = {
      countryCode: countryCode,
      mobileNumber: mobileNumber,
    };
    console.log('****************', details);
    const mobileData = yield postAPI(
      Config.verfiyMobile,
      JSON.stringify(details),
    );
    console.log('data:   ' + JSON.stringify(mobileData.data));
    console.log('****************');
    if (mobileData.data.exist === true) {
      yield put(mobileSuccess(mobileData.data));
      yield* hideLoader(false, '');
      navigation.navigate(Config.Password, {
        mobileNumber: mobileNumber,
        countryCode: countryCode,
      });
    } else {
      yield put(mobileFail());
      yield* hideLoader(false, '');
      navigation.navigate(Config.VerifyOTP, {
        otp: mobileData.data.data.OTP,
        mobileNumber,
        countryCode,
        countryName,
      });
    }
  } catch (error) {
    //console.log(JSON.stringify(error));
    yield put(mobileFail());
    yield* hideLoader(false, '');
  }
}

function* onloginWithSocialRequest({data, navigation}) {
  // yield* showLoader(false);
  try {
    const socialData = yield postAPI(
      Config.loginWithSocialURl,
      JSON.stringify(data),
    );
    if (socialData.data.status === SUCCESS) {
      yield put(loginWithSocialSuccess(socialData.data));
      // yield* hideLoader(false, '');
    } else {
      yield put(mobileFail());
      // yield* hideLoader(false, '');
    }
  } catch (error) {
    yield put(mobileFail());
    // yield* hideLoader(false, '');
  }
}

function* sagaMobile() {
  yield takeEvery(MOBILE_REQUESTED, onMobileRequest);
  yield takeEvery(LOGIN_WITH_SOCIAL_REQUEST, onloginWithSocialRequest);
}
export default sagaMobile;
