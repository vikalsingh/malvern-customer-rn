import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { takeEvery, put } from 'redux-saga/effects';
import {
  ADD_TRIP_REQUEST,
  CANCEL_TRIP_REQUEST,
  GET_TRIP_REQUEST,
  RATING_REQUEST,
  PANIC_REQUEST,
  PREFER_DRIVER_REQUEST,
  COUPON_REQUEST,
  RATING_CANCEL_REQUEST,
  CHANGE_ADDRESS_REQUEST,
  CHANGE_ADDRESS_SUCCESS,
} from './types';
import {
  addTripFail,
  addTripSuccess,
  cancelTripSuccess,
  getTripSuccess,
  ratingSuccess,
  panicSuccess,
  preferDriverSuccess,
  cancelRatingSuccess,
  couponSuccess,
  changeAddressSuccess,
} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import { myTripsSuccess, myTripsFail } from './../MyTrips/actions';

import Config, { SUCCESS } from '../../constants/Config';
import { postAPI, get } from '../../utils/api';
import { getConfiguration, setConfiguration } from '../../utils/configuration';

function* onAddTripRequested({ details, navigation }) {
  yield* showLoader(false);
  try {
    // console.log('details :--- ' + JSON.stringify(details));
    const addTripData = yield postAPI(
      Config.addTripURL,
      JSON.stringify(details),
    );
    console.log('Add Trip Data:   ', addTripData.data);
    if (addTripData.data.status === SUCCESS) {
      if (addTripData.data.data.tripStatus != 'Scheduled') {
        var tripId = addTripData.data.data.tripId;
        yield* onGetTripRequest({ tripId });
      }
      // yield* onGetTripRequest(addTripData.data.data.tripId);
      yield put(addTripSuccess(addTripData.data.data));
      yield* hideLoader(false, '');
    } else if (addTripData.data.message === Config.authMessage) {
      yield put(addTripFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          { cancelable: false },
        );
      }, 600);
    } else {
      yield* hideLoader(false, '');
      yield put(addTripFail());
      yield showAlertWithDelay(addTripData.data.message);
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield put(addTripFail());
    yield* hideLoader(false, '');
    //yield showAlertWithDelay('Unable to get estimated cost');
  }
}
function* onCancelTripRequest({ data, navigation }) {
  yield* showLoader(false);
  try {
    const responseData = yield postAPI(
      Config.cancelTripURL,
      JSON.stringify(data),
    );

    if (responseData.data.status === SUCCESS) {
      yield put(cancelTripSuccess(responseData.data));

      const resData = yield get(Config.allTripsURL);
      if (resData.data.status === SUCCESS) {
        yield put(myTripsSuccess(resData.data.data));
        yield* hideLoader(false, '');
      }
      yield showAlertWithDelay('Your trip cancel successfully!');
      yield* hideLoader(false, '');
    } else if (responseData.data.message === Config.authMessage) {
      yield put(addTripFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          { cancelable: false },
        );
      }, 600);
    } else {
      yield put(addTripFail());
      yield* hideLoader(false, '');
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield put(addTripFail());
    yield* hideLoader(false, '');
  }
}
function* onGetTripRequest({ tripId, navigation }) {
  const responseData = yield get(Config.getTripRequestURL + tripId);
  if (responseData.data.status === SUCCESS) {
    yield put(getTripSuccess(responseData.data.data));
  } else if (responseData.data.message === Config.authMessage) {
    yield put(addTripFail());
    yield* hideLoader(false, '');
    setTimeout(() => {
      Alert.alert(
        'Alert',
        Config.authErrorMessage,
        [
          {
            text: 'Ok',
            onPress: () => {
              setConfiguration('token', '');
              setConfiguration('user_id', '');
              setConfiguration('defaultPayment', '');
              AsyncStorage.setItem('user_id', '');
              AsyncStorage.setItem('token', '');
              navigation.navigate(Config.Login);
            },
          },
        ],
        { cancelable: false },
      );
    }, 600);
  }
}
function* onRatingRequest({ data, navigation }) {
  yield* showLoader(false);
  try {
    const responseData = yield postAPI(
      Config.ratingTripURL,
      JSON.stringify(data),
    );
    console.log(responseData);
    if (responseData.data.status === SUCCESS) {
      yield put(ratingSuccess(responseData.data));
      yield* hideLoader(false, '');
    } else if (responseData.data.message === Config.authMessage) {
      yield put(addTripFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          { cancelable: false },
        );
      }, 600);
    } else {
      yield put(addTripFail());
      yield* hideLoader(false, '');
    }
  } catch (error) {
    //console.log(JSON.stringify(error));
    yield put(addTripFail());
    yield* hideLoader(false, '');
  }
}
function* onPanicRequest({ data, navigation }) {
  yield* showLoader(false);
  try {
    const responseData = yield postAPI(Config.panicURL, JSON.stringify(data));
    //console.log('dasdad');
    if (responseData.data.status === SUCCESS) {
      yield put(panicSuccess(responseData.data));
      yield* hideLoader(false, '');
      yield showAlertWithDelay(responseData.data.message);
    } else if (responseData.data.message === Config.authMessage) {
      yield put(addTripFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          { cancelable: false },
        );
      }, 600);
    } else {
      yield put(addTripFail());

      yield* hideLoader(false, '');
      yield showAlertWithDelay(
        'No emergency contacts found. Please add Contacts!',
      );
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield put(addTripFail());
    yield* hideLoader(false, '');
  }
}
function* onPreferDriverRequest({ data, navigation }) {
  yield* showLoader(false);
  try {
    const responseData = yield postAPI(
      Config.preferDriverURL,
      JSON.stringify(data),
    );
    console.log('responseData');

    console.log(responseData.data);
    if (responseData.data.status === SUCCESS) {
      yield put(preferDriverSuccess(responseData.data));
      yield* hideLoader(false, '');
    } else if (responseData.data.message === Config.authMessage) {
      yield put(addTripFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          { cancelable: false },
        );
      }, 600);
    } else {
      yield put(addTripFail());
      yield* hideLoader(false, '');
    }
  } catch (error) {
    console.log(error);
    yield put(addTripFail());
    yield* hideLoader(false, '');
  }
}
function* onCouponRequest({ data, navigation }) {
  yield* showLoader(false);
  try {
    // console.log(JSON.stringify(data));
    const responseData = yield postAPI(
      Config.validatePromoCodeURl,
      JSON.stringify(data),
    );
    // console.log(JSON.stringify(responseData));
    if (responseData.data.status === SUCCESS) {
      yield put(couponSuccess(responseData.data));
      yield* hideLoader(false, '');
    } else if (responseData.data.message === Config.authMessage) {
      yield put(addTripFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          { cancelable: false },
        );
      }, 600);
    } else {
      yield put(couponSuccess(responseData.data));
      yield* hideLoader(false, '');
      // yield showAlertWithDelay(responseData.data.message);
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield put(addTripFail());
    yield* hideLoader(false, '');
  }
}

function* onRatingCancelRequest(navigation) {
  var data = null;
  // console.log('aasdassda');
  yield put(getTripSuccess(data));
  yield put(cancelRatingSuccess());
}

function* onChangeAddressRequest({ data, navigation }) {
  yield* showLoader(false);
  try {
    // console.log(JSON.stringify(data));
    const responseData = yield postAPI(
      Config.changeAddressURL,
      JSON.stringify(data),
    );
    console.log('onChangeAddressRequest');

    console.log(JSON.stringify(responseData.data));
    if (responseData.data.status === SUCCESS) {
      yield put(changeAddressSuccess(responseData.data));
      yield* hideLoader(false, '');
    } else if (responseData.data.message === Config.authMessage) {
      yield put(addTripFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          { cancelable: false },
        );
      }, 600);
    } else {
      yield put(changeAddressSuccess(responseData.data));
      yield* hideLoader(false, '');
      // yield showAlertWithDelay(responseData.data.message);
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield put(addTripFail());
    yield* hideLoader(false, '');
  }
}

function* sagaAddTrip() {
  yield takeEvery(ADD_TRIP_REQUEST, onAddTripRequested);
  yield takeEvery(CANCEL_TRIP_REQUEST, onCancelTripRequest);
  yield takeEvery(GET_TRIP_REQUEST, onGetTripRequest);
  yield takeEvery(RATING_REQUEST, onRatingRequest);
  yield takeEvery(PANIC_REQUEST, onPanicRequest);
  yield takeEvery(PREFER_DRIVER_REQUEST, onPreferDriverRequest);
  yield takeEvery(COUPON_REQUEST, onCouponRequest);
  yield takeEvery(RATING_CANCEL_REQUEST, onRatingCancelRequest);
  yield takeEvery(CHANGE_ADDRESS_REQUEST, onChangeAddressRequest);
}
export default sagaAddTrip;
