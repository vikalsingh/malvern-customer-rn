import { CHATHISTORY_SUCCESS, CHATHISTORY_REQUEST, CHATHISTORY_FAILURE } from './types';

export const chatHistoryRequest = (driverId, navigation) => ({
  type: CHATHISTORY_REQUEST,
  driverId,
  navigation,
});

export const chatHistorySuccess = data => ({
  type: CHATHISTORY_SUCCESS,
  data,
});
export const chatHistoryFail = () => ({
  type: CHATHISTORY_FAILURE,
});
