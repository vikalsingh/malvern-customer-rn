import {takeEvery, put} from 'redux-saga/effects';
import {CHATHISTORY_REQUEST} from './types';
import {chatHistorySuccess, chatHistoryFail} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI, get} from '../../utils/api';

function* onChatHistoryRequested({driverId, navigation}) {
  yield* showLoader(false);
  try {
    let details = {
      driverId: driverId,
    };
    const chatHistoryData = yield postAPI(
      Config.ChatHistory,
      JSON.stringify(details),
    );
    // console.log('data:   ' + JSON.stringify(chatHistoryData));
    // console.log('****************');
    if (chatHistoryData.data.status === SUCCESS) {
      yield put(chatHistorySuccess(chatHistoryData.data.data));
      yield* hideLoader(false, '');
    } else {
      yield* hideLoader(false, '');
      yield put(chatHistoryFail());
      // yield showAlertWithDelay(JSON.stringify(chatHistoryData.data.message));
    }
  } catch (error) {
    console.log(JSON.stringify(error));

    yield* hideLoader(false, '');
    yield put(chatHistoryFail());
  }
}

function* sagaConversation() {
  yield takeEvery(CHATHISTORY_REQUEST, onChatHistoryRequested);
}
export default sagaConversation;
