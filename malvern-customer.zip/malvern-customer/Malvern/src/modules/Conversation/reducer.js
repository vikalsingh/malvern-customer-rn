import { CHATHISTORY_SUCCESS, CHATHISTORY_REQUEST, CHATHISTORY_FAILURE } from './types';

const INITIAL_STATE = {
  chatHistoryData: null,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case CHATHISTORY_REQUEST:
      return {
        ...state,
      };
    case CHATHISTORY_SUCCESS:
      return {
        ...state,
        chatHistoryData: action.data,
      };
    case CHATHISTORY_FAILURE:
      return {
        ...state,
      };
    default:
      return state;
  }
};
