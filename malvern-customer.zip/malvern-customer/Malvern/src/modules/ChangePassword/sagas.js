import {takeEvery, put, select} from 'redux-saga/effects';
import {PASSRESET_REQUESTED, PASSCHANGE_REQUESTED} from './types';
import {apiFail, apiSuccess} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI} from '../../utils/api';

function* onResetRequested({password, phone, otp, countryCode, navigation}) {
  yield* showLoader(false);
  try {
    let details = {
      password,
      confirmPassword: password,
      mobileNumber: phone,
      OTP: otp,
      countryCode: countryCode,
    };
    const loginData = yield postAPI(
      Config.resetpassword,
      JSON.stringify(details),
    );

    if (loginData.data.status === SUCCESS) {
      yield* hideLoader(false, '');
      yield put(apiSuccess(loginData.data));
      yield showAlertWithDelay(JSON.stringify(loginData.data.message));
      setTimeout(() => {
        navigation.reset({
          routes: [
            {
              name: Config.Password,
              params: {mobileNumber: phone, countryCode: countryCode},
            },
          ],
        });
      }, 800);
    } else {
      yield* hideLoader(false, '');
      yield put(apiFail());
      yield showAlertWithDelay(JSON.stringify(loginData.data.message));
    }
  } catch (error) {
    console.log(JSON.stringify(error));

    yield* hideLoader(false, '');
    yield put(apiFail());
    yield showAlertWithDelay('Invalid Mobile Number/Password');
  }
}

function* onChangeRequested({password, currentPassword, navigation}) {
  yield* showLoader(false);
  try {
    let details = {
      password: password,
      confirmPassword: password,
      currentPassword: currentPassword,
    };
    const loginData = yield postAPI(
      Config.changepassword,
      JSON.stringify(details),
    );
    // console.log('data:   ' + JSON.stringify(loginData.data));
    if (loginData.data.status === SUCCESS) {
      yield* hideLoader(false, '');
      yield put(apiSuccess(loginData.data));

      setTimeout(() => {
        navigation.goBack();
      }, 800);
      yield showAlertWithDelay(JSON.stringify(loginData.data.message));
    } else {
      yield* hideLoader(false, '');
      yield put(apiFail());
      // eslint-disable-next-line no-undef
      yield showAlertWithDelay(JSON.stringify(loginData.data.message));
    }
  } catch (error) {
    console.log(JSON.stringify(error));

    yield* hideLoader(false, '');
    yield put(apiFail());
    yield showAlertWithDelay('Something went wrong!!');
  }
}

function* sagaChangeP() {
  yield takeEvery(PASSRESET_REQUESTED, onResetRequested);
  yield takeEvery(PASSCHANGE_REQUESTED, onChangeRequested);
}
export default sagaChangeP;
