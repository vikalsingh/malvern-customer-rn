import React from 'react';
import {
  StyleSheet,
  View,
  Image,
  Text,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Platform} from 'react-native';
import {connect} from 'react-redux';
import {resetPRequest, changeRequest} from './actions';
import {isEmpty} from '../../utils/CommonFunctions';

class ChangePassword extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentPassword: '',
      password: '',
      confirmPassword: '',
    };
  }

  goBack() {
    this.props.navigation.goBack();
  }

  verifyCredentials = () => {
    const {currentPassword, password, confirmPassword} = this.state;
    const {navigation} = this.props;
    if (!navigation.getParam('forgot') && isEmpty(currentPassword)) {
      alert('Please enter current password!!');
      return false;
    } else if (isEmpty(password)) {
      alert('Please enter password!!');
      return false;
    } else if (isEmpty(confirmPassword)) {
      alert('Please enter confirm password!!');
      return false;
    } else if (password !== confirmPassword) {
      alert('Password do not match!!');
      return false;
    }
    return true;
  };

  requestAPI = () => {
    const {navigation, resetRequest, changeRequest} = this.props;
    const {password, currentPassword} = this.state;
    if (this.verifyCredentials()) {
      if (navigation.getParam('forgot')) {
        resetRequest(password, navigation);
      } else {
        changeRequest(password, currentPassword, navigation);
      }
    }
  };

  render() {
    const {navigation} = this.props;

    return (
      <View
        style={{
          flex: 1,
          marginTop: this.state.mainViewTop,
          backgroundColor: '#f1f1f1',
        }}>
        <View
          style={{
            backgroundColor: 'transparent',
            width: wp('100%'),
            height: wp('100%'),
            marginTop: -wp('13.33%'),
            justifyContent: 'flex-end',
            alignItems: 'center',
          }}>
          <Image
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              width: '100%',
              height: '100%',
              backgroundColor: 'transparent',
            }}
            source={require('../../../assets/logoBG.png')}
          />
          <View
            style={{
              backgroundColor: 'transparent',
              width: wp('100%'),
              height: wp('40%'),
              marginBottom: wp('18.66%'),
            }}>
            <Image
              resizeMode="contain"
              style={{
                width: '100%',
                height: '100%',
                backgroundColor: 'transparent',
              }}
              source={require('../../../assets/logo.png')}
            />
          </View>
        </View>
        <View style={styles.headerView}>
          <TouchableOpacity
            style={styles.backTouchable}
            onPress={() => this.goBack()}>
            <Image
              resizeMode="contain"
              style={styles.backIcon}
              source={require('../../../assets/backwhite.png')}
            />
          </TouchableOpacity>
          <Text style={styles.title}>Change Password</Text>
        </View>
        <View style={styles.lowerView}>
          {!navigation.getParam('forgot') && (
            <View style={styles.tile}>
              <Image
                resizeMode="contain"
                style={styles.tileIcon}
                source={require('../../../assets/password.png')}
              />
              <TextInput
                style={styles.searchTextInput}
                placeholder="Current Password"
                placeholderTextColor={'#818e97'}
                autoCorrect={false}
                secureTextEntry={true}
                onChangeText={(password) =>
                  this.setState({currentPassword: password})
                }
                value={this.state.currentPassword}
              />
            </View>
          )}
          <View style={styles.tile}>
            <Image
              resizeMode="contain"
              style={styles.tileIcon}
              source={require('../../../assets/password.png')}
            />
            <TextInput
              style={styles.searchTextInput}
              placeholder="New Password"
              placeholderTextColor={'#818e97'}
              autoCorrect={false}
              secureTextEntry={true}
              onChangeText={(password) => this.setState({password})}
              value={this.state.password}
            />
          </View>

          <View style={styles.tile}>
            <Image
              resizeMode="contain"
              style={styles.tileIcon}
              source={require('../../../assets/password.png')}
            />
            <TextInput
              style={styles.searchTextInput}
              placeholder="Confirm Password"
              placeholderTextColor={'#818e97'}
              autoCorrect={false}
              secureTextEntry={true}
              onChangeText={(confirmPassword) =>
                this.setState({confirmPassword})
              }
              value={this.state.confirmPassword}
            />
          </View>
          <View style={styles.arrowTile}>
            <TouchableOpacity
              style={styles.touchableArrow}
              onPress={this.requestAPI}>
              <Image
                resizeMode="contain"
                style={styles.arrowIcon}
                source={require('../../../assets/next.png')}
              />
            </TouchableOpacity>
          </View>
        </View>
        {this.props.isBusy ||
        this.props.isBusySocial ||
        this.props.isBusyGetProfile ? (
          <Activity />
        ) : null}
      </View>
    );
  }
}
const mapStateToProps = (state) => ({
  resetData: state.changePReducer.data,
});

const mapDispatchToProps = (dispatch) => ({
  resetRequest: (password, navigation) =>
    dispatch(resetPRequest(password, navigation)),
  changeRequest: (password, currentPassword, navigation) =>
    dispatch(changeRequest(password, currentPassword, navigation)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ChangePassword);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'red',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },

  searchTextInput: {
    height: wp('10.33%'),
    marginTop: wp('2.5%'),
    paddingBottom: 5,
    paddingHorizontal: 15,
    backgroundColor: 'transparent',
    borderColor: 'gray',
    width: '100%',
    borderRadius: 0,
    fontSize: wp('5.33%'),
    fontFamily: 'CharlieDisplay-Regular',
  },
  tileIcon: {
    width: wp('8%'),
    height: wp('10.33%'),
    marginTop: wp('2.5%'),
    marginLeft: 10,
  },

  tile: {
    backgroundColor: 'white',
    width: 'auto',
    height: wp('16%'),
    marginTop: wp('8%'),
    marginHorizontal: wp('5.33%'),
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0.0,
    borderColor: '#818e97',
  },
  touchableForgotPassword: {
    backgroundColor: 'transparent',
    position: 'absolute',
    right: 0,
    height: 30,
  },
  forgot: {
    color: '#f05798',
    fontSize: 18,
    fontFamily: 'CharlieDisplay-Regular',
  },

  lowerView: {
    backgroundColor: '#f1f1f1',
    width: wp('100%'),
    height: 'auto',
    justifyContent: 'center',
    marginTop: 0,
  },
  headingBG: {
    marginTop: wp('8%'),
    width: '100%',
    height: 'auto',
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  tileIcon: {
    width: 18,
    height: 40,
    marginTop: -5,
    marginLeft: 0,
  },
  tile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: 40,
    marginTop: wp('8%'),
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 1.0,
    borderColor: '#818e97',
  },
  searchTextInput: {
    height: 40,
    width: '100%',
    paddingBottom: 5,
    paddingHorizontal: 20,
    backgroundColor: 'transparent',
    borderColor: 'gray',
    borderRadius: 0,
    fontSize: wp('4.8%'),
    fontFamily: 'CharlieDisplay-Regular',
  },
  forgotTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: 40,
    marginTop: 10,
    marginHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0,
    borderColor: '#818e97',
  },
  touchableForgotPassword: {
    backgroundColor: 'transparent',
    position: 'absolute',
    right: 0,
    height: 30,
  },
  arrowTile: {
    backgroundColor: 'transparent',
    width: 'auto',
    height: wp('16%'),
    marginTop: wp('8%'),
    marginBottom: 10,
    right: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 0,
    borderColor: '#818e97',
  },
  touchableArrow: {
    backgroundColor: '#f05798',
    position: 'absolute',
    right: 0,
    height: wp('16%'),
    width: wp('16%'),
    borderRadius: wp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  arrowIcon: {
    width: '100%',
    height: '100%',
  },
  title: {
    fontSize: wp('4.8%'),
    color: 'white',
    fontFamily: 'CharlieDisplay-Semibold',
  },
  backTouchable: {
    position: 'absolute',
    width: 60,
    height: 50,
    top: 0,
    left: 0,
  },
  headerView: {
    height: 40,
    width: '100%',
    backgroundColor: 'transparent',
    borderColor: '#0082cb',
    borderWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    left: 0,
    top: Platform.OS === 'ios' ? 30 : 0,
  },
  backIcon: {
    position: 'absolute',
    width: 22,
    height: 22,
    top: 10,
    left: 15,
    backgroundColor: 'transparent',
  },
});
