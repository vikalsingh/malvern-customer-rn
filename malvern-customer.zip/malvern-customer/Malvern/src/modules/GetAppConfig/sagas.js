import {takeEvery, put} from 'redux-saga/effects';
import {GETAPPCONFIG_REQUEST, LANGUAGE_REQUEST} from './types';
import {
  appConfigFail,
  appConfigSuccess,
  appLanguageFail,
  appLanguageSuccess,
} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {get} from '../../utils/api';

function* onAppConfigRequested({navigation}) {
  yield* showLoader(false);
  try {
    const AppConfigData = yield get(Config.configURL);
    console.log('onAppConfigRequested:   ' + JSON.stringify(AppConfigData));

    if (AppConfigData.data.status === SUCCESS) {
      console.log('Success');
      yield put(appConfigSuccess(AppConfigData.data.data));
      yield* hideLoader(false, '');
    } else {
      yield put(appConfigFail());
      yield* hideLoader(false, '');
    }
  } catch (error) {
    console.log('onAppConfigRequested error:   ' + error);

    yield* hideLoader(false, '');
    yield put(appConfigFail());
  }
}

function* onGetLanguageRequested() {
  console.log('did');
  yield* showLoader(false);
  try {
    const LanguageData = yield get(Config.languageURL);
    // console.log('onAppConfigRequested:   ' + JSON.stringify(LanguageData));

    if (LanguageData.data.status === SUCCESS) {
      console.log('Success');
      yield put(appLanguageSuccess(LanguageData.data.data));
      yield* hideLoader(false, '');
    } else {
      yield put(appLanguageFail());
      yield* hideLoader(false, '');
    }
  } catch (error) {
    console.log('onAppConfigRequested error:   ' + error);

    yield* hideLoader(false, '');
    yield put(appLanguageFail());
  }
}

function* sagaAppConfig() {
  yield takeEvery(GETAPPCONFIG_REQUEST, onAppConfigRequested);
  yield takeEvery(LANGUAGE_REQUEST, onGetLanguageRequested);
}
export default sagaAppConfig;
