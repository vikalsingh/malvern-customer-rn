import {
  GETAPPCONFIG_REQUEST,
  GETAPPCONFIG_SUCCESS,
  GETAPPCONFIG_FAILURE,
  LANGUAGE_REQUEST,
  LANGUAGE_SUCCESS,
  LANGUAGE_FAILURE,
} from './types';

const INITIAL_STATE = {
  AppConfigData: null,
  languageData: null,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case GETAPPCONFIG_REQUEST:
      return {
        ...state,
      };
    case GETAPPCONFIG_SUCCESS:
      return {
        ...state,
        AppConfigData: action.data,
      };
    case GETAPPCONFIG_FAILURE:
      return {
        ...state,
      };

    case LANGUAGE_REQUEST:
      return {
        ...state,
      };
    case LANGUAGE_SUCCESS:
      return {
        ...state,
        languageData: action.data,
      };
    case LANGUAGE_FAILURE:
      return {
        ...state,
      };
    default:
      return state;
  }
};

// import {
//   GETAPPCONFIG_REQUEST,
//   GETAPPCONFIG_SUCCESS,
//   GETAPPCONFIG_FAILURE,
//   LANGUAGE_REQUEST,
//   LANGUAGE_SUCCESS,
//   LANGUAGE_FAILURE,
// } from './types';

// const INITIAL_STATE = {
//   AppConfigData: null,
// };

// export default (state = INITIAL_STATE, action) => {
//   switch (action.type) {
//     case GETAPPCONFIG_REQUEST:
//       return {
//         ...state,
//       };
//     case GETAPPCONFIG_SUCCESS:
//       return {
//         ...state,
//         AppConfigData: action.data,
//       };
//     case GETAPPCONFIG_FAILURE:
//       return {
//         ...state,
//       };
//     default:
//       return state;
//   }
// };

// const INITIAL_STATE1 = {
//   languageData: null,
// };

// export default (state = INITIAL_STATE1, action) => {
//   switch (action.type) {
//     case LANGUAGE_REQUEST:
//       return {
//         ...state,
//       };
//     case LANGUAGE_SUCCESS:
//       return {
//         ...state,
//         languageData: action.data,
//       };
//     case LANGUAGE_FAILURE:
//       return {
//         ...state,
//       };
//     default:
//       return state;
//   }
// };
