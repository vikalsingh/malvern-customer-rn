import {
  GETAPPCONFIG_REQUEST,
  GETAPPCONFIG_SUCCESS,
  GETAPPCONFIG_FAILURE,
  LANGUAGE_REQUEST,
  LANGUAGE_SUCCESS,
  LANGUAGE_FAILURE,
} from './types';

export const appConfigRequest = (navigation) => ({
  type: GETAPPCONFIG_REQUEST,
  navigation,
});

export const appConfigSuccess = (data) => ({
  type: GETAPPCONFIG_SUCCESS,
  data,
});
export const appConfigFail = () => ({
  type: GETAPPCONFIG_FAILURE,
});

//============= Language ============//

export const appLanguageRequest = (navigation) => ({
  type: LANGUAGE_REQUEST,
  navigation,
});

export const appLanguageSuccess = (data) => ({
  type: LANGUAGE_SUCCESS,
  data,
});
export const appLanguageFail = () => ({
  type: LANGUAGE_FAILURE,
});
