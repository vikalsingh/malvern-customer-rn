import {Alert} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {takeEvery, put} from 'redux-saga/effects';
import {GETPROFILE_REQUEST} from './types';
import {profileSuccess, profileFail} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {get} from '../../utils/api';
import {loginSuccess} from '../Password/actions';
import {getConfiguration, setConfiguration} from '../../utils/configuration';

function* onProfileRequested({navigation}) {
  //const url = Config.URL + Config.profile;
  yield* showLoader(false);
  try {
    const profileData = yield get(Config.profile);
    // console.log(JSON.stringify(profileData.data));
    if (profileData.data.status === SUCCESS) {
      navigation.navigate(Config.SideMenu);
      yield put(loginSuccess(profileData.data.data));
      yield put(profileSuccess(profileData.data.data));
      yield* hideLoader(false, '');
    } else if (profileData.data.message == Config.authMessage2) {
      yield put(estimateFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          {cancelable: false},
        );
      }, 600);
    } else {
      var token = '';
      yield setConfiguration('token', token);
      var user_id = '';
      yield setConfiguration('user_id', user_id);
      yield AsyncStorage.setItem('user_id', user_id);
      yield AsyncStorage.setItem('token', token);
      yield put(profileFail());
      yield* hideLoader(false, '');
      // setTimeout(() => {
      //   navigation.reset({
      //     routes: [{name: Config.SideMenu}],
      //   });
      // }, 600);
    }
  } catch (error) {
    var token = '';
    yield setConfiguration('token', token);
    var user_id = '';
    yield setConfiguration('user_id', user_id);
    yield AsyncStorage.setItem('user_id', user_id);
    yield AsyncStorage.setItem('token', token);
    // console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    // setTimeout(() => {
    //   navigation.reset({
    //     routes: [{name: Config.Login}],
    //   });
    // }, 800);
    yield put(profileFail());
  }
}

function* sagaProfile() {
  yield takeEvery(GETPROFILE_REQUEST, onProfileRequested);
}
export default sagaProfile;
