import {
  ADDDISPUTE_REQUEST,
  ADDDISPUTE_SUCCESS,
  GET_DISPUTE_REQUEST,
  GET_DISPUTE_SUCCESS,
  UPDATE_DISPUTE_REQUEST,
  UPDATE_DISPUTE_SUCCESS,
  ADDDISPUTE_FAILURE,
} from './types';

export const addDisputeRequest = (data, navigation) => ({
  type: ADDDISPUTE_REQUEST,
  data,
  navigation,
});

export const addDisputeSuccess = (data) => ({
  type: ADDDISPUTE_SUCCESS,
  data,
});

export const getDisputeRequest = (data, navigation) => ({
  type: GET_DISPUTE_REQUEST,
  data,
  navigation,
});

export const getDisputeSuccess = (data) => ({
  type: GET_DISPUTE_SUCCESS,
  data,
});

export const updateDisputeRequest = (data, navigation) => ({
  type: UPDATE_DISPUTE_REQUEST,
  data,
  navigation,
});

export const updateDisputeSuccess = (data) => ({
  type: UPDATE_DISPUTE_SUCCESS,
  data,
});

export const addDisputeFail = () => ({
  type: ADDDISPUTE_FAILURE,
});
