import {Alert} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {takeEvery, put} from 'redux-saga/effects';
import {
  ADDDISPUTE_REQUEST,
  GET_DISPUTE_REQUEST,
  UPDATE_DISPUTE_REQUEST,
} from './types';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI, get} from '../../utils/api';
import {getConfiguration, setConfiguration} from '../../utils/configuration';
import {
  addDisputeSuccess,
  getDisputeSuccess,
  updateDisputeSuccess,
  addDisputeFail,
} from './actions';

function* onAddDispute({data, navigation}) {
  yield* showLoader(false);
  try {
    const response = yield postAPI(Config.addDisputeURL, JSON.stringify(data));

    if (response.data.status === SUCCESS) {
      yield put(addDisputeSuccess(response.data));
      yield* hideLoader(false, '');
    } else if (response.data.message == Config.authMessage) {
      yield put(addDisputeFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          {cancelable: false},
        );
      }, 600);
    } else {
      yield put(addDisputeFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(JSON.stringify(response.data.message));
    }
  } catch (error) {
    console.log(JSON.stringify('ERRROR', error));
    yield* hideLoader(false, '');
    yield put(addDisputeFail());
  }
}

function* onUpdateDispute({data, navigation}) {
  yield* showLoader(false);
  try {
    const response = yield postAPI(
      Config.updateDisputeURL,
      JSON.stringify(data),
    );
    console.log(response.data);

    if (response.data.status === SUCCESS) {
      const customerId = getConfiguration('user_id');
      let data1 = {customerId};
      const response1 = yield postAPI(
        Config.updateDisputeURL,
        JSON.stringify(data1),
      );
      if (response1.data.status === SUCCESS) {
        yield put(getDisputeSuccess(response1.data));
      }

      yield put(updateDisputeSuccess(response.data));

      yield* hideLoader(false, '');
    } else if (response.data.message == Config.authMessage) {
      yield put(addDisputeFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          {cancelable: false},
        );
      }, 600);
    } else {
      yield put(addDisputeFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(JSON.stringify(response.data.message));
    }
  } catch (error) {
    console.log(error);
    yield* hideLoader(false, '');
    yield put(addDisputeFail());
  }
}

function* onGetDispute({data, navigation}) {
  yield* showLoader(false);
  try {
    const response = yield postAPI(
      Config.getDisputeListURL,
      JSON.stringify(data),
    );
    if (response.data.status === SUCCESS) {
      yield put(getDisputeSuccess(response.data));
      yield* hideLoader(false, '');
    } else if (response.data.message == Config.authMessage) {
      yield put(addDisputeFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          {cancelable: false},
        );
      }, 600);
    } else {
      yield put(addDisputeFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(JSON.stringify(response.data.message));
    }
  } catch (error) {
    console.log(JSON.stringify('ERRROR', error));
    yield* hideLoader(false, '');
    yield put(addDisputeFail());
  }
}

function* sagaDispute() {
  yield takeEvery(ADDDISPUTE_REQUEST, onAddDispute);
  yield takeEvery(UPDATE_DISPUTE_REQUEST, onUpdateDispute);
  yield takeEvery(GET_DISPUTE_REQUEST, onGetDispute);
}
export default sagaDispute;
