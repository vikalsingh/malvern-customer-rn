import {
  ADDDISPUTE_REQUEST,
  ADDDISPUTE_SUCCESS,
  GET_DISPUTE_REQUEST,
  GET_DISPUTE_SUCCESS,
  UPDATE_DISPUTE_REQUEST,
  UPDATE_DISPUTE_SUCCESS,
  ADDDISPUTE_FAILURE,
} from './types';

const INITIAL_STATE = {
  AddDisputeData: null,
  GetDisputeData: null,
  updateDisputeData: null,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case ADDDISPUTE_REQUEST:
      return {
        ...state,
      };
    case ADDDISPUTE_SUCCESS:
      return {
        ...state,
        AddDisputeData: action.data,
      };

    case GET_DISPUTE_REQUEST:
      return {
        ...state,
      };
    case GET_DISPUTE_SUCCESS:
      return {
        ...state,
        GetDisputeData: action.data,
      };

    case UPDATE_DISPUTE_REQUEST:
      return {
        ...state,
      };
    case UPDATE_DISPUTE_SUCCESS:
      return {
        ...state,
        updateDisputeData: action.data,
      };

    case ADDDISPUTE_FAILURE:
      return {
        ...state,
      };
    default:
      return state;
  }
};
