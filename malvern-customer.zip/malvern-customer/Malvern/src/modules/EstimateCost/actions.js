import {
  ESTIMATE_COST_REQUEST,
  ESTIMATE_COST_SUCCESS,
  ESTIMATE_COST_FAILURE,
  NEARBY_DRIVER,
  NEARBY_DRIVER_SUCCESS,
  NEARBY_DRIVER_FAILURE
} from './types';

export const estimateRequest = (
  timezone,
  sourceLoc,
  stopsArray,
  destLoc,
  surgeData,
  navigation,
) => ({
  type: ESTIMATE_COST_REQUEST,
  timezone,
  sourceLoc,
  stopsArray,
  destLoc,
  surgeData,
  navigation,
});

export const estimateSuccess = (data) => ({
  type: ESTIMATE_COST_SUCCESS,
  data,
});
export const estimateFail = () => ({
  type: ESTIMATE_COST_FAILURE,
});

export const getNearBydriver = (navigation) => ({
  type: NEARBY_DRIVER,
  navigation,
});

export const getNearBydriverSuccess = data => ({
  type: NEARBY_DRIVER_SUCCESS,
  data,
});
export const getNearBydriverFail = () => ({
  type: NEARBY_DRIVER_FAILURE,
});