import AsyncStorage from '@react-native-async-storage/async-storage';
import { takeEvery, put } from 'redux-saga/effects';
import { ESTIMATE_COST_REQUEST, NEARBY_DRIVER } from './types';
import { estimateFail, estimateSuccess, getNearBydriverSuccess, getNearBydriverFail } from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, { SUCCESS, FAILURE } from '../../constants/Config';
import { getConfiguration, setConfiguration } from '../../utils/configuration';
import { postAPI, get } from '../../utils/api';

function* onEstimateRequested({ timezone, sourceLoc, stopsArray, destLoc, surgeData, navigation }) {
  yield* showLoader(false);
  try {
    let details = {
      timezone: timezone,
      source: sourceLoc,
      stopsArray: stopsArray,
      destination: destLoc,
      tripType: surgeData.tripType,
      date: surgeData.date,
      time: surgeData.time
    };

    console.log('est cost param:', details);

    const estimateData = yield postAPI(
      Config.estimatedCost,
      JSON.stringify(details),
    );
    console.log('est cost res:', estimateData);
    if (estimateData.data.status === SUCCESS) {
      yield put(estimateSuccess(estimateData.data.data));
      yield* hideLoader(false, '');
    } else if (estimateData.data.message == Config.authMessage) {
      yield put(estimateFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          { cancelable: false },
        );
      }, 600);
    } else {
      yield put(estimateFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(JSON.stringify(estimateData.data.message));
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(estimateFail());
    //yield showAlertWithDelay('Unable to get estimated cost');
  }
}

function* onNearByDriverRequested({ navigation }) {
  yield* showLoader(false);
  try {

    const responceData = yield postAPI(Config.onlineNearDriver);
    if (responceData.data.status === SUCCESS) {
      yield put(getNearBydriverSuccess(responceData.data.data));
      yield* hideLoader(false, '');
    }
    else {
      yield put(getNearBydriverFail());
      yield* hideLoader(false, '');
      // yield showAlertWithDelay(JSON.stringify(responceData.data.message));
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(getNearBydriverFail());
    //yield showAlertWithDelay('Unable to get estimated cost');
  }
}

function* sagaEstimateCost() {
  yield takeEvery(ESTIMATE_COST_REQUEST, onEstimateRequested);
  yield takeEvery(NEARBY_DRIVER, onNearByDriverRequested);
}
export default sagaEstimateCost;
