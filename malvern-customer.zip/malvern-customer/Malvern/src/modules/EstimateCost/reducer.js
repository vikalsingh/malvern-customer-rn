import {
  ESTIMATE_COST_REQUEST,
  ESTIMATE_COST_SUCCESS,
  ESTIMATE_COST_FAILURE,
  NEARBY_DRIVER,
  NEARBY_DRIVER_SUCCESS,
  NEARBY_DRIVER_FAILURE
} from './types';

const INITIAL_STATE = {
  estimateData: null,
  nearByDriverData: null
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case ESTIMATE_COST_REQUEST:
      return {
        ...state,
      };
    case ESTIMATE_COST_SUCCESS:
      return {
        ...state,
        estimateData: action.data,
      };
    case ESTIMATE_COST_FAILURE:
      return {
        ...state,
      };
    case NEARBY_DRIVER:
      return {
        ...state,
      };
    case NEARBY_DRIVER_SUCCESS:
      return {
        ...state,
        nearByDriverData: action.data,
      };
    case NEARBY_DRIVER_FAILURE:
      return {
        ...state,
      };
    default:
      return state;
  }
};
