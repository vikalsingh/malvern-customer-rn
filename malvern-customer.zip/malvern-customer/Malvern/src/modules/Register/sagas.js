import { takeEvery, put, call } from 'redux-saga/effects';
import { REGISTER } from './types';
import { registerFail, registerSuccess } from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, { SUCCESS } from '../../constants/Config';
import { loginSuccess } from '../Password/actions';
import { setConfiguration } from '../../utils/configuration';
import { postAPI, get } from '../../utils/api';
import { PaymentMethodListSuccess } from '../GetPaymentMethodList/actions';
import { profileSuccess } from '../GetProfile/actions';
import AsyncStorage from '@react-native-async-storage/async-storage';

function* onRegisterRequested({ data, navigation }) {
  yield* showLoader(false);
  try {
    const response = yield postAPI(Config.register, JSON.stringify(data))
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.log(error);
      });
    console.log('responce data:   ', response);
    if (response.status == SUCCESS) {
      var token = response.data.token;
      var user_id = response.data._id;
      yield setConfiguration('token', token);
      yield setConfiguration('user_id', user_id);
      yield AsyncStorage.setItem('user_id', user_id);
      yield AsyncStorage.setItem('token', token);
      yield put(loginSuccess(response.data));
      yield put(profileSuccess(response.data));
      const paymentMethodData = yield get(Config.paymentMethodList);
      console.log('responce paymentMethodData:   ', paymentMethodData);
      if (paymentMethodData.data.status === SUCCESS) {
        yield put(PaymentMethodListSuccess(paymentMethodData.data.data));
      }
      yield put(registerSuccess(response.data));
      yield* hideLoader(false, '');
      yield showAlertWithDelay(response.message);

      navigation.reset({
        routes: [{ name: Config.SideMenu }],
      });

    } else {
      yield* hideLoader(false, '');
      yield put(registerFail());
      yield showAlertWithDelay(response.message);
    }
  } catch (error) {
    console.log(error);
    yield* hideLoader(false, '');
    yield put(registerFail());
  }
}

function* sagaRegister() {
  yield takeEvery(REGISTER, onRegisterRequested);
}
export default sagaRegister;
