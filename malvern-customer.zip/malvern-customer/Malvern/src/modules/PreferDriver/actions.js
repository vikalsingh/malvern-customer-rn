import {PREFERRED_REQUEST, PREFERRED_SUCCESS, PREFERRED_FAIL} from './types';

export const preferredRequest = () => ({
  type: PREFERRED_REQUEST,
});

export const preferredSuccess = data => ({
  type: PREFERRED_SUCCESS,
  data,
});
export const preferredFail = () => ({
  type: PREFERRED_FAIL,
});
