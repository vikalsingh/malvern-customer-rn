import {takeEvery, put} from 'redux-saga/effects';
import {GETCONTACTS_REQUEST} from './types';
import {contactsFail, contactsSuccess} from './actions';
import Config, {SUCCESS} from '../../constants/Config';
import {get} from '../../utils/api';

function* onContactsRequested({navigation}) {
  try {
    const contactsData = yield get(Config.contactsURL);
    // console.log('BasicData: - ' + JSON.stringify(contactsData.data));

    if (contactsData.data.status === SUCCESS) {
      yield put(contactsSuccess(contactsData.data.data[0]));
    } else {
      yield put(contactsFail());
    }
  } catch (error) {
    console.log('contacts error:   ' + error);
    yield put(contactsFail());
  }
}

function* sagaContacts() {
  yield takeEvery(GETCONTACTS_REQUEST, onContactsRequested);
}
export default sagaContacts;
