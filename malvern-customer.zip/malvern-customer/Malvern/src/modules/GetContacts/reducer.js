import {
  GETCONTACTS_SUCCESS,
  GETCONTACTS_REQUEST,
  GETCONTACTS_FAILURE,
} from './types';

const INITIAL_STATE = {
  contactsData: null,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case GETCONTACTS_REQUEST:
      return {
        ...state,
      };
    case GETCONTACTS_SUCCESS:
      return {
        ...state,
        contactsData: action.data,
      };
    case GETCONTACTS_FAILURE:
      return {
        ...state,
      };
    default:
      return state;
  }
};
