import {
  GETCONTACTS_REQUEST,
  GETCONTACTS_SUCCESS,
  GETCONTACTS_FAILURE,
} from './types';
import {GETPROFILE_FAILURE} from '../GetProfile/types';

export const contactsRequest = navigation => ({
  type: GETCONTACTS_REQUEST,
  navigation,
});

export const contactsSuccess = data => ({
  type: GETCONTACTS_SUCCESS,
  data,
});
export const contactsFail = () => ({
  type: GETPROFILE_FAILURE,
});
