import {takeEvery, put} from 'redux-saga/effects';
import {PROMO_LIST_REQUEST} from './types';
import {promoListSuccess, promoFail} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI, get} from '../../utils/api';

function* onPromoListRequest() {
  yield* showLoader(false);
  try {
    const responseData = yield get(Config.allPromosURL);
    // console.log('data:   ' + JSON.stringify(responseData));
    if (responseData.data.status === SUCCESS) {
      yield put(promoListSuccess(responseData.data.data));
      yield* hideLoader(false, '');
    } else {
      yield* hideLoader(false, '');
      yield put(promoFail());
      yield showAlertWithDelay(responseData.data.message);
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(promoFail());
    //yield showAlertWithDelay('Invalid  details');
  }
}

function* sagaPromoCodes() {
  yield takeEvery(PROMO_LIST_REQUEST, onPromoListRequest);
}
export default sagaPromoCodes;
