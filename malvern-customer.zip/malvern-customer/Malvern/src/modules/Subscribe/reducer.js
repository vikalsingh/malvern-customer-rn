import {
  SUBSCRIBE_SUCCESS,
  SUBSCRIBE_REQUEST,
  SUBSCRIBE_FAIL,
  UPLOADVIDEO_REQUEST,
  UPLOADVIDEO_SUCCESS,
} from './types';

const INITIAL_STATE = {
  subscribeData: null,
  uploadVideoData: null,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case SUBSCRIBE_REQUEST:
      return {
        ...state,
      };
    case SUBSCRIBE_SUCCESS:
      return {
        ...state,
        subscribeData: action.data,
      };

    case UPLOADVIDEO_REQUEST:
      return {
        ...state,
      };
    case UPLOADVIDEO_SUCCESS:
      return {
        ...state,
        uploadVideoData: action.data,
      };
    case SUBSCRIBE_FAIL:
      return {
        ...state,
      };
    default:
      return state;
  }
};
