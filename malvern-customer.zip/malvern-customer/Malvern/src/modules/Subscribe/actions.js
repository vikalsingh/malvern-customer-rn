import {
  SUBSCRIBE_SUCCESS,
  SUBSCRIBE_REQUEST,
  SUBSCRIBE_FAIL,
  UPLOADVIDEO_REQUEST,
  UPLOADVIDEO_SUCCESS,
} from './types';

export const subscribeRequest = (data, navigation) => ({
  type: SUBSCRIBE_REQUEST,
  data,
  navigation,
});

export const subscribeSuccess = (data) => ({
  type: SUBSCRIBE_SUCCESS,
  data,
});

export const uploadvideoRequest = (videoData, navigation) => ({
  type: UPLOADVIDEO_REQUEST,
  videoData,
  navigation,
});

export const uploadvideoSuccess = (data) => ({
  type: UPLOADVIDEO_SUCCESS,
  data,
});

export const subscribeFail = () => ({
  type: SUBSCRIBE_FAIL,
});
