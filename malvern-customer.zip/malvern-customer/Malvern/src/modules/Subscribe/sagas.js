import Axios from 'axios';

import {takeEvery, put, select} from 'redux-saga/effects';
import {SUBSCRIBE_REQUEST, UPLOADVIDEO_REQUEST} from './types';
import {subscribeSuccess, subscribeFail} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS} from '../../constants/Config';
import {postAPI} from '../../utils/api';

function* onsubscribeRequested({data, navigation}) {
  yield* showLoader(false);
  try {
    console.log('params ', data);
    const mobileData = yield postAPI(
      Config.addSubscribeURL,
      JSON.stringify(data),
    );
    console.log('data:   ', JSON.stringify(mobileData.data));
    if (mobileData.data.status === SUCCESS) {
      yield put(subscribeSuccess(mobileData.data));
      yield* hideLoader(false, '');
      // yield showAlertWithDelay(mobileData.data.message);
    } else if (mobileData.data.message == Config.authMessage) {
      yield put(subscribeFail());
      yield* hideLoader(false, '');
      setTimeout(() => {
        Alert.alert(
          'Alert',
          Config.authErrorMessage,
          [
            {
              text: 'Ok',
              onPress: () => {
                setConfiguration('token', '');
                setConfiguration('user_id', '');
                setConfiguration('defaultPayment', '');
                AsyncStorage.setItem('user_id', '');
                AsyncStorage.setItem('token', '');
                navigation.navigate(Config.Login);
              },
            },
          ],
          {cancelable: false},
        );
      }, 600);
    } else {
      yield* hideLoader(false, '');
      yield put(subscribeFail());
    }
  } catch (error) {
    console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(subscribeFail());
  }
}

function* onUploadVideo({videoData}) {
  const selectorData = yield select();
  var url = Config.URL + 'api/v1/trip/recording/video';

  yield* showLoader(false);
  try {
    console.log(JSON.stringify(videoData));
    const {_id, token} = selectorData.loginReducer.loginData;
    const config = {
      method: Config.apiTypePost,
      headers: {
        customerId: _id,
        token: token,
      },
      url,
      responseType: 'json',
      data: videoData,
    };
    console.log(JSON.stringify(config));

    const response = yield Axios(config);

    console.log('data:   ' + JSON.stringify(response));
    if (response.data.status === SUCCESS) {
      alert('Sent successfully.');
      // yield put(loginSuccess(response.data.data));
      // yield showAlertWithDelay(response.data.message);
      // yield put(profileImSuccess(response.data));
      yield* hideLoader(false, '');
    } else {
      // alert('not');
      // yield put(apiEPFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(response.data.message);
    }
  } catch (error) {
    alert('error');
    console.log(JSON.stringify(error));

    yield* hideLoader(false, '');
    // yield put(apiEPFail());
  }
}

function* sagaSubscribe() {
  yield takeEvery(SUBSCRIBE_REQUEST, onsubscribeRequested);
  yield takeEvery(UPLOADVIDEO_REQUEST, onUploadVideo);
}
export default sagaSubscribe;
