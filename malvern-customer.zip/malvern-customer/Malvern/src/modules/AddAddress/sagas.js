import {takeEvery, put} from 'redux-saga/effects';
import {
  ADD_ADDRESS_REQUEST,
  ADDRESSLIST_REQUEST,
  REMOVE_ADDRESS_REQUEST,
  EDIT_ADDRESS_REQUEST
} from './types';
import {
  addAddressFail,
  addAddressSuccess,
  AddressListSuccess,
  removeAddressSuccess,
  editAddrSuccess,
  editAddrFail
} from './actions';
import {
  showLoader,
  hideLoader,
  showAlertWithDelay,
} from '../../utils/CommonFunctions';
import Config, {SUCCESS, FAILURE} from '../../constants/Config';
import {postAPI, get} from '../../utils/api';

function* onddAddressRequested({name, address, navigation}) {
  yield* showLoader(false);
  try {
    let details = {
      name: name,
      address: address,
    };
    console.log('details', details);
    const AddressData = yield postAPI(
      Config.addAddress,
      JSON.stringify(details),
    );
    console.log('Parameters Add Address:', AddressData);

    if (AddressData.data.status === SUCCESS) {
      yield put(addAddressSuccess(AddressData.data.data));
      yield* onGetAddressListRequest();
      yield* hideLoader(false, '');
    } else {
      yield put(addAddressFail());
      yield* hideLoader(false, '');
      yield showAlertWithDelay(AddressData.data.message);
    }
  } catch (error) {
    console.log(JSON.stringify(error));
    yield* hideLoader(false, '');
    yield put(addAddressFail());
  }
}

function* onRemoveAddressRequest({addressId}) {
  yield* showLoader(false);
  try {
    let details = {
      addressId: addressId,
    };
    const responseData = yield postAPI(
      Config.removeAddressURL,
      JSON.stringify(details),
    );
    if (responseData.data.status === SUCCESS) {
      yield put(removeAddressSuccess(responseData.data));
      yield* onGetAddressListRequest();
      yield* hideLoader(false, '');
    } else {
      yield put(addAddressFail());
      yield* hideLoader(false, '');
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield put(addAddressFail());
    yield* hideLoader(false, '');
  }
}

function* onGetAddressListRequest() {
  const responseData = yield get(Config.getAddreesURL);
  if (responseData.data.status === SUCCESS) {
    yield put(AddressListSuccess(responseData.data.data));
  }
}


function* onEditAddressRequest({data, navigation}) {
  yield* showLoader(false);
  try {
    
    const responseData = yield postAPI(
      Config.updateaddressURL,
      JSON.stringify(data),
    );
    if (responseData.data.status === SUCCESS) {
      yield put(editAddrSuccess(responseData.data));
      yield* onGetAddressListRequest();
      yield* hideLoader(false, '');
    } else {
      yield put(editAddrFail());
      yield* hideLoader(false, '');
    }
  } catch (error) {
    // console.log(JSON.stringify(error));
    yield put(editAddrFail());
    yield* hideLoader(false, '');
  }
}

function* sagaAddAddress() {
  yield takeEvery(ADD_ADDRESS_REQUEST, onddAddressRequested);
  yield takeEvery(ADDRESSLIST_REQUEST, onGetAddressListRequest);
  yield takeEvery(REMOVE_ADDRESS_REQUEST, onRemoveAddressRequest);
  yield takeEvery(EDIT_ADDRESS_REQUEST, onEditAddressRequest);
}
export default sagaAddAddress;
