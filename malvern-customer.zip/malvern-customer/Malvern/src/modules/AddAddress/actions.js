import {
  ADD_ADDRESS_REQUEST,
  ADD_ADDRESS_SUCCESS,
  ADD_ADDRESS_FAILURE,
  ADDRESSLIST_REQUEST,
  ADDRESSLIST_SUCCESS,
  REMOVE_ADDRESS_REQUEST,
  REMOVE_ADDRESS_SUCCESS,
  EDIT_ADDRESS_REQUEST,
  EDIT_ADDRESS_SUCCESS,
  EDIT_ADDRESS_FAIL
} from './types';

export const addAddressRequest = (name, address, navigation) => ({
  type: ADD_ADDRESS_REQUEST,
  name,
  address,
  navigation,
});
export const addAddressSuccess = data => ({
  type: ADD_ADDRESS_SUCCESS,
  data,
});
export const addAddressFail = () => ({
  type: ADD_ADDRESS_FAILURE,
});


export const editAddrRequest = (data, navigation) => ({
  type: EDIT_ADDRESS_REQUEST,
  data,
  navigation,
});
export const editAddrSuccess = data => ({
  type: EDIT_ADDRESS_SUCCESS,
  data,
});
export const editAddrFail = () => ({
  type: EDIT_ADDRESS_FAIL,
});


export const removeAddressRequest = (addressId, navigation) => ({
  type: REMOVE_ADDRESS_REQUEST,
  addressId,
  navigation,
});
export const removeAddressSuccess = data => ({
  type: REMOVE_ADDRESS_SUCCESS,
  data,
});


export const AddressListRequest = (navigation) => ({
  type: ADDRESSLIST_REQUEST,
  navigation,
});
export const AddressListSuccess = data => ({
  type: ADDRESSLIST_SUCCESS,
  data,
});


