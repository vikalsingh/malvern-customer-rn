import {
  ADD_ADDRESS_REQUEST,
  ADD_ADDRESS_SUCCESS,
  ADD_ADDRESS_FAILURE,
  ADDRESSLIST_SUCCESS,
  ADDRESSLIST_REQUEST,
  REMOVE_ADDRESS_SUCCESS,
  REMOVE_ADDRESS_REQUEST,
  EDIT_ADDRESS_REQUEST,
  EDIT_ADDRESS_SUCCESS,
  EDIT_ADDRESS_FAIL
} from './types';

const INITIAL_STATE = {
  AddressData: null,
  GetAddressList: null,
  removeAddressData: null,
  updateSaveAddr: null
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case ADD_ADDRESS_REQUEST:
      return {
        ...state,
      };
    case ADDRESSLIST_REQUEST:
      return {
        ...state,
      };
    case REMOVE_ADDRESS_REQUEST:
      return {
        ...state,
      };
    case ADD_ADDRESS_SUCCESS:
      return {
        ...state,
        AddressData: action.data,
      };
    case REMOVE_ADDRESS_SUCCESS:
      return {
        ...state,
        removeAddressData: action.data,
      };
    case ADDRESSLIST_SUCCESS:
      return {
        ...state,
        GetAddressList: action.data,
      };
    case ADD_ADDRESS_FAILURE:
      return {
        ...state,
      };


    case EDIT_ADDRESS_REQUEST:
      return {
        ...state,
      };
    case EDIT_ADDRESS_SUCCESS:
      return {
        ...state,
        updateSaveAddr: action.data,
      };
    case EDIT_ADDRESS_FAIL:
      return {
        ...state,
      };
    default:
      return state;
  }
};
