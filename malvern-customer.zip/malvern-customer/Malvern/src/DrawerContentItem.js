import React from 'react';
import {TouchableOpacity, Image, Text, StyleSheet} from 'react-native';
import Colors from './constants/Colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Fonts from './constants/Fonts';

function DrawerContentItem({onNavigate, Icon, title}) {
  return (
    <TouchableOpacity style={styles.tile} onPress={() => onNavigate()}>
      <Image resizeMode="contain" style={styles.tileIcon} source={Icon} />
      <Text style={styles.tileTitle}> {title.toUpperCase()} </Text>
    </TouchableOpacity>
  );
}

export {DrawerContentItem};

const styles = StyleSheet.create({
  tile: {
    height: 40,
    width: '100%',
    marginTop: 8,
    alignItems: 'center',
    backgroundColor: 'transparent',
    flexDirection: 'row',
  },
  tileIcon: {
    width: 20,
    height: 20,
    marginLeft: 20,
  },
  tileTitle: {
    fontSize: wp('4%'),
    color: Colors.FontDarkColor,
    fontFamily: Fonts.Semibold,
    marginLeft: wp('4%'),
  },
});
