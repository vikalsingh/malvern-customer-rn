import React from 'react';
import {
  Image,
  View,
  Modal,
  ImageBackground,
  TouchableOpacity,
  Text,
  TextInput,
  StyleSheet,
  TouchableHighlight,
} from 'react-native';
import {getStatusBarHeight} from '../../utils/IPhoneXHelper';
import VectorIcon from '../../utils/vectorIcons';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Fonts from '../../constants/Fonts';
import strings from '../../constants/languagesString';
import Config from '../../constants/Config';

const googleAutocomplete = async (Location, curLat, curLong) => {
  const apiUrl =
    'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=' +
    Location +
    '&key=' +
    Config.GOOGLE_MAPS_APIKEY +
    '&location=' +
    curLat +
    ',' +
    curLong +
    '&radius=' +
    1000;
  const result = await fetch(apiUrl);
  const json = await result.json();
  return json;
};

function EnterAddressPopup({
  isOpen,
  onClose,
  sourceLocation,
  onChangeSource,
  showSuggestion,
  predictions,
  setSourceLocation,
}) {
  let predictions2;
  if (showSuggestion && predictions.length !== 0) {
    predictions2 = predictions.map((prediction, index) => (
      <TouchableOpacity
        style={styles.ItemTouchHighStyle}
        onPress={() =>
          setSourceLocation(prediction.place_id, prediction.description)
        }>
        <Text style={{margin: 10}} key={index}>
          {prediction.description}
        </Text>
      </TouchableOpacity>
    ));
  }

  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={isOpen}
      onRequestClose={() => onClose()}>
      <ImageBackground style={styles.HeaderView} resizeMode="cover">
        <TouchableOpacity
          style={styles.TouchBackButton}
          onPress={() => onClose()}>
          <VectorIcon
            style={{alignSelf: 'center'}}
            name={'left'}
            groupName={'AntDesign'}
            size={20}
            color={'black'}
          />
        </TouchableOpacity>
        <Text style={styles.HeaderText}>{strings.enterAddress}</Text>
        <View style={{marginRight: 15, width: 30, height: 30}} />
      </ImageBackground>
      <View>
        <View style={styles.tile}>
          <Image
            resizeMode="contain"
            style={styles.tileIcon}
            source={Images.WhiteAddress}
          />
          <TextInput
            placeholder={strings.Address}
            placeholderTextColor="grey"
            onChangeText={(sourceLocation) => onChangeSource(sourceLocation)}
            value={sourceLocation}
            style={styles.searchTextInput}
          />
        </View>

        {showSuggestion ? (
          <View style={styles.predictionItemView}>{predictions2}</View>
        ) : null}
      </View>
    </Modal>
  );
}

function CameraOptionsPopup({isOpen, onClose, openCamera, openGallery}) {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isOpen}
      onRequestClose={() => onClose()}>
      <TouchableOpacity
        style={{width: '100%', height: '100%'}}
        onPress={() => onClose()}>
        <View style={styles.backgroundblacktint} />
        <View style={styles.viewForOptions}>
          <TouchableHighlight>
            <View style={styles.viewforChoosePhoto}>
              <Text style={styles.selectPhototxt}>{strings.selectPhoto}</Text>
              <View style={styles.sepratorLine} />
              <TouchableHighlight onPress={() => openCamera()}>
                <Text style={styles.takephotoTxt}>{strings.takephoto}...</Text>
              </TouchableHighlight>

              <View style={styles.sepratorLine} />
              <TouchableHighlight onPress={() => openGallery()}>
                <Text style={styles.takephotoTxt}>{strings.chooselib}...</Text>
              </TouchableHighlight>
            </View>
          </TouchableHighlight>

          <View style={styles.viewForcancel}>
            <TouchableHighlight onPress={() => onClose()}>
              <Text style={styles.takephotoTxt}>{strings.Cancel}</Text>
            </TouchableHighlight>
          </View>
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

export {googleAutocomplete, EnterAddressPopup, CameraOptionsPopup};

const styles = StyleSheet.create({
  HeaderView: {
    height: Platform.select({
      ios: 40 + getStatusBarHeight(),
      android: 50,
      backgroundColor: 'white',
    }),
    width: '100%',
    borderColor: '#0082cb',
    borderWidth: 0,
    backgroundColor: Colors.White,
    alignItems: 'center',
    paddingTop: Platform.select({
      ios: getStatusBarHeight(),
      android: 0,
    }),
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  TouchBackButton: {
    marginLeft: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
    backgroundColor: 'white',
    borderRadius: 30,
  },
  HeaderText: {
    fontSize: wp('5.33%'),
    fontFamily: Fonts.Semibold,
    textAlign: 'center',
    color: Colors.FontDarkColor,
  },
  searchTextInput: {
    width: '86%',
    backgroundColor: 'transparent',
    borderColor: 'gray',
    borderRadius: 0,
    fontSize: wp('4.8%'),
    fontFamily: Fonts.Regular,
    marginLeft: 25,
  },
  predictionItemView: {
    height: wp('55%'),
    width: wp('100%'),
    backgroundColor: 'white',
  },
  tileIcon: {
    width: 20,
    height: 45,
    marginLeft: 0,
  },
  tile: {
    backgroundColor: 'transparent',
    width: '75%',
    marginTop: wp('5.33%'),
    alignItems: 'center',
    flexDirection: 'row',
    borderBottomWidth: 1.0,
    borderColor: Colors.bottomBorder,
    alignSelf: 'center',
  },
  ItemTouchHighStyle: {
    paddingVertical: 5,
    borderBottomWidth: 1.0,
    borderColor: 'gray',
    backgroundColor: 'white',
    height: 'auto',
  },

  backgroundblacktint: {
    width: '100%',
    height: '100%',
    backgroundColor: 'black',
    opacity: 0.3,
    position: 'absolute',
    justifyContent: 'flex-end',
  },
  viewForOptions: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    justifyContent: 'flex-end',
  },
  viewforChoosePhoto: {
    backgroundColor: 'white',
    width: '96%',
    alignSelf: 'center',
    borderRadius: 8,
  },
  selectPhototxt: {
    alignSelf: 'center',
    color: 'gray',
    marginTop: 10,
    marginBottom: 10,
    fontFamily: Fonts.Regular,
  },
  sepratorLine: {
    height: 1,
    backgroundColor: 'gray',
    opacity: 0.4,
  },
  takephotoTxt: {
    alignSelf: 'center',
    fontSize: 18,
    color: Colors.PrimaryColor,
    marginTop: 10,
    marginBottom: 10,
    fontFamily: Fonts.Regular,
  },
  viewForcancel: {
    marginTop: 7,
    marginBottom: 10,
    backgroundColor: 'white',
    width: '96%',
    alignSelf: 'center',
    borderRadius: 8,
  },
});
