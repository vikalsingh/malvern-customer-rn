import React from 'react';
import {
  View,
  Image,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import Colors from '../../constants/Colors';
import Fonts from '../../constants/Fonts';
import strings from '../../constants/languagesString';
import Images from '../../constants/Images';

function LanguagePop({languageList, setLanguage}) {
  return (
    <View style={styles.container}>
      <View style={styles.headerView}>
        <View style={styles.headerView2}>
          <Image style={styles.languageIcon} source={Images.languageIcon} />
          <Text style={styles.choosettext}>{strings.chooseLanguage}</Text>
        </View>
      </View>

      <View style={styles.flatListContainer}>
        <View style={styles.sepratorLine} />
        <FlatList
          style={{marginHorizontal: 15, marginBottom: 20}}
          scrollEnabled={true}
          data={languageList}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setLanguage(item)}
              style={styles.languageTouch}>
              <View style={styles.itemView}>
                <Image style={styles.flagIcon} source={{uri: item.flagUrl}} />
                <Text style={styles.languageNametxt}> {item.languageName}</Text>
              </View>
              <Image style={styles.arrowIcon} source={Images.arrowright} />
            </TouchableOpacity>
          )}
        />
      </View>
    </View>
  );
}

export {LanguagePop};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
  },
  headerView: {
    backgroundColor: 'white',
    height: '30%',
    justifyContent: 'center',
  },
  headerView2: {
    width: '80%',
    backgroundColor: Colors.background,
    height: '50%',
    marginTop: 10,
  },
  languageIcon: {
    height: '60%',
    width: '50%',
    resizeMode: 'contain',
    tintColor: Colors.PrimaryColor,
  },
  choosettext: {
    color: 'grey',
    alignSelf: 'center',
    marginTop: 20,
    fontSize: 26,
    fontFamily: Fonts.Regular,
    marginLeft: 20,
  },
  flatListContainer: {
    marginTop: 20,
    flex: 1,
  },
  sepratorLine: {
    height: 0.5,
    width: '90%',
    backgroundColor: 'grey',
    marginHorizontal: 15,
  },
  languageTouch: {
    height: 'auto',
    paddingVertical: 15,
    backgroundColor: 'transparent',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 0.5,
    borderColor: 'grey',
  },
  itemView: {
    height: 50,
    marginLeft: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  languageNametxt: {
    color: 'black',
    marginLeft: 10,
    fontSize: 18,
    fontFamily: Fonts.Regular,
  },
  flagIcon: {
    width: 50,
    height: '100%',
    resizeMode: 'contain',
  },
  arrowIcon: {
    width: 15,
    height: 15,
    marginRight: 15,
    resizeMode: 'contain',
    tintColor: Colors.PrimaryColor,
  },
});
