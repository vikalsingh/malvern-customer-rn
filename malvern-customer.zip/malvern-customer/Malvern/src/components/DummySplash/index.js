// @flow
import DummySplash from './DummySplash';

export default DummySplash;
