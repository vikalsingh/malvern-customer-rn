import React from 'react';
import {View, StyleSheet, Text, TouchableOpacity} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';
import Fonts from '../../constants/Fonts';

function LoginButtons({text, onClick, style1}) {
  return (
    <TouchableOpacity onPress={() => onClick()}>
      <View style={[styles.buttonView, style1]}>
        <Text style={styles.logintext}>{text}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  buttonView: {
    marginTop: hp('3.5%'),
    height: wp('13%'),
    borderRadius: wp('12%'),
    width: '85%',
    backgroundColor: Colors.buttonsColor,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logintext: {
    color: 'white',
    fontSize: wp('4.5%'),
    fontFamily: Fonts.Semibold,
  },
});

export {LoginButtons};
