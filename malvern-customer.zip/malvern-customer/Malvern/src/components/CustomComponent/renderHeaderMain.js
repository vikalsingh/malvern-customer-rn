import React from 'react';
import {
  View,
  TouchableOpacity,
  ImageBackground,
  Platform,
  Text,
  Image,
  StyleSheet,
} from 'react-native';
import Fonts from '../../constants/Fonts';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import {getStatusBarHeight} from '../../utils/IPhoneXHelper';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';

const RenderHeader = (props) => {
  const {title, navigation, back} = props;

  return (
    <ImageBackground style={styles.container}>
      <TouchableOpacity
        style={styles.touchBackBtView}
        onPress={() => navigation.openDrawer()}>
        <Image
          resizeMode="contain"
          style={styles.backIcon}
          source={Images.menuBlack}
        />
      </TouchableOpacity>

      <Text style={styles.titleText}>{title}</Text>
      <View style={{marginRight: 15, width: 30, height: 30}} />
    </ImageBackground>
  );
};

export default RenderHeader;

const styles = StyleSheet.create({
  container: {
    height: Platform.select({
      ios: 40 + getStatusBarHeight(),
      android: 50,
    }),
    width: '100%',
    borderColor: '#475d72',
    borderWidth: 0,
    alignItems: 'center',
    paddingTop: Platform.select({
      ios: getStatusBarHeight(),
      android: 0,
    }),
    flexDirection: 'row',
  },
  touchBackBtView: {
    marginLeft: 15,
    width: 35,
    height: 35,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
    backgroundColor: 'white',
    borderRadius: 30,
  },
  titleText: {
    fontSize: wp('5.33%'),
    flex: 6,
    fontFamily: Fonts.Semibold,
    textAlign: 'center',
    color: Colors.FontDarkColor,
  },
  backIcon: {
    width: 26,
    height: 26,
  },
  backTouchable: {
    position: 'absolute',
    width: 50,
    height: 50,
    top: Platform.OS === 'ios' ? getStatusBarHeight() + 10 : 0,
    left: wp('4.5%'),
  },
  backTouchable2: {
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
    width: 35,
    height: 35,
    backgroundColor: 'white',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
