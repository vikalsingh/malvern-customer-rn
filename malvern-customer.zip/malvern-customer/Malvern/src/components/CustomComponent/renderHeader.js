import React from 'react';
import {
  View,
  TouchableOpacity,
  ImageBackground,
  Platform,
  Text,
  Image,
  StyleSheet,
} from 'react-native';
import Fonts from './../../constants/Fonts';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import {getStatusBarHeight} from './../../utils/IPhoneXHelper';
import Colors from '../../constants/Colors';
import Images from '../../constants/Images';

const RenderHeader = (props) => {
  const {title, navigation, back} = props;
  return (
    <ImageBackground style={styles.headerView}>
      <TouchableOpacity
        style={styles.backtouch}
        onPress={() => (back ? navigation.goBack() : navigation.openDrawer())}>
        {back ? (
          <Image style={styles.backic} source={Images.backIc} />
        ) : (
          <Image style={styles.menuIc} source={Images.menuBlack} />
        )}
      </TouchableOpacity>
      <Text style={styles.titletxt}>{title}</Text>
      <View style={styles.emptyView} />
    </ImageBackground>
  );
};

export default RenderHeader;

const RenderHeaderBack = (props) => {
  const {title, onBack} = props;

  return (
    <ImageBackground style={styles.headerView}>
      <TouchableOpacity style={styles.backtouch} onPress={() => onBack()}>
        <Image style={styles.backic} source={Images.backIc} />
      </TouchableOpacity>
      <Text style={styles.titletxt}>{title}</Text>
      <View style={styles.emptyView} />
    </ImageBackground>
  );
};

const HeaderWhiteTitle = (props) => {
  const {title, navigation, back} = props;

  return (
    <ImageBackground style={styles.headerView}>
      <TouchableOpacity
        style={styles.backtouch}
        onPress={() => (back ? navigation.goBack() : navigation.openDrawer())}>
        {back ? (
          <Image style={styles.backic} source={Images.backIc} />
        ) : (
          <Image style={styles.menuIc} source={Images.menuBlack} />
        )}
      </TouchableOpacity>
      <Text style={[styles.titletxt, {color: 'white'}]}>{title}</Text>
      <View style={styles.emptyView} />
    </ImageBackground>
  );
};

const RenderHeader2 = (props) => {
  const {title, navigation} = props;

  return (
    <ImageBackground style={styles.headerView2}>
      <Text style={styles.titletxt2}>{title}</Text>
    </ImageBackground>
  );
};

// const RenderHeaderBack = (props) => {
//   const {title, onBack} = props;

//   return (
//     <ImageBackground style={styles.headerView}>
//       <TouchableOpacity style={styles.backtouch} onPress={() => onBack()}>
//         <Image style={styles.backic} source={Images.backIc} />
//       </TouchableOpacity>
//       <Text style={styles.titletxt}>{title}</Text>
//       <View style={styles.emptyView} />
//     </ImageBackground>
//   );
// };

export {RenderHeader2, RenderHeaderBack, HeaderWhiteTitle};

const styles = StyleSheet.create({
  headerView: {
    height: Platform.select({
      ios: 40 + getStatusBarHeight(),
      android: 50,
    }),
    width: '100%',
    borderColor: '#475d72',
    borderWidth: 0,
    alignItems: 'center',
    paddingTop: Platform.select({
      ios: getStatusBarHeight(),
      android: 0,
    }),
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  backtouch: {
    marginLeft: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: Colors.graylight,
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.8,
    elevation: 5,
    backgroundColor: 'white',
    borderRadius: 30,
  },
  backic: {
    resizeMode: 'contain',
    width: 30,
    height: 30,
    marginLeft: 4,
  },
  menuIc: {
    width: 26,
    height: 26,
    resizeMode: 'contain',
  },
  titletxt: {
    fontSize: wp('5.33%'),
    color: Colors.FontDarkColor,
    fontFamily: Fonts.Semibold,
    textAlign: 'center',
  },
  emptyView: {
    marginRight: 15,
    width: 30,
    height: 30,
  },
  headerView2: {
    height: Platform.select({
      ios: 45 + getStatusBarHeight(),
      android: 50,
    }),
    width: '100%',
    borderColor: '#475d72',
    borderWidth: 0,
    alignItems: 'center',
    paddingTop: Platform.select({
      ios: getStatusBarHeight(),
      android: 0,
    }),
    backgroundColor: Colors.backgroundColor,
    flexDirection: 'row',
  },
  titletxt2: {
    fontSize: wp('5.5%'),
    color: Colors.FontDarkColor,
    flex: 6,
    fontFamily: Fonts.Semibold,
    textAlign: 'center',
  },
});
