import React from 'react';
import {
  View,
  StyleSheet,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  Keyboard,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../constants/Colors';
import Fonts from '../../constants/Fonts';
import CountryPicker from 'react-native-country-picker-modal';
import strings from '../../constants/languagesString';
import Placeholder from '../../constants/Placeholder';
import Images from '../../constants/Images';

function InputTextWithCountry({
  editable,
  placeholder,
  cnCode,
  cnName,
  showFlag,
  onSelect,
  onShowFlag,
  phone,
  onChangePhone,
  header,
}) {
  return (
    <View style={{width: '85%', alignSelf: 'center', marginTop: wp('4%')}}>
      {header ? (
        <Text style={styles.headingtext}>
          {strings.EnterYourMobileNumber.toUpperCase()}
        </Text>
      ) : null}

      <View style={[styles.tile]}>
        <CountryPicker
          countryCode={cnName}
          withFilter={true}
          withCallingCode={true}
          containerButtonStyle={styles.countryPicker}
          onSelect={(country) => onSelect(country)}
          visible={showFlag}
          modalProps={!editable ? {visible: ''} : null}
        />
        <Text
          style={{fontFamily: Fonts.Semibold, fontSize: wp('3.8%')}}
          onPress={() => onShowFlag(true)}>
          {cnCode}
        </Text>

        <TextInput
          placeholder={
            placeholder ? strings.EnterYourMobileNumber.toUpperCase() : ''
          }
          editable={editable}
          multiline={true}
          keyboardType="number-pad"
          placeholderTextColor={'#aabbc7'}
          maxLength={20}
          value={phone}
          onChangeText={(text) => {
            onChangePhone(text.replace(/[^0-9]/g, ''));
          }}
          textContentType="creditCardNumber"
          style={styles.NumberInputText}
          returnKeyType="done"
          onSubmitEditing={() => Keyboard.dismiss()}
        />
      </View>
    </View>
  );
}

function SignUpInputText({
  icon,
  header,
  placeholder,
  text,
  onChangeText,
  keyboardType,
  onTouchable,
  onTouchStart,
}) {
  return (
    <View style={{width: '85%', alignSelf: 'center', marginTop: wp('4%')}}>
      {header ? (
        <Text style={styles.headingtext}>{header.toUpperCase()}</Text>
      ) : null}

      <View style={[styles.tile, {width: '100%'}]}>
        {icon ? (
          <Image resizeMode="contain" style={styles.tileIcon} source={icon} />
        ) : null}

        <TextInput
          style={styles.searchTextInput}
          placeholder={placeholder ? placeholder : ''}
          placeholderTextColor={Placeholder.placeholderTextColor}
          autoCorrect={false}
          onChangeText={(name) => {
            if (name.length == 1 && name == ' ') {
            } else {
              onChangeText(name);
            }
          }}
          onTouchStart={() =>
            onTouchable ? onTouchStart() : console.log('touch')
          }
          value={text}
          keyboardType={keyboardType}
          returnKeyType="done"
        />
      </View>
    </View>
  );
}

function SignUpInputTextPassword({
  icon,
  header,
  placeholder,
  text,
  onChangeText,
  keyboardType,
  showEye,
  onClickEye,
}) {
  return (
    <View style={{width: '85%', alignSelf: 'center', marginTop: wp('4%')}}>
      {header ? (
        <Text style={styles.headingtext}>{header.toUpperCase()}</Text>
      ) : null}

      <View style={[styles.tile, {width: '100%'}]}>
        <Image resizeMode="contain" style={styles.tileIcon} source={icon} />
        <TextInput
          style={[styles.searchTextInput, {width: '70%'}]}
          placeholder={placeholder ? placeholder : ''}
          placeholderTextColor={Placeholder.placeholderTextColor}
          autoCorrect={false}
          onChangeText={(name) => {
            if (name.length == 1 && name == ' ') {
            } else {
              onChangeText(name);
            }
          }}
          secureTextEntry={showEye}
          value={text}
          keyboardType={keyboardType}
          returnKeyType="done"
        />
        <TouchableOpacity onPress={() => onClickEye()}>
          <Image
            resizeMode="contain"
            style={{
              width: 28,
              height: 28,
              marginLeft: 0,
              resizeMode: 'contain',
            }}
            source={showEye ? Images.no_Visibility : Images.show_Visibility}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

export {InputTextWithCountry, SignUpInputTextPassword, SignUpInputText};

const styles = StyleSheet.create({
  tile: {
    backgroundColor: Colors.graylights,
    width: '100%',
    alignSelf: 'center',
    paddingLeft: 10,
    height: wp('13%'),
    borderRadius: wp('14%') / 4,
    marginHorizontal: wp('5.33%'),
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 0.2,
    borderColor: 'gray',
    borderBottomColor: 'grey',
  },
  NumberInputText: {
    fontFamily: Fonts.Regular,
    fontSize: wp('3.8%'),
    width: '100%',
    alignSelf: 'center',
    marginLeft: 10,
  },
  headingtext: {
    marginBottom: wp('2%'),
    fontSize: wp('3.5%'),
    fontFamily: Fonts.Semibold,
    color: Colors.FontDarkColor,
  },
  tileIcon: {
    width: 24,
    height: 24,
    marginLeft: 0,
    resizeMode: 'contain',
  },
  tileIcon2: {
    width: 28,
    height: 28,
    marginLeft: 0,
    resizeMode: 'contain',
  },
  searchTextInput: {
    width: '84%',
    backgroundColor: 'transparent',
    borderColor: 'gray',
    borderRadius: 0,
    fontSize: wp('3.8%'),
    fontFamily: Fonts.Regular,
    marginLeft: 25,
  },
});
