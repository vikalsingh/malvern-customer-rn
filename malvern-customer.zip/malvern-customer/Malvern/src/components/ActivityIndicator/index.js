// @flow
import Activity from './ActivityIndicator';
export default Activity;
