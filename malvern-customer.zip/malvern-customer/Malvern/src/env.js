module.exports = {
  // API_ROOT: 'https://boraque-api.ondemandcreations.com/',
  API_ROOT: 'https://malvern-api.ondemandcreations.com/',
};
