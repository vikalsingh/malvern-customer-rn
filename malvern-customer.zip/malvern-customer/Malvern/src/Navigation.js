import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
import DrawerContent from './DrawerContent';

import {
  Login,
  Password,
  VerifyOTP,
  Register,
  Profile,
  EditProfile,
  Track,
  ChangePassword,
  MyTrip,
  NewsLetter,
  Emergency,
  Support,
  SupportMessage,
  Disputes,
  AddDispute,
  About,
  Invite,
  AddCard,
  MapSearch,
  AccountDetail,
  Thankyou,
  AddContacts,
  ChangePasswordProfile,
  CouponScreen,
  Wallet,
  PreferredDriver,
  Chat,
  AddAmtWallet,
  PrivacyPolicy,
  TermsConditions,
} from './containers/index';

function MyTripNavigation() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        gestureEnabled: false,
      }}>
      <Stack.Screen name="MapSearchScreen" component={MapSearch} />
      <Stack.Screen name="ThankyouScreen" component={Thankyou} />
      <Stack.Screen name="Chat" component={Chat} />
    </Stack.Navigator>
  );
}

function DrawerNav() {
  return (
    <Drawer.Navigator
      drawerContent={(props) => <DrawerContent {...props} />}
      drawerStyle={{width: '76%'}}
      screenOptions={{
        headerShown: false,
      }}>
      <Drawer.Screen name="MyTrip" component={MyTripNavigation} />
      <Drawer.Screen name="MyTripScreen" component={MyTrip} />
      <Drawer.Screen name="NewsLetterScreen" component={NewsLetter} />
      <Drawer.Screen name="WalletScreen" component={Wallet} />
      <Drawer.Screen name="PreferredScreen" component={PreferredDriver} />
      <Drawer.Screen name="CouponScreen" component={CouponScreen} />
      <Drawer.Screen name="AccountDetail" component={AccountDetail} />
      <Drawer.Screen name="Emergency" component={Emergency} />
      <Drawer.Screen name="Support" component={Support} />
      <Drawer.Screen name="About" component={About} />
      <Drawer.Screen name="ProfileScreen" component={Profile} />
      <Drawer.Screen name="Track" component={Track} />
      <Drawer.Screen name="Invite" component={Invite} />
      <Drawer.Screen name="Disputes" component={Disputes} />
    </Drawer.Navigator>
  );
}

function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
          gestureEnabled: false,
        }}>
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Password" component={Password} />
        <Stack.Screen name="VerifyOTP" component={VerifyOTP} />
        <Stack.Screen name="Register" component={Register} />

        <Stack.Screen name="ChangePassword" component={ChangePassword} />
        <Stack.Screen name="SideMenu" component={DrawerNav} />

        <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
        <Stack.Screen name="TermsConditions" component={TermsConditions} />
        <Stack.Screen name="SupportMessage" component={SupportMessage} />
        <Stack.Screen
          name="ChangePasswordProfile"
          component={ChangePasswordProfile}
        />
        <Stack.Screen name="EditProfile" component={EditProfile} />
        <Stack.Screen name="AddContacts" component={AddContacts} />
        <Stack.Screen name="AddCard" component={AddCard} />
        <Stack.Screen name="AddDispute" component={AddDispute} />

        <Stack.Screen name="AddAmtWallet" component={AddAmtWallet} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default AppNavigator;
